"""
Video Recording & Live Camera Manager for Mosque Kuliah & Friday Khutbah
Handles Linux V4L2 HDMI capture cards (/dev/video*) and MP4 recording using ffmpeg.
"""

import os
import sys
import glob
import time
import shutil
import subprocess
import threading
from pathlib import Path
from typing import Dict, Any, List, Optional

class RecordingManager:
    def __init__(self, recordings_dir: str = "/var/lib/esolat/media/recordings"):
        self.recordings_dir = Path(recordings_dir)
        try:
            self.recordings_dir.mkdir(parents=True, exist_ok=True)
        except Exception:
            self.recordings_dir = Path("./data/media/recordings")
            self.recordings_dir.mkdir(parents=True, exist_ok=True)

        self.current_process: Optional[subprocess.Popen] = None
        self.recording_start_time: float = 0.0
        self.current_filename: str = ""
        self.lock = threading.Lock()

    def detect_video_devices(self) -> List[str]:
        """
        Scans for available V4L2 video devices (/dev/video*).
        USB HDMI capture cards typically appear as /dev/video0 or /dev/video2.
        """
        devices = sorted(glob.glob("/dev/video*"))
        return devices

    def is_recording(self) -> bool:
        with self.lock:
            if self.current_process:
                if self.current_process.poll() is None:
                    return True
                else:
                    self.current_process = None
            return False

    def get_status(self, rtsp_url: str = "") -> Dict[str, Any]:
        with self.lock:
            recording = self.is_recording()
            duration = int(time.time() - self.recording_start_time) if recording else 0
            devices = self.detect_video_devices()
            has_rtsp = bool(rtsp_url and rtsp_url.startswith("rtsp://"))

            return {
                "camera_detected": len(devices) > 0 or has_rtsp,
                "video_devices": devices,
                "has_rtsp_configured": has_rtsp,
                "is_recording": recording,
                "duration_seconds": duration,
                "current_file": self.current_filename if recording else None,
                "ffmpeg_available": shutil.which("ffmpeg") is not None
            }

    def start_recording(self, source: str = "/dev/video0", audio_device: str = "default") -> Dict[str, Any]:
        """
        Starts MP4 recording from either:
        1. V4L2 USB HDMI capture card (/dev/video*)
        2. RTSP IP Network Stream (rtsp://...)
        """
        with self.lock:
            if self.is_recording():
                return {"success": False, "message": "Rakaman sedang berjalan."}

            ffmpeg_bin = shutil.which("ffmpeg")
            if not ffmpeg_bin:
                return {
                    "success": False,
                    "message": "Utiliti ffmpeg belum dipasang. Sila pasang dengan: sudo apt install ffmpeg"
                }

            is_rtsp = source.startswith("rtsp://") or source.startswith("http://")

            if not is_rtsp and not Path(source).exists():
                devices = self.detect_video_devices()
                if devices:
                    source = devices[0]
                else:
                    return {"success": False, "message": "Tiada peranti kamera/HDMI capture dikesan di /dev/video* dan tiada strim RTSP."}

            timestamp = time.strftime("%Y-%m-%d_%H-%M-%S")
            self.current_filename = f"kuliah_{timestamp}.mp4"
            output_path = self.recordings_dir / self.current_filename

            if is_rtsp:
                # RTSP IP Camera Stream (direct copy = near 0% CPU usage)
                cmd = [
                    ffmpeg_bin,
                    "-y",
                    "-rtsp_transport", "tcp",
                    "-i", source,
                    "-c:v", "copy",
                    "-c:a", "aac",
                    "-b:a", "128k",
                    "-movflags", "+faststart",
                    str(output_path)
                ]
            else:
                # Standard V4L2 USB HDMI capture card
                cmd = [
                    ffmpeg_bin,
                    "-y",
                    "-f", "v4l2",
                    "-framerate", "30",
                    "-video_size", "1920x1080",
                    "-i", source,
                    "-f", "alsa",
                    "-i", audio_device,
                    "-c:v", "libx264",
                    "-preset", "veryfast",
                    "-crf", "23",
                    "-c:a", "aac",
                    "-b:a", "128k",
                    "-movflags", "+faststart",
                    str(output_path)
                ]

            try:
                self.current_process = subprocess.Popen(
                    cmd,
                    stdin=subprocess.PIPE,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL
                )
                self.recording_start_time = time.time()
                return {
                    "success": True,
                    "message": f"Rakaman dimulakan: {self.current_filename}",
                    "file": self.current_filename,
                    "source": "rtsp" if is_rtsp else "v4l2"
                }
            except Exception as e:
                # Fallback for V4L2 without separate ALSA input if ALSA capture device differs
                if not is_rtsp:
                    try:
                        cmd_no_audio = [
                            ffmpeg_bin,
                            "-y",
                            "-f", "v4l2",
                            "-framerate", "30",
                            "-video_size", "1920x1080",
                            "-i", source,
                            "-c:v", "libx264",
                            "-preset", "veryfast",
                            "-crf", "23",
                            "-movflags", "+faststart",
                            str(output_path)
                        ]
                        self.current_process = subprocess.Popen(
                            cmd_no_audio,
                            stdin=subprocess.PIPE,
                            stdout=subprocess.DEVNULL,
                            stderr=subprocess.DEVNULL
                        )
                        self.recording_start_time = time.time()
                        return {
                            "success": True,
                            "message": f"Rakaman video dimulakan (tanpa audio ALSA): {self.current_filename}",
                            "file": self.current_filename,
                            "source": "v4l2"
                        }
                    except Exception as ex2:
                        return {"success": False, "message": f"Gagal memulakan ffmpeg: {str(ex2)}"}
                return {"success": False, "message": f"Gagal memulakan rakaman RTSP: {str(e)}"}

    def stop_recording(self) -> Dict[str, Any]:
        """
        Gracefully stops ffmpeg by sending 'q' to stdin so MP4 trailer is cleanly finalized.
        """
        with self.lock:
            if not self.current_process:
                return {"success": False, "message": "Tiada rakaman sedang aktif."}

            try:
                # Send 'q' to quit ffmpeg cleanly
                if self.current_process.stdin:
                    try:
                        self.current_process.stdin.write(b"q\n")
                        self.current_process.stdin.flush()
                    except Exception:
                        pass
                self.current_process.terminate()
                self.current_process.wait(timeout=5)
            except Exception:
                try:
                    self.current_process.kill()
                except Exception:
                    pass
            finally:
                self.current_process = None

            saved_file = self.current_filename
            self.current_filename = ""
            self.recording_start_time = 0.0

            return {
                "success": True,
                "message": f"Rakaman berjaya disimpan: {saved_file}",
                "file": saved_file
            }

    def list_recordings(self) -> List[Dict[str, Any]]:
        """
        Lists all recorded MP4 files with file size and timestamp.
        """
        items = []
        for p in sorted(self.recordings_dir.glob("*.mp4"), key=os.path.getmtime, reverse=True):
            try:
                stat = p.stat()
                items.append({
                    "filename": p.name,
                    "size_mb": round(stat.st_size / (1024 * 1024), 2),
                    "created_at": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(stat.st_mtime)),
                    "download_url": f"/media/recordings/{p.name}"
                })
            except Exception:
                continue
        return items

    def delete_recording(self, filename: str) -> bool:
        clean_name = os.path.basename(filename)
        target = self.recordings_dir / clean_name
        if target.exists() and target.suffix == ".mp4":
            try:
                target.unlink()
                return True
            except Exception:
                pass
        return False
