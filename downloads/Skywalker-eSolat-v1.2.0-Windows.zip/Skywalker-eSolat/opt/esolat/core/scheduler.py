"""
Prayer State Engine & Signage Life-Cycle Controller
Calculates prayer state machine:
NORMAL -> PRE_ADHAN -> ADHAN -> DOA_ADHAN -> IQAMAH -> SOLAT -> NORMAL
Handles licensing overrides (LOCKED screen on trial expiration).
"""

import time
from datetime import datetime, timedelta
from typing import Dict, Any, Optional

class PrayerScheduler:
    def __init__(self, db, jakim_mgr, audio_mgr, license_mgr):
        self.db = db
        self.jakim_mgr = jakim_mgr
        self.audio_mgr = audio_mgr
        self.license_mgr = license_mgr

        # Simulation override state for testing
        self.test_override: Optional[Dict[str, Any]] = None
        self.test_override_expiry: float = 0.0

        # Audio trigger trackers to avoid replaying within the same prayer window
        self.last_audio_played_prayer = None
        self.last_audio_played_state = None

    def set_test_mode(self, state: str, prayer_name: str = "Zohor", duration_sec: int = 30):
        """
        Allows admin to trigger a state preview (ADHAN, IQAMAH, SOLAT, LOCKED) for testing.
        """
        self.test_override = {
            "state": state.upper(),
            "prayer": prayer_name,
            "seconds_left": duration_sec,
            "total_duration": duration_sec
        }
        self.test_override_expiry = time.time() + duration_sec

    def clear_test_mode(self):
        self.test_override = None
        self.test_override_expiry = 0.0

    def _parse_time_today(self, time_str: str, offset_min: int = 0) -> datetime:
        """
        Parses HH:MM:SS or HH:MM string into today's datetime object with offset.
        """
        now = datetime.now()
        parts = [int(p) for p in time_str.strip().split(":")]
        h = parts[0]
        m = parts[1]
        s = parts[2] if len(parts) > 2 else 0
        base_dt = now.replace(hour=h, minute=m, second=s, microsecond=0)
        if offset_min != 0:
            base_dt += timedelta(minutes=offset_min)
        return base_dt

    def get_current_signage_state(self) -> Dict[str, Any]:
        """
        Computes the complete real-time state for the Kiosk Display & Admin Panel.
        """
        now_dt = datetime.now()
        now_ts = time.time()

        # 1. License Check
        lic_status = self.license_mgr.get_full_system_status()
        if not lic_status.get("is_unlocked", False):
            return {
                "state": "LOCKED",
                "message": lic_status.get("message", "Trial Expired"),
                "hwid": lic_status.get("hwid"),
                "license_status": lic_status,
                "current_time": now_dt.strftime("%H:%M:%S"),
                "current_date": now_dt.strftime("%A, %d %B %Y")
            }

        # 2. Check Test Override
        if self.test_override and now_ts < self.test_override_expiry:
            sec_left = int(self.test_override_expiry - now_ts)
            return {
                "state": self.test_override["state"],
                "active_prayer": self.test_override["prayer"],
                "countdown_seconds": sec_left,
                "total_duration": self.test_override["total_duration"],
                "is_test_preview": True,
                "license_status": lic_status,
                "current_time": now_dt.strftime("%H:%M:%S"),
                "current_date": now_dt.strftime("%A, %d %B %Y")
            }
        else:
            self.test_override = None

        # 3. Retrieve settings and prayer times
        settings = self.db.get_all_settings()
        zone = settings.get("jakim_zone", "WLY01")
        prayer_data = self.jakim_mgr.get_today_prayer_times(zone, now_dt)

        # Offsets
        offsets = {
            "imsak": int(settings.get("offset_imsak", 0)),
            "subuh": int(settings.get("offset_subuh", 0)),
            "syuruk": int(settings.get("offset_syuruk", 0)),
            "zohor": int(settings.get("offset_zohor", 0)),
            "asar": int(settings.get("offset_asar", 0)),
            "maghrib": int(settings.get("offset_maghrib", 0)),
            "isyak": int(settings.get("offset_isyak", 0))
        }

        # Parse schedule into datetimes
        schedule = [
            ("Imsak", self._parse_time_today(prayer_data.get("imsak", "05:40:00"), offsets["imsak"]), False),
            ("Subuh", self._parse_time_today(prayer_data.get("fajr", "05:50:00"), offsets["subuh"]), True),
            ("Syuruk", self._parse_time_today(prayer_data.get("syuruk", "07:00:00"), offsets["syuruk"]), False),
            ("Zohor", self._parse_time_today(prayer_data.get("dhuhr", "13:10:00"), offsets["zohor"]), True),
            ("Asar", self._parse_time_today(prayer_data.get("asr", "16:20:00"), offsets["asar"]), True),
            ("Maghrib", self._parse_time_today(prayer_data.get("maghrib", "19:15:00"), offsets["maghrib"]), True),
            ("Isyak", self._parse_time_today(prayer_data.get("isha", "20:25:00"), offsets["isyak"]), True)
        ]

        # Parameters
        pre_lead_sec = int(settings.get("pre_adhan_lead", 3)) * 60
        adhan_duration_sec = 180  # 3 minutes for Adhan
        doa_duration_sec = 60     # 1 minute for Doa Selepas Adhan
        solat_duration_sec = int(settings.get("solat_duration", 12)) * 60

        current_state = "NORMAL"
        active_prayer = None
        countdown_sec = 0
        total_duration = 0

        # Check solat windows (Subuh, Zohor, Asar, Maghrib, Isyak)
        solat_prayers = [p for p in schedule if p[2]]

        for name, p_dt, _ in solat_prayers:
            key_name = name.lower()
            iqamah_min = int(settings.get(f"iqamah_{key_name}", 10))
            iqamah_sec = iqamah_min * 60

            t_pre = p_dt - timedelta(seconds=pre_lead_sec)
            t_adhan_start = p_dt
            t_adhan_end = t_adhan_start + timedelta(seconds=adhan_duration_sec)
            t_doa_end = t_adhan_end + timedelta(seconds=doa_duration_sec)
            t_iqamah_end = t_doa_end + timedelta(seconds=iqamah_sec)
            t_solat_end = t_iqamah_end + timedelta(seconds=solat_duration_sec)

            if t_pre <= now_dt < t_adhan_start:
                current_state = "PRE_ADHAN"
                active_prayer = name
                countdown_sec = int((t_adhan_start - now_dt).total_seconds())
                total_duration = pre_lead_sec
                # Trigger soft chime once
                if self.last_audio_played_prayer != (name, "PRE_ADHAN"):
                    self.audio_mgr.play_sound("pre_adhan.wav")
                    self.last_audio_played_prayer = (name, "PRE_ADHAN")
                break

            elif t_adhan_start <= now_dt < t_adhan_end:
                current_state = "ADHAN"
                active_prayer = name
                countdown_sec = int((t_adhan_end - now_dt).total_seconds())
                total_duration = adhan_duration_sec
                # Trigger Adhan audio once
                if self.last_audio_played_prayer != (name, "ADHAN"):
                    mode = settings.get(f"adhan_mode_{key_name}", "auto")
                    if mode == "auto":
                        snd = settings.get("audio_azan_subuh_file", "azan_subuh_special.mp3") if name == "Subuh" else settings.get("audio_azan_standard_file", "azan_mekah.mp3")
                        self.audio_mgr.play_sound(snd)
                    elif mode == "beep":
                        self.audio_mgr.play_sound("beep.wav")
                    self.last_audio_played_prayer = (name, "ADHAN")
                break

            elif t_adhan_end <= now_dt < t_doa_end:
                current_state = "DOA_ADHAN"
                active_prayer = name
                countdown_sec = int((t_doa_end - now_dt).total_seconds())
                total_duration = doa_duration_sec
                break

            elif t_doa_end <= now_dt < t_iqamah_end:
                current_state = "IQAMAH"
                active_prayer = name
                countdown_sec = int((t_iqamah_end - now_dt).total_seconds())
                total_duration = iqamah_sec
                break

            elif t_iqamah_end <= now_dt < t_solat_end:
                current_state = "SOLAT"
                active_prayer = name
                countdown_sec = int((t_solat_end - now_dt).total_seconds())
                total_duration = solat_duration_sec
                # Trigger double chime at Iqamah finish
                if self.last_audio_played_prayer != (name, "SOLAT"):
                    self.audio_mgr.play_sound("beep.wav")
                    self.last_audio_played_prayer = (name, "SOLAT")
                break

        # If NORMAL, compute next upcoming prayer and countdown
        next_prayer = None
        time_to_next_sec = 0

        for name, p_dt, is_solat in schedule:
            if p_dt > now_dt:
                next_prayer = name
                time_to_next_sec = int((p_dt - now_dt).total_seconds())
                break

        # If passed Isyak, next is tomorrow's Subuh
        if not next_prayer:
            next_prayer = "Subuh"
            subuh_tomorrow = schedule[1][1] + timedelta(days=1)
            time_to_next_sec = int((subuh_tomorrow - now_dt).total_seconds())

        # Determine current prayer slot
        current_prayer_slot = "Isyak"
        for i in range(len(schedule)):
            if schedule[i][1] <= now_dt:
                current_prayer_slot = schedule[i][0]

        # Format timetable dictionary for display
        ribbon_times = {
            "Imsak": schedule[0][1].strftime("%H:%M"),
            "Subuh": schedule[1][1].strftime("%H:%M"),
            "Syuruk": schedule[2][1].strftime("%H:%M"),
            "Zohor": schedule[3][1].strftime("%H:%M"),
            "Asar": schedule[4][1].strftime("%H:%M"),
            "Maghrib": schedule[5][1].strftime("%H:%M"),
            "Isyak": schedule[6][1].strftime("%H:%M")
        }

        # Slides
        slides = self.db.get_slides(enabled_only=True)

        return {
            "state": current_state,
            "active_prayer": active_prayer,
            "countdown_seconds": countdown_sec,
            "total_duration": total_duration,
            "current_prayer_slot": current_prayer_slot,
            "next_prayer": next_prayer,
            "time_to_next_seconds": time_to_next_sec,
            "ribbon_times": ribbon_times,
            "hijri_date": prayer_data.get("hijri", "1448-04-16"),
            "gregorian_date": now_dt.strftime("%A, %d %B %Y"),
            "current_time": now_dt.strftime("%H:%M:%S"),
            "settings": {
                "mosque_name": settings.get("mosque_name", "Surau Al-Ikhlas"),
                "mosque_location": settings.get("mosque_location", "Shah Alam"),
                "ticker_text": settings.get("ticker_text", ""),
                "ticker_speed": settings.get("ticker_speed", "normal"),
                "slide_duration": int(settings.get("slide_duration", 10)),
                "bank_name": settings.get("bank_name", ""),
                "bank_account_no": settings.get("bank_account_no", ""),
                "bank_account_holder": settings.get("bank_account_holder", ""),
                "bank_qr_url": settings.get("bank_qr_url", ""),
                "kiosk_layout": settings.get("kiosk_layout", "full"),
                "kuliah_title": settings.get("kuliah_title", "Kuliah Maghrib Perdana: Menghayati Al-Quran"),
                "kuliah_ustaz": settings.get("kuliah_ustaz", "Ustaz Hj. Ahmad Fauzi"),
                "kuliah_date": settings.get("kuliah_date", "Setiap Hari Rabu (Lepas Maghrib)"),
                # Multi-Source Video, PiP & Layout Settings
                "kiosk_layout_mode": settings.get("kiosk_layout_mode", "fullscreen" if settings.get("media_fullscreen_enabled") == "1" else "split"),
                "pip_mode": settings.get("pip_mode", "none"),
                "media_source_type": settings.get("media_source_type", settings.get("video_source_type", "slides")),
                "media_stream_url": settings.get("media_stream_url", settings.get("video_source_url", "")),
                "active_layout_mode": settings.get("active_layout_mode", "fullscreen_signage"),
                "video_source_type": settings.get("video_source_type", settings.get("media_source_type", "slides")),
                "video_source_url": settings.get("video_source_url", settings.get("media_stream_url", "")),
                "video_audio_enabled": settings.get("video_audio_enabled", "0"),
                "video_volume": int(settings.get("video_volume", 80)),
                "media_fullscreen_enabled": settings.get("media_fullscreen_enabled", "1" if settings.get("kiosk_layout_mode") == "fullscreen" else "0"),
                # Azan MP3 Audio Management
                "audio_azan_subuh": settings.get("audio_azan_subuh") or settings.get("audio_azan_subuh_file", "azan_subuh_special.mp3"),
                "audio_azan_regular": settings.get("audio_azan_regular") or settings.get("audio_azan_standard_file", "azan_mekah.mp3"),
                "audio_volume": int(settings.get("audio_volume", settings.get("audio_azan_volume", 80))),
                "audio_azan_subuh_file": settings.get("audio_azan_subuh") or settings.get("audio_azan_subuh_file", "azan_subuh_special.mp3"),
                "audio_azan_standard_file": settings.get("audio_azan_regular") or settings.get("audio_azan_standard_file", "azan_mekah.mp3"),
                "audio_azan_volume": int(settings.get("audio_volume", settings.get("audio_azan_volume", 80))),
                # Interactive Drag & Resize Custom Canvas Layout
                "custom_layout_enabled": settings.get("custom_layout_enabled", "0"),
                "layout_edit_mode": settings.get("layout_edit_mode", "0"),
                "custom_layout_zones": self.db.get_custom_layout_zones() if hasattr(self.db, "get_custom_layout_zones") else {
                    "media_stage": {"x": 30, "y": 270, "width": 1250, "height": 730},
                    "sidebar_takwim": {"x": 1300, "y": 270, "width": 590, "height": 730},
                    "pip_overlay": {"x": 1340, "y": 650, "width": 540, "height": 320}
                }
            },
            "slides": slides,
            "license_status": lic_status
        }
