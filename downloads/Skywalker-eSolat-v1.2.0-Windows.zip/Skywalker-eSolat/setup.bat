@echo off
TITLE Skywalker e-Solat Windows Installer & Setup
SETLOCAL EnableDelayedExpansion

echo ==========================================================================
echo 🕌 Skywalker e-Solat Mosque Digital Signage & Kiosk Setup (Windows)
echo Version: 1.2.0 (Commercial Standalone)
echo Vendor : Skywalker Consortium (AS0463209-A)
echo ==========================================================================
echo.

SET "INSTALL_DIR=%~dp0"

:: 1. Check Python Availability
echo [1/4] Checking Python Runtime environment...
where python >nul 2>nul
IF %ERRORLEVEL% NEQ 0 (
    echo.
    echo [WARNING] Python was not found in your system PATH.
    echo Sila muat turun dan pasang Python 3.10+ dari https://www.python.org/
    echo Pastikan anda menandakan kotak "Add Python to PATH" semasa pemasangan.
    echo.
    pause
    EXIT /B 1
) ELSE (
    echo [OK] Python is installed.
)

:: 2. Create Desktop Shortcut using VBScript
echo [2/4] Creating Desktop Shortcut for e-Solat Kiosk...
SET "DESKTOP_DIR=%USERPROFILE%\Desktop"
SET "VBS_SCRIPT=%TEMP%\create_esolat_shortcut.vbs"

(
echo Set oWS = WScript.CreateObject^("WScript.Shell"^)
echo sLinkFile = "%DESKTOP_DIR%\Skywalker e-Solat Kiosk.lnk"
echo Set oLink = oWS.CreateShortcut^(sLinkFile^)
echo oLink.TargetPath = "%INSTALL_DIR%esolat-kiosk.bat"
echo oLink.WorkingDirectory = "%INSTALL_DIR%"
echo oLink.Description = "Skywalker e-Solat Mosque Digital Signage"
echo oLink.Save
) > "%VBS_SCRIPT%"

cscript //nologo "%VBS_SCRIPT%" >nul 2>nul
del "%VBS_SCRIPT%" >nul 2>nul
echo [OK] Desktop Shortcut created successfully.

:: 3. Create Admin Shortcut
echo [3/4] Creating Desktop Shortcut for Admin Panel...
(
echo Set oWS = WScript.CreateObject^("WScript.Shell"^)
echo sLinkFile = "%DESKTOP_DIR%\e-Solat Phone Admin.lnk"
echo Set oLink = oWS.CreateShortcut^(sLinkFile^)
echo oLink.TargetPath = "http://localhost:8080/admin"
echo oLink.Description = "Skywalker e-Solat Admin Panel"
echo oLink.Save
) > "%VBS_SCRIPT%"

cscript //nologo "%VBS_SCRIPT%" >nul 2>nul
del "%VBS_SCRIPT%" >nul 2>nul
echo [OK] Admin Shortcut created successfully.

:: 4. Completion
echo.
echo ==========================================================================
echo ✅ PEMASANGAN SELESAI (INSTALLATION COMPLETED)
echo.
echo Pintasan "Skywalker e-Solat Kiosk" telah dicipta di Desktop anda.
echo.
echo Pilihan Pelancaran:
echo   1. Lancarkan Paparan e-Solat Kiosk sekarang (Fullscreen)
echo   2. Buka Panel Kawalan Pentadbir (Admin Panel)
echo   3. Keluar
echo ==========================================================================
echo.
set /p CHOICE="Sila pilih nombor (1-3): "

IF "%CHOICE%"=="1" (
    start "" "%INSTALL_DIR%esolat-kiosk.bat"
) ELSE IF "%CHOICE%"=="2" (
    start "" "http://localhost:8080/admin"
)

EXIT /B 0
