@echo off
TITLE Skywalker e-Solat Windows Binary Builder
SETLOCAL EnableDelayedExpansion

echo ==========================================================================
echo 🔨 Building Skywalker e-Solat for Windows (Standalone .exe)
echo ==========================================================================

:: 1. Ensure Python and PyInstaller
where pyinstaller >nul 2>nul
IF %ERRORLEVEL% NEQ 0 (
    echo [INFO] Installing PyInstaller...
    pip install pyinstaller
)

:: 2. Compile standalone binary
echo ⚙️ Compiling backend into standalone esolat-server.exe...
pyinstaller --clean --onefile --strip --name esolat-server ^
    --paths "..\opt\esolat" ^
    --distpath "bin" ^
    --workpath "build\work" ^
    --specpath "build" ^
    "..\opt\esolat\bin\esolat-server"

IF %ERRORLEVEL% EQU 0 (
    echo ==========================================================================
    echo ✅ SUCCESS: Built bin\esolat-server.exe
    echo ==========================================================================
) ELSE (
    echo ❌ ERROR: Build failed!
    EXIT /B 1
)

EXIT /B 0
