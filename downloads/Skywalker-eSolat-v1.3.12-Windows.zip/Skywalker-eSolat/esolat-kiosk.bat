@echo off
TITLE Skywalker e-Solat Mosque Signage Launcher
SETLOCAL EnableDelayedExpansion

:: 1. Define Paths
SET "APP_DIR=%~dp0"
SET "SERVER_EXE=%APP_DIR%bin\esolat-server.exe"
SET "SERVER_URL=http://localhost:8080"

:: 2. Start Backend Server if not already running
netstat -ano | find "8080" | find "LISTENING" >nul 2>nul
IF "%ERRORLEVEL%"=="0" (
    echo [e-Solat] Server is already active on port 8080.
) ELSE (
    echo [e-Solat] Starting e-Solat background server daemon...
    SET "PY_CMD=python"
    where python >nul 2>nul
    IF %ERRORLEVEL% NEQ 0 (
        where py >nul 2>nul
        IF %ERRORLEVEL% EQU 0 (
            SET "PY_CMD=py"
        )
    )

    IF EXIST "%SERVER_EXE%" (
        start "" /B "%SERVER_EXE%" --port 8080 --host 0.0.0.0
    ) ELSE IF EXIST "%APP_DIR%opt\esolat\bin\esolat-server" (
        start "" /B !PY_CMD! "%APP_DIR%opt\esolat\bin\esolat-server" --port 8080 --host 0.0.0.0 --web-dir "%APP_DIR%opt\esolat\web"
    ) ELSE IF EXIST "%APP_DIR%..\opt\esolat\bin\esolat-server" (
        start "" /B !PY_CMD! "%APP_DIR%..\opt\esolat\bin\esolat-server" --port 8080 --host 0.0.0.0 --web-dir "%APP_DIR%..\opt\esolat\web"
    ) ELSE (
        echo [ERROR] Backend server not found at %SERVER_EXE%!
    )
)

:: 3. Wait for Server to respond
echo [e-Solat] Waiting for service to become ready...
timeout /t 2 /nobreak >nul

:: 4. Find Browser (Edge or Chrome)
SET "BROWSER_CMD="
IF EXIST "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" (
    SET "BROWSER_CMD=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
) ELSE IF EXIST "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" (
    SET "BROWSER_CMD=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
) ELSE IF EXIST "%ProgramFiles%\Google\Chrome\Application\chrome.exe" (
    SET "BROWSER_CMD=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
) ELSE IF EXIST "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" (
    SET "BROWSER_CMD=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
)

:: 5. Launch Fullscreen Kiosk Mode
IF DEFINED BROWSER_CMD (
    echo [e-Solat] Launching Kiosk Display using "!BROWSER_CMD!"...
    start "" "!BROWSER_CMD!" --kiosk "%SERVER_URL%" --edge-kiosk-type=fullscreen --no-first-run --disable-pinch --autoplay-policy=no-user-gesture-required --user-data-dir="%TEMP%\esolat-kiosk-profile"
) ELSE (
    echo [e-Solat] Launching Default Browser...
    start "" "%SERVER_URL%"
)

EXIT /B 0
