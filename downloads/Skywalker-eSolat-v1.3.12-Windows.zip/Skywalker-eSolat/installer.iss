; Inno Setup Script for Skywalker e-Solat Digital Signage & Mosque Kiosk System
; Generates standard Windows single-executable setup wizard

#define MyAppName "Skywalker e-Solat Kiosk"
#define MyAppVersion "1.3.9"
#define MyAppPublisher "Skywalker Consortium"
#define MyAppURL "https://sky12388.github.io/esolat/"
#define MyAppExeName "esolat-kiosk.bat"

[Setup]
AppId={{8B8A61C2-8245-4DC3-81D2-38B8684D024B}}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
AppPublisherURL={#MyAppURL}
AppSupportURL={#MyAppURL}
AppUpdatesURL={#MyAppURL}
DefaultDirName={autopf}\Skywalker e-Solat
DefaultGroupName={#MyAppName}
DisableProgramGroupPage=yes
LicenseFile=..\USER_MANUAL.md
OutputDir=dist
OutputBaseFilename=Skywalker-eSolat-Setup-v1.3.9
Compression=lzma2/max
SolidCompression=yes
WizardStyle=modern
PrivilegesRequired=lowest
DisableWelcomePage=no

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "{cm:CreateDesktopIcon}"; GroupDescription: "{cm:AdditionalIcons}"
Name: "autostart"; Description: "Start e-Solat automatically when Windows boots"; GroupDescription: "System Startup:"

[Files]
; Compiled backend executable (if available)
Source: "bin\esolat-server.exe"; DestDir: "{app}\bin"; Flags: ignoreversion skipifsourcedoesntexist
; Launch scripts
Source: "esolat-kiosk.bat"; DestDir: "{app}"; Flags: ignoreversion
Source: "start-server-hidden.vbs"; DestDir: "{app}"; Flags: ignoreversion
Source: "setup.bat"; DestDir: "{app}"; Flags: ignoreversion
; Core Backend & Web UI & Assets
Source: "..\opt\esolat\*"; DestDir: "{app}\opt\esolat"; Flags: ignoreversion recursesubdirs createallsubdirs
; Documentation
Source: "..\USER_MANUAL.md"; DestDir: "{app}\docs"; Flags: ignoreversion
Source: "..\PANDUAN_PENGGUNA.md"; DestDir: "{app}\docs"; Flags: ignoreversion

[Icons]
Name: "{group}\{#MyAppName}"; Filename: "{app}\esolat-kiosk.bat"; WorkingDir: "{app}"
Name: "{group}\e-Solat Phone Admin"; Filename: "http://localhost:8080/admin"
Name: "{group}\Uninstall {#MyAppName}"; Filename: "{uninstallexe}"
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\esolat-kiosk.bat"; WorkingDir: "{app}"; Tasks: desktopicon
Name: "{autostartup}\e-Solat Server"; Filename: "{app}\start-server-hidden.vbs"; WorkingDir: "{app}"; Tasks: autostart

[Run]
Filename: "{app}\esolat-kiosk.bat"; Description: "{cm:LaunchProgram,{#StringChange(MyAppName, '&', '&&')}}"; Flags: shellexec postinstall skipifsilent
