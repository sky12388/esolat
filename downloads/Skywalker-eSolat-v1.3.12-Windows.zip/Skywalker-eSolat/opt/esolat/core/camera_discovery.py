"""
Auto-Discovery Engine for PTZ, ONVIF & RTSP IP Cameras for Skywalker e-Solat
Zero external pip dependencies (Pure Python 3 standard library).
Features:
1. ONVIF WS-Discovery via UDP multicast (239.255.255.250:3702)
2. Fast parallel RTSP port scanner (Port 554 / 8000 / 37777 / 80)
3. Local V4L2 USB HDMI capture card detection (/dev/video*)
4. Generates standard ready-to-use RTSP URLs for major camera brands (Hikvision, Dahua, Uniview, Generic PTZ)
"""

import os
import re
import sys
import glob
import time
import socket
import uuid
import shutil
import subprocess
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Dict, Any, List, Optional

# ONVIF WS-Discovery Probe Message (XML SOAP over UDP multicast)
WS_DISCOVERY_PROBE = """<?xml version="1.0" encoding="utf-8"?>
<Envelope xmlns:dn="http://www.onvif.org/ver10/network/wsdl"
          xmlns="http://www.w3.org/2003/05/soap-envelope">
  <Header>
    <wsa:MessageID xmlns:wsa="http://schemas.xmlsoap.org/ws/2004/08/addressing">uuid:{msg_id}</wsa:MessageID>
    <wsa:To xmlns:wsa="http://schemas.xmlsoap.org/ws/2004/08/addressing">urn:schemas-xmlsoap-org:ws:2005:04:discovery</wsa:To>
    <wsa:Action xmlns:wsa="http://schemas.xmlsoap.org/ws/2004/08/addressing">http://schemas.xmlsoap.org/ws/2005/04/discovery/Probe</wsa:Action>
  </Header>
  <Body>
    <Probe xmlns="http://schemas.xmlsoap.org/ws/2005/04/discovery">
      <Types>dn:NetworkVideoTransmitter</Types>
    </Probe>
  </Body>
</Envelope>"""

class CameraDiscovery:
    @staticmethod
    def get_local_subnets() -> List[str]:
        """
        Discovers all active local IPv4 subnets
        """
        subnets = []
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.settimeout(0.5)
            s.connect(("8.8.8.8", 80))
            local_ip = s.getsockname()[0]
            s.close()
            parts = local_ip.split(".")
            if len(parts) == 4 and not local_ip.startswith("127."):
                subnets.append(f"{parts[0]}.{parts[1]}.{parts[2]}")
        except Exception:
            pass

        # Also inspect /proc/net/arp or hostname -I
        try:
            if shutil.which("hostname"):
                out = subprocess.check_output(["hostname", "-I"], text=True, timeout=1)
                for ip in out.strip().split():
                    parts = ip.split(".")
                    if len(parts) == 4 and not ip.startswith("127."):
                        sub = f"{parts[0]}.{parts[1]}.{parts[2]}"
                        if sub not in subnets:
                            subnets.append(sub)
        except Exception:
            pass

        if not subnets:
            subnets = ["192.168.1", "192.168.0", "192.168.8"]

        return subnets

    @staticmethod
    def ws_discovery_probe(timeout: float = 1.5) -> List[Dict[str, Any]]:
        """
        Broadcasts ONVIF WS-Discovery probe packet to local multicast group.
        """
        discovered = []
        msg_id = str(uuid.uuid4())
        probe_bytes = WS_DISCOVERY_PROBE.format(msg_id=msg_id).encode("utf-8")

        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
            sock.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 4)
            sock.settimeout(timeout)

            # Send probe to standard ONVIF multicast address
            sock.sendto(probe_bytes, ("239.255.255.250", 3702))

            start_time = time.time()
            while time.time() - start_time < timeout:
                try:
                    data, addr = sock.recvfrom(65535)
                    raw_text = data.decode("utf-8", errors="ignore")
                    ip = addr[0]

                    # Extract XAddrs or service endpoints
                    xaddr_match = re.search(r'<[^>]*XAddrs[^>]*>([^<]+)<\/', raw_text)
                    scopes_match = re.search(r'<[^>]*Scopes[^>]*>([^<]+)<\/', raw_text)

                    vendor = "ONVIF Camera"
                    model = "PTZ / IP Stream"
                    if scopes_match:
                        scopes = scopes_match.group(1)
                        if "hardware/" in scopes:
                            m = re.search(r'hardware/([^ \r\n]+)', scopes)
                            if m: model = m.group(1)
                        if "name/" in scopes:
                            m = re.search(r'name/([^ \r\n]+)', scopes)
                            if m: vendor = m.group(1)

                    xaddrs = xaddr_match.group(1) if xaddr_match else f"http://{ip}/onvif/device_service"

                    if not any(d["ip"] == ip for d in discovered):
                        discovered.append({
                            "ip": ip,
                            "type": "ONVIF PTZ Camera",
                            "vendor": vendor,
                            "model": model,
                            "onvif_service": xaddrs,
                            "discovery_method": "ONVIF WS-Discovery",
                            "rtsp_url": f"rtsp://{ip}:554/stream1",
                            "rtsp_candidates": CameraDiscovery.build_rtsp_candidates(ip)
                        })
                except socket.timeout:
                    break
                except Exception:
                    break
            sock.close()
        except Exception:
            pass

        return discovered

    @staticmethod
    def build_rtsp_candidates(ip: str) -> List[str]:
        """
        Constructs standard RTSP stream URLs for mainstream PTZ & IP cameras.
        """
        return [
            f"rtsp://{ip}:554/stream1",
            f"rtsp://{ip}:554/live/ch0",
            f"rtsp://{ip}:554/h264Preview_01_main",
            f"rtsp://{ip}:554/onvif1",
            f"rtsp://{ip}:554/Streaming/Channels/101",
            f"rtsp://{ip}:554/cam/realmonitor?channel=1&subtype=0",
            f"rtsp://admin:admin@{ip}:554/stream1",
            f"rtsp://admin:password@{ip}:554/live/ch0"
        ]

    @staticmethod
    def scan_rtsp_ports(timeout: float = 0.35, max_workers: int = 50) -> List[Dict[str, Any]]:
        """
        Fast subnet sweep to detect active RTSP stream ports (554, 8000, 37777).
        """
        cameras = []
        subnets = CameraDiscovery.get_local_subnets()

        ips_to_scan = []
        for sub in subnets:
            for i in range(1, 255):
                ips_to_scan.append(f"{sub}.{i}")

        # Add ARP cache entries
        try:
            if Path("/proc/net/arp").exists():
                with open("/proc/net/arp", "r") as f:
                    for line in f.readlines()[1:]:
                        parts = line.split()
                        if len(parts) >= 4 and parts[3] != "00:00:00:00:00:00":
                            if parts[0] not in ips_to_scan and not parts[0].startswith("127."):
                                ips_to_scan.insert(0, parts[0])
        except Exception:
            pass

        def probe_ip(ip: str):
            # Probe RTSP (554), Hikvision (8000), Dahua (37777), Alt (8554, 10554)
            rtsp_ports = [554, 8554, 8000, 37777, 10554]
            detected_port = None

            for port in rtsp_ports:
                try:
                    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                    sock.settimeout(timeout)
                    res = sock.connect_ex((ip, port))
                    sock.close()
                    if res == 0:
                        detected_port = port
                        break
                except Exception:
                    pass

            if detected_port:
                # Try getting hostname
                hostname = ""
                try:
                    hostname = socket.gethostbyaddr(ip)[0]
                except Exception:
                    hostname = ""

                brand = "IP Camera / PTZ Streamer"
                if detected_port == 8000:
                    brand = "Hikvision / DVR PTZ"
                elif detected_port == 37777:
                    brand = "Dahua / Imou PTZ"

                cameras.append({
                    "ip": ip,
                    "port": detected_port,
                    "hostname": hostname,
                    "type": "RTSP / H.264 IP Camera",
                    "vendor": brand,
                    "model": f"Port {detected_port} Live Stream",
                    "discovery_method": "RTSP Port Sweep",
                    "rtsp_url": f"rtsp://{ip}:{detected_port}/stream1" if detected_port == 554 else f"rtsp://{ip}:554/live/ch0",
                    "rtsp_candidates": CameraDiscovery.build_rtsp_candidates(ip)
                })

        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            executor.map(probe_ip, ips_to_scan)

        return cameras

    @staticmethod
    def scan_usb_video_devices() -> List[Dict[str, Any]]:
        """
        Detects local USB HDMI capture cards and webcams (/dev/video*)
        """
        usb_cameras = []
        for dev_path in sorted(glob.glob("/dev/video*")):
            dev_num = dev_path.replace("/dev/video", "")
            sysfs_name = f"/sys/class/video4linux/video{dev_num}/name"
            name = "USB Video Device"
            if Path(sysfs_name).exists():
                try:
                    with open(sysfs_name, "r") as f:
                        name = f.read().strip()
                except Exception:
                    pass

            is_capture = any(k in name.lower() for k in ["hdmi", "capture", "cam", "video", "usb", "uvc"])
            if is_capture:
                usb_cameras.append({
                    "ip": "localhost",
                    "device_path": dev_path,
                    "type": "USB HDMI Capture / Local Camera",
                    "vendor": name,
                    "model": dev_path,
                    "discovery_method": "V4L2 Local Capture",
                    "rtsp_url": f"v4l2://{dev_path}",
                    "rtsp_candidates": [f"v4l2://{dev_path}", dev_path]
                })
        return usb_cameras

    @staticmethod
    def discover_all_cameras() -> Dict[str, Any]:
        """
        Runs comprehensive discovery: ONVIF WS-Discovery + RTSP Port Sweep + USB Capture
        """
        results = []
        seen_ips = set()

        # 1. ONVIF WS-Discovery (fast broadcast)
        onvif_cams = CameraDiscovery.ws_discovery_probe(timeout=1.2)
        for cam in onvif_cams:
            if cam["ip"] not in seen_ips:
                seen_ips.add(cam["ip"])
                results.append(cam)

        # 2. RTSP Subnet Sweep
        rtsp_cams = CameraDiscovery.scan_rtsp_ports(timeout=0.3, max_workers=50)
        for cam in rtsp_cams:
            if cam["ip"] not in seen_ips:
                seen_ips.add(cam["ip"])
                results.append(cam)

        # 3. Local USB HDMI Grabbers
        usb_cams = CameraDiscovery.scan_usb_video_devices()
        for cam in usb_cams:
            results.append(cam)

        return {
            "success": True,
            "timestamp": int(time.time()),
            "total_found": len(results),
            "cameras": results,
            "local_subnets": CameraDiscovery.get_local_subnets()
        }
