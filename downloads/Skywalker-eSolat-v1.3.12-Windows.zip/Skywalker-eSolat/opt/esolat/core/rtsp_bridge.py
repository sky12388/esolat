"""
Ultra-Low Latency RTSP Bridge & IP Camera Streaming Engine for Skywalker e-Solat
Converts Dahua / Hikvision / ONVIF IP PTZ Camera RTSP streams to WebRTC / MSE / Low-Latency HLS.
Supports go2rtc binary integration (< 300ms lag) with automatic fallback to zero-copy ffmpeg HLS (< 0.8s lag).
"""

import os
import sys
import time
import shutil
import signal
import socket
import urllib.request
import subprocess
import tempfile
import threading
from pathlib import Path
from typing import Dict, Any, Optional

class RTSPBridgeManager:
    def __init__(self, run_dir: Optional[str] = None):
        if run_dir:
            self.run_dir = Path(run_dir)
        elif sys.platform == "win32":
            self.run_dir = Path(tempfile.gettempdir()) / "esolat_stream"
        elif os.path.exists("/dev/shm") and os.access("/dev/shm", os.W_OK):
            self.run_dir = Path("/dev/shm/esolat_stream")
        else:
            self.run_dir = Path(tempfile.gettempdir()) / "esolat_stream"

        try:
            self.run_dir.mkdir(parents=True, exist_ok=True)
        except Exception:
            self.run_dir = Path("./data/esolat_stream")
            self.run_dir.mkdir(parents=True, exist_ok=True)

        self.current_rtsp_url: str = ""
        self.is_running: bool = False
        self.bridge_engine: str = "none" # "go2rtc", "ffmpeg_hls", "none"
        self.process: Optional[subprocess.Popen] = None
        self.lock = threading.Lock()

        # Find go2rtc binary
        self.go2rtc_bin = self._find_go2rtc()
        self.ffmpeg_bin = shutil.which("ffmpeg")

    def _find_go2rtc(self) -> Optional[str]:
        candidates = [
            "/usr/local/bin/go2rtc",
            "/opt/esolat/bin/go2rtc",
            "./bin/go2rtc",
            "./bin/go2rtc.exe",
            "bin/go2rtc.exe",
            "/usr/bin/go2rtc",
            shutil.which("go2rtc"),
            shutil.which("go2rtc.exe")
        ]
        for c in candidates:
            if c and os.path.isfile(c) and (os.access(c, os.X_OK) or sys.platform == "win32"):
                return str(Path(c).resolve())
        return None

    def get_status(self) -> Dict[str, Any]:
        with self.lock:
            running = False
            if self.process and self.process.poll() is None:
                running = True
            else:
                self.is_running = False

            return {
                "is_running": running,
                "engine": self.bridge_engine if running else "none",
                "go2rtc_available": bool(self.go2rtc_bin),
                "ffmpeg_available": bool(self.ffmpeg_bin),
                "rtsp_url": self.current_rtsp_url if running else "",
                "stream_hls_url": "/stream/live.m3u8" if (running and self.bridge_engine == "ffmpeg_hls") else "",
                "stream_webrtc_available": (running and self.bridge_engine == "go2rtc"),
                "go2rtc_port": 1984,
                "run_dir": str(self.run_dir)
            }

    def start_bridge(self, rtsp_url: str) -> Dict[str, Any]:
        """
        Starts the low-latency RTSP streaming bridge.
        Priority: go2rtc (WebRTC / MSE < 300ms) -> ffmpeg (RAM Low-Latency HLS < 800ms)
        """
        rtsp_url = (rtsp_url or "").strip()
        if not rtsp_url:
            return {"success": False, "message": "Pautan RTSP kamera tidak boleh kosong."}

        with self.lock:
            # If already running with same URL, return success
            if self.is_running and self.process and self.process.poll() is None and self.current_rtsp_url == rtsp_url:
                return {
                    "success": True,
                    "engine": self.bridge_engine,
                    "message": f"Bridge {self.bridge_engine} sedang beroperasi."
                }

            self._stop_bridge_unlocked()
            self.current_rtsp_url = rtsp_url

            # 1. Try go2rtc if installed
            if self.go2rtc_bin:
                try:
                    cfg_path = self.run_dir / "go2rtc.yaml"
                    cfg_content = f"""
api:
  listen: ":1984"
webrtc:
  listen: ":8555"
streams:
  kuliah: "{rtsp_url}"
"""
                    with open(cfg_path, "w", encoding="utf-8") as f:
                        f.write(cfg_content.strip())

                    cmd = [self.go2rtc_bin, "-config", str(cfg_path)]
                    self.process = subprocess.Popen(
                        cmd,
                        stdout=subprocess.DEVNULL,
                        stderr=subprocess.DEVNULL,
                        preexec_fn=os.setsid if hasattr(os, "setsid") else None
                    )
                    time.sleep(0.4)
                    if self.process.poll() is None:
                        self.is_running = True
                        self.bridge_engine = "go2rtc"
                        return {
                            "success": True,
                            "engine": "go2rtc",
                            "message": "Bridge ultra-rendah latensi go2rtc (WebRTC/MSE) berjaya diaktifkan."
                        }
                except Exception as e:
                    print(f"[RTSP BRIDGE] go2rtc launch failed, trying ffmpeg: {e}")

            # 2. Fallback to zero-copy Low-Latency HLS via ffmpeg in RAM (/dev/shm)
            if self.ffmpeg_bin:
                try:
                    # Clean previous segments
                    for f in self.run_dir.glob("live*"):
                        try: f.unlink()
                        except Exception: pass

                    m3u8_out = self.run_dir / "live.m3u8"
                    cmd = [
                        self.ffmpeg_bin,
                        "-hide_banner",
                        "-loglevel", "error",
                        "-rtsp_transport", "tcp",
                        "-fflags", "nobuffer+discardcorrupt",
                        "-flags", "low_delay",
                        "-analyzeduration", "1000000",
                        "-probesize", "1000000",
                        "-i", rtsp_url,
                        "-c:v", "copy",
                        "-an",
                        "-f", "hls",
                        "-hls_time", "1",
                        "-hls_list_size", "3",
                        "-hls_flags", "delete_segments+split_by_time",
                        "-hls_segment_type", "mpegts",
                        "-hls_segment_filename", str(self.run_dir / "live_%03d.ts"),
                        str(m3u8_out)
                    ]
                    self.process = subprocess.Popen(
                        cmd,
                        stdout=subprocess.DEVNULL,
                        stderr=subprocess.DEVNULL,
                        preexec_fn=os.setsid if hasattr(os, "setsid") else None
                    )
                    # Wait up to 2 seconds for initial m3u8 playlist creation
                    start_t = time.time()
                    while time.time() - start_t < 2.5:
                        if m3u8_out.exists() and m3u8_out.stat().st_size > 0:
                            break
                        time.sleep(0.2)

                    if self.process.poll() is None:
                        self.is_running = True
                        self.bridge_engine = "ffmpeg_hls"
                        return {
                            "success": True,
                            "engine": "ffmpeg_hls",
                            "message": "Bridge strim lancar ffmpeg (Low-Latency HLS) berjaya diaktifkan."
                        }
                    else:
                        return {"success": False, "message": "Gagal menyambung ke RTSP kamera. Sila semak IP & kata laluan."}
                except Exception as e:
                    return {"success": False, "message": f"Ralat ffmpeg bridge: {str(e)}"}

            return {"success": False, "message": "Tiada enjin bridge (go2rtc / ffmpeg) ditemui pada sistem."}

    def stop_bridge(self) -> Dict[str, Any]:
        with self.lock:
            return self._stop_bridge_unlocked()

    def _stop_bridge_unlocked(self) -> Dict[str, Any]:
        if self.process:
            try:
                if hasattr(os, "killpg") and hasattr(os, "getpgid"):
                    os.killpg(os.getpgid(self.process.pid), signal.SIGTERM)
                else:
                    self.process.terminate()
                self.process.wait(timeout=1.5)
            except Exception:
                try:
                    self.process.kill()
                except Exception:
                    pass
            self.process = None

        self.is_running = False
        self.bridge_engine = "none"
        self.current_rtsp_url = ""
        return {"success": True, "message": "Bridge RTSP telah dimatikan."}

    def test_connection(self, ip: str, port: int = 554, timeout: float = 2.0) -> Dict[str, Any]:
        """
        Quick TCP socket handshake test on camera RTSP port
        """
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(timeout)
            res = s.connect_ex((ip, int(port)))
            s.close()
            if res == 0:
                return {
                    "success": True,
                    "reachable": True,
                    "message": f"Port {port} pada kamera {ip} sedia dan menerima sambungan."
                }
            else:
                return {
                    "success": False,
                    "reachable": False,
                    "message": f"Port {port} pada IP {ip} tidak memberi respon (Ralat kod: {res})."
                }
        except Exception as e:
            return {"success": False, "reachable": False, "message": f"Ralat rangkaian: {str(e)}"}
