"""
Prayer State Engine & Signage Life-Cycle Controller
Calculates prayer state machine:
NORMAL -> PRE_ADHAN -> ADHAN -> DOA_ADHAN -> IQAMAH -> SOLAT -> NORMAL
Handles licensing overrides (LOCKED screen on trial expiration).
"""

import time
from datetime import datetime, timedelta
from typing import Dict, Any, Optional

MALAY_DAYS = ["Isnin", "Selasa", "Rabu", "Khamis", "Jumaat", "Sabtu", "Ahad"]
MALAY_MONTHS = ["", "Januari", "Februari", "Mac", "April", "Mei", "Jun", "Julai", "Ogos", "September", "Oktober", "November", "Disember"]

def format_malay_date(dt: datetime) -> str:
    day_name = MALAY_DAYS[dt.weekday()]
    month_name = MALAY_MONTHS[dt.month]
    return f"{day_name}, {dt.day} {month_name} {dt.year}"

class PrayerScheduler:
    def __init__(self, db, jakim_mgr, audio_mgr, license_mgr):
        self.db = db
        self.jakim_mgr = jakim_mgr
        self.audio_mgr = audio_mgr
        self.license_mgr = license_mgr

        # Simulation override state for testing
        self.test_override: Optional[Dict[str, Any]] = None
        self.test_override_expiry: float = 0.0

        # Audio trigger trackers to avoid replaying within the same prayer window
        self.last_audio_played_prayer = None
        self.last_audio_played_state = None

    def set_test_mode(self, state: str, prayer_name: str = "Zohor", duration_sec: int = 30):
        """
        Allows admin to trigger a state preview (ADHAN, IQAMAH, SOLAT, LOCKED) for testing.
        """
        self.test_override = {
            "state": state.upper(),
            "prayer": prayer_name,
            "seconds_left": duration_sec,
            "total_duration": duration_sec
        }
        self.test_override_expiry = time.time() + duration_sec

    def clear_test_mode(self):
        self.test_override = None
        self.test_override_expiry = 0.0

    def trigger_immediate_iqamah(self, prayer_name: Optional[str] = None) -> Dict[str, Any]:
        """
        Immediately cancels remaining Iqamah countdown and transitions directly into SOLAT mode.
        """
        settings = self.db.get_all_settings()
        solat_duration_sec = int(settings.get("solat_duration", 12)) * 60
        target_prayer = prayer_name or (self.test_override.get("prayer") if self.test_override else None)
        
        if not target_prayer:
            signage = self.get_current_signage_state()
            target_prayer = signage.get("active_prayer") or signage.get("current_prayer") or "Solat"

        self.set_test_mode("SOLAT", target_prayer, solat_duration_sec)
        
        # Trigger prompt audio for Rapatkan Saf / Mod Solat
        try:
            self.audio_mgr.play_sound("beep.wav")
        except Exception:
            pass

        return {
            "success": True,
            "state": "SOLAT",
            "prayer": target_prayer,
            "duration_seconds": solat_duration_sec,
            "message": "Detik undur dibatalkan. Skrin beralih ke Mod Solat serta-merta."
        }

    def _parse_time_today(self, time_str: Any, offset_min: int = 0, default_str: str = "06:00:00") -> datetime:
        """
        Parses HH:MM:SS or HH:MM string into today's datetime object with offset.
        Guarantees fallback to default_str if input is empty, None, or malformed.
        """
        now = datetime.now()
        raw = str(time_str or "").strip()
        if not raw or ":" not in raw:
            raw = default_str

        try:
            parts = [int(p) for p in raw.split(":")]
            h = parts[0]
            m = parts[1] if len(parts) > 1 else 0
            s = parts[2] if len(parts) > 2 else 0
            base_dt = now.replace(hour=h % 24, minute=m % 60, second=s % 60, microsecond=0)
        except Exception:
            parts = [int(p) for p in default_str.split(":")]
            base_dt = now.replace(hour=parts[0], minute=parts[1], second=parts[2] if len(parts) > 2 else 0, microsecond=0)

        if offset_min != 0:
            base_dt += timedelta(minutes=offset_min)
        return base_dt

    def get_current_signage_state(self) -> Dict[str, Any]:
        """
        Computes the complete real-time state for the Kiosk Display & Admin Panel.
        """
        now_dt = datetime.now()
        now_ts = time.time()

        # 1. License Check
        lic_status = self.license_mgr.get_full_system_status()
        if not lic_status.get("is_unlocked", False):
            return {
                "state": "LOCKED",
                "message": lic_status.get("message", "Trial Expired"),
                "hwid": lic_status.get("hwid"),
                "license_status": lic_status,
                "current_time": now_dt.strftime("%H:%M:%S"),
                "current_date": format_malay_date(now_dt)
            }

        # 2. Check Test Override
        if self.test_override and now_ts < self.test_override_expiry:
            sec_left = int(self.test_override_expiry - now_ts)
            return {
                "state": self.test_override["state"],
                "active_prayer": self.test_override["prayer"],
                "countdown_seconds": sec_left,
                "total_duration": self.test_override["total_duration"],
                "is_test_preview": True,
                "license_status": lic_status,
                "current_time": now_dt.strftime("%H:%M:%S"),
                "current_date": format_malay_date(now_dt)
            }
        else:
            self.test_override = None

        # 3. Retrieve settings and prayer times
        settings = self.db.get_all_settings()
        zone = str(settings.get("jakim_zone") or "SGR01").strip().upper()
        prayer_data = self.jakim_mgr.get_today_prayer_times(zone, now_dt) or {}

        # Offsets
        offsets = {
            "imsak": int(settings.get("offset_imsak", 0)),
            "subuh": int(settings.get("offset_subuh", 0)),
            "syuruk": int(settings.get("offset_syuruk", 0)),
            "zohor": int(settings.get("offset_zohor", 0)),
            "asar": int(settings.get("offset_asar", 0)),
            "maghrib": int(settings.get("offset_maghrib", 0)),
            "isyak": int(settings.get("offset_isyak", 0))
        }

        # Safe extraction supporting all alias key conventions
        imsak_raw = prayer_data.get("imsak") or prayer_data.get("Imsak") or "05:40:00"
        subuh_raw = prayer_data.get("fajr") or prayer_data.get("subuh") or prayer_data.get("Subuh") or prayer_data.get("Fajr") or "05:50:00"
        syuruk_raw = prayer_data.get("syuruk") or prayer_data.get("sunrise") or prayer_data.get("Syuruk") or "07:00:00"
        zohor_raw = prayer_data.get("dhuhr") or prayer_data.get("zohor") or prayer_data.get("dohor") or prayer_data.get("Zohor") or prayer_data.get("Dhuhr") or "13:10:00"
        asar_raw = prayer_data.get("asr") or prayer_data.get("asar") or prayer_data.get("Asar") or prayer_data.get("Asr") or "16:20:00"
        maghrib_raw = prayer_data.get("maghrib") or prayer_data.get("Maghrib") or "19:15:00"
        isyak_raw = prayer_data.get("isha") or prayer_data.get("isyak") or prayer_data.get("Isyak") or prayer_data.get("Isha") or "20:25:00"

        # Parse schedule into datetimes safely
        schedule = [
            ("Imsak", self._parse_time_today(imsak_raw, offsets["imsak"], default_str="05:40:00"), False),
            ("Subuh", self._parse_time_today(subuh_raw, offsets["subuh"], default_str="05:50:00"), True),
            ("Syuruk", self._parse_time_today(syuruk_raw, offsets["syuruk"], default_str="07:00:00"), False),
            ("Zohor", self._parse_time_today(zohor_raw, offsets["zohor"], default_str="13:10:00"), True),
            ("Asar", self._parse_time_today(asar_raw, offsets["asar"], default_str="16:20:00"), True),
            ("Maghrib", self._parse_time_today(maghrib_raw, offsets["maghrib"], default_str="19:15:00"), True),
            ("Isyak", self._parse_time_today(isyak_raw, offsets["isyak"], default_str="20:25:00"), True)
        ]

        # Parameters
        pre_lead_sec = int(settings.get("pre_adhan_lead", 3)) * 60
        adhan_duration_sec = 180  # 3 minutes for Adhan
        doa_duration_sec = 60     # 1 minute for Doa Selepas Adhan
        solat_duration_sec = int(settings.get("solat_duration", 12)) * 60

        # Pre-Azan Quran Tarhim configuration
        quran_enabled = settings.get("quran_pre_azan_enabled", "1") == "1"
        quran_lead_min = int(settings.get("quran_pre_azan_lead_minutes", 10))
        quran_lead_sec = quran_lead_min * 60
        quran_mode = settings.get("quran_pre_azan_mode", "random")
        quran_file = settings.get("quran_pre_azan_file", "")
        quran_vol = int(settings.get("quran_pre_azan_volume", 70))

        try:
            allowed_quran_prayers = json.loads(settings.get("quran_pre_azan_prayers", '["subuh","zohor","asar","maghrib","isyak","jumaat"]'))
        except Exception:
            allowed_quran_prayers = ["subuh", "zohor", "asar", "maghrib", "isyak", "jumaat"]

        is_friday = (now_dt.weekday() == 4)

        current_state = "NORMAL"
        active_prayer = None
        countdown_sec = 0
        total_duration = 0

        # Check solat windows (Subuh, Zohor, Asar, Maghrib, Isyak)
        solat_prayers = [p for p in schedule if p[2]]

        for name, p_dt, _ in solat_prayers:
            key_name = name.lower()
            if key_name == "zohor" and is_friday:
                iqamah_min = int(settings.get("iqamah_jumaat", 0))
            else:
                default_mins = {"subuh": 10, "zohor": 7, "asar": 7, "maghrib": 5, "isyak": 7}
                iqamah_min = int(settings.get(f"iqamah_{key_name}", default_mins.get(key_name, 7)))
            iqamah_sec = iqamah_min * 60

            t_pre = p_dt - timedelta(seconds=pre_lead_sec)
            t_quran = p_dt - timedelta(seconds=quran_lead_sec)
            t_adhan_start = p_dt
            t_adhan_end = t_adhan_start + timedelta(seconds=adhan_duration_sec)
            t_doa_end = t_adhan_end + timedelta(seconds=doa_duration_sec)
            t_iqamah_end = t_doa_end + timedelta(seconds=iqamah_sec)
            t_solat_end = t_iqamah_end + timedelta(seconds=solat_duration_sec)

            # Check and trigger Pre-Azan Quran Tilawah / Tarhim playback
            prayer_check_key = "jumaat" if (key_name == "zohor" and is_friday) else key_name
            if quran_enabled and (prayer_check_key in allowed_quran_prayers or key_name in allowed_quran_prayers):
                if t_quran <= now_dt < t_adhan_start:
                    if self.last_audio_played_prayer != (name, "QURAN_PRE_AZAN"):
                        tracks = self.audio_mgr.list_quran_tracks() if hasattr(self.audio_mgr, "list_quran_tracks") else []
                        if tracks:
                            track_to_play = None
                            if quran_mode == "specific" and quran_file:
                                track_to_play = quran_file
                            elif quran_mode == "sequence":
                                p_idx = [p[0] for p in solat_prayers].index(name) if name in [p[0] for p in solat_prayers] else 0
                                idx = (now_dt.day + p_idx) % len(tracks)
                                track_to_play = tracks[idx]["file_name"]
                            else: # random
                                import random
                                track_to_play = random.choice(tracks)["file_name"]

                            if track_to_play and hasattr(self.audio_mgr, "play_quran"):
                                self.audio_mgr.play_quran(track_to_play, volume=quran_vol)
                        self.last_audio_played_prayer = (name, "QURAN_PRE_AZAN")

            if t_pre <= now_dt < t_adhan_start:
                current_state = "PRE_ADHAN"
                active_prayer = name
                countdown_sec = int((t_adhan_start - now_dt).total_seconds())
                total_duration = pre_lead_sec
                # Pre-adhan chime muted to prevent repetitive chime noise
                if self.last_audio_played_prayer != (name, "PRE_ADHAN"):
                    self.last_audio_played_prayer = (name, "PRE_ADHAN")
                break

            elif t_adhan_start <= now_dt < t_adhan_end:
                # Stop Quran recitation immediately before starting Adhan
                if hasattr(self.audio_mgr, "stop_quran"):
                    self.audio_mgr.stop_quran()

                current_state = "ADHAN"
                active_prayer = name
                countdown_sec = int((t_adhan_end - now_dt).total_seconds())
                total_duration = adhan_duration_sec
                # Audio playback is handled exclusively by the TV Kiosk frontend (kiosk.js)
                # to prevent dual playback / audio flanging and overlap.
                if self.last_audio_played_prayer != (name, "ADHAN"):
                    self.last_audio_played_prayer = (name, "ADHAN")
                break

            elif t_adhan_end <= now_dt < t_doa_end:
                current_state = "DOA_ADHAN"
                active_prayer = name
                countdown_sec = int((t_doa_end - now_dt).total_seconds())
                total_duration = doa_duration_sec
                break

            elif t_doa_end <= now_dt < t_iqamah_end:
                current_state = "IQAMAH"
                active_prayer = name
                countdown_sec = int((t_iqamah_end - now_dt).total_seconds())
                total_duration = iqamah_sec
                break

            elif t_iqamah_end <= now_dt < t_solat_end:
                current_state = "SOLAT"
                active_prayer = name
                countdown_sec = int((t_solat_end - now_dt).total_seconds())
                total_duration = solat_duration_sec
                if self.last_audio_played_prayer != (name, "SOLAT"):
                    self.last_audio_played_prayer = (name, "SOLAT")
                break

        # If NORMAL, compute next upcoming FARDHU solat and countdown (exclude Imsak and Syuruk)
        next_prayer = None
        time_to_next_sec = 0

        for name, p_dt, is_solat in solat_prayers:
            if p_dt > now_dt:
                next_prayer = name
                time_to_next_sec = int((p_dt - now_dt).total_seconds())
                break

        # If passed Isyak, next is tomorrow's Subuh
        if not next_prayer:
            next_prayer = "Subuh"
            subuh_dt = [p[1] for p in solat_prayers if p[0] == "Subuh"][0]
            subuh_tomorrow = subuh_dt + timedelta(days=1)
            time_to_next_sec = int((subuh_tomorrow - now_dt).total_seconds())

        # Determine current prayer slot
        current_prayer_slot = "Isyak"
        for i in range(len(schedule)):
            if schedule[i][1] <= now_dt:
                current_prayer_slot = schedule[i][0]

        # Format timetable dictionary for display
        ribbon_times = {
            "Imsak": schedule[0][1].strftime("%H:%M"),
            "Subuh": schedule[1][1].strftime("%H:%M"),
            "Syuruk": schedule[2][1].strftime("%H:%M"),
            "Zohor": schedule[3][1].strftime("%H:%M"),
            "Asar": schedule[4][1].strftime("%H:%M"),
            "Maghrib": schedule[5][1].strftime("%H:%M"),
            "Isyak": schedule[6][1].strftime("%H:%M")
        }

        # Slides
        slides = self.db.get_slides(enabled_only=True)

        # Build complete settings payload for kiosk / admin
        merged_settings = dict(settings)
        merged_settings.update({
            "mosque_name": settings.get("mosque_name", "Surau Darul Taqwa"),
            "mosque_location": settings.get("mosque_location", "Shah Alam"),
            "ticker_text": settings.get("ticker_text", ""),
            "ticker_speed": settings.get("ticker_speed", "normal"),
            "hijri_countdown_enabled": settings.get("hijri_countdown_enabled", "1"),
            "slide_duration": int(settings.get("slide_duration", 10)),
            # Instant Janazah / Takziah Notice Board
            "janazah_enabled": settings.get("janazah_enabled", "0"),
            "janazah_arwah_name": settings.get("janazah_arwah_name", ""),
            "janazah_age": settings.get("janazah_age", ""),
            "janazah_solat_time": settings.get("janazah_solat_time", "Selepas Solat Zohor"),
            "janazah_solat_loc": settings.get("janazah_solat_loc", "Surau Darul Taqwa"),
            "janazah_kubur_loc": settings.get("janazah_kubur_loc", "Tanah Perkuburan Islam Seksyen 21, Shah Alam"),
            # Friday Auto Solat Mode
            "jumaat_khutbah_title": settings.get("jumaat_khutbah_title", "Membina Ummah MADANI Berteraskan Taqwa"),
            "bank_name": settings.get("bank_name", ""),
            "bank_account_no": settings.get("bank_account_no", ""),
            "bank_account_holder": settings.get("bank_account_holder", ""),
            "bank_qr_url": settings.get("bank_qr_url", ""),
            "kiosk_layout": settings.get("kiosk_layout", "full"),
            "kuliah_title": settings.get("kuliah_title", "Kuliah Maghrib Perdana: Menghayati Al-Quran"),
            "kuliah_ustaz": settings.get("kuliah_ustaz", "Ustaz Hj. Ahmad Fauzi"),
            "kuliah_date": settings.get("kuliah_date", "Setiap Hari Rabu (Lepas Maghrib)"),
            # Multi-Source Video, PiP & Layout Settings
            "kiosk_layout_mode": settings.get("kiosk_layout_mode", "fullscreen" if settings.get("media_fullscreen_enabled") == "1" else "split"),
            "pip_mode": settings.get("pip_mode", "none"),
            "media_source_type": settings.get("media_source_type", settings.get("video_source_type", "slides")),
            "media_stream_url": settings.get("media_stream_url", settings.get("video_source_url", "")),
            "active_layout_mode": settings.get("active_layout_mode", "fullscreen_signage"),
            "video_source_type": settings.get("video_source_type", settings.get("media_source_type", "slides")),
            "video_source_url": settings.get("video_source_url", settings.get("media_stream_url", "")),
            "video_audio_enabled": settings.get("video_audio_enabled", "0"),
            "video_volume": int(settings.get("video_volume", 80)),
            "media_fullscreen_enabled": settings.get("media_fullscreen_enabled", "1" if settings.get("kiosk_layout_mode") == "fullscreen" else "0"),
            # Azan MP3 Audio Management
            "audio_azan_subuh": settings.get("audio_azan_subuh") or settings.get("audio_azan_subuh_file", "azan_subuh_special.mp3"),
            "audio_azan_regular": settings.get("audio_azan_regular") or settings.get("audio_azan_standard_file", "azan_mekah.mp3"),
            "audio_volume": int(settings.get("audio_volume", settings.get("audio_azan_volume", 80))),
            "audio_azan_subuh_file": settings.get("audio_azan_subuh") or settings.get("audio_azan_subuh_file", "azan_subuh_special.mp3"),
            "audio_azan_standard_file": settings.get("audio_azan_regular") or settings.get("audio_azan_standard_file", "azan_mekah.mp3"),
            "audio_azan_volume": int(settings.get("audio_volume", settings.get("audio_azan_volume", 80))),
            # Pre-Azan Quran Recitation Settings
            "quran_pre_azan_enabled": settings.get("quran_pre_azan_enabled", "1"),
            "quran_pre_azan_lead_minutes": int(settings.get("quran_pre_azan_lead_minutes", 10)),
            "quran_pre_azan_mode": settings.get("quran_pre_azan_mode", "random"),
            "quran_pre_azan_file": settings.get("quran_pre_azan_file", ""),
            "quran_pre_azan_prayers": settings.get("quran_pre_azan_prayers", '["subuh","zohor","asar","maghrib","isyak","jumaat"]'),
            "quran_pre_azan_volume": int(settings.get("quran_pre_azan_volume", 70)),
            # Interactive Drag & Resize Custom Canvas Layout
            "custom_layout_enabled": settings.get("custom_layout_enabled", "0"),
            "layout_edit_mode": settings.get("layout_edit_mode", "0"),
            "custom_layout_zones": self.db.get_custom_layout_zones() if hasattr(self.db, "get_custom_layout_zones") else {
                "media_stage": {"x": 30, "y": 270, "width": 1250, "height": 730},
                "sidebar_takwim": {"x": 1300, "y": 270, "width": 590, "height": 730},
                "pip_overlay": {"x": 1340, "y": 650, "width": 540, "height": 320}
            }
        })

        return {
            "state": current_state,
            "active_prayer": active_prayer,
            "countdown_seconds": countdown_sec,
            "total_duration": total_duration,
            "current_prayer_slot": current_prayer_slot,
            "next_prayer": next_prayer,
            "time_to_next_seconds": time_to_next_sec,
            "ribbon_times": ribbon_times,
            "hijri_date": prayer_data.get("hijri", "1448-04-16"),
            "gregorian_date": format_malay_date(now_dt),
            "current_time": now_dt.strftime("%H:%M:%S"),
            "settings": merged_settings,
            "quran_status": {
                "is_playing": self.audio_mgr.is_quran_playing() if hasattr(self.audio_mgr, "is_quran_playing") else False,
                "current_track": getattr(self.audio_mgr, "current_quran_track", None),
                "pre_azan_enabled": settings.get("quran_pre_azan_enabled", "1") == "1"
            },
            "slides": slides,
            "license_status": lic_status
        }
