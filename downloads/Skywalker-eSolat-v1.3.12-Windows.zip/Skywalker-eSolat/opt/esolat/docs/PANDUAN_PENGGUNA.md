# 📖 Panduan Pengguna Sistem e-Solat Signage Surau (End-User Manual)

**Untuk Kegunaan**: Jawatankuasa Masjid & Surau (Imam, Bilal, Setiausaha, Bendahari, Siak)  
**Penyedia Rasmi**: Skywalker Consortium (No. Pendaftaran SSM: AS0463209-A / 202303102311)  
**Versi Sistem**: 1.0.0 (Komersial)  
**Akses Panel Kawalan**: Menerusi pelayar telefon pintar pada rangkaian Wi-Fi Surau  
**Talian Bantuan & Sokongan**: +6011-1871 2388 | skywalker.co@proton.me  

---

## 🌟 1. Pengenalan Ringkas

Sistem e-Solat Signage Surau adalah sistem paparan waktu solat dan hebahan pintar digital yang dipaparkan pada skrin TV di dewan solat. Sistem ini beroperasi secara automatik 24 jam sehari, 7 hari seminggu.

Semua pengurusan surau—seperti menukar zon waktu solat, menetapkan masa kiraan Iqamah, memuat naik poster kuliah, dan menyunting teks pengumuman bergerak—boleh dilakukan terus **menggunakan telefon pintar anda** tanpa perlu memasang sebarang aplikasi tambahan!

```text
┌───────────────────────┐             Wi-Fi Surau             ┌───────────────────────┐
│     Telefon Pintar    │ ◄─────────────────────────────────► │     Komputer Kiosk    │
│  (Pelayar Web Chrome/ │                                     │  (Mengawal Paparan TV │
│   Safari di Telefon)  │                                     │     Dewan Solat)      │
└───────────────────────┘                                     └───────────────────────┘
```

---

## 📺 2. Bagaimana Paparan TV Berfungsi

Apabila komputer dan TV surau dihidupkan, paparan TV akan memaparkan:
1. **Jam Digital Masa Nyata**: Tepat mengikut saat beserta tarikh Masihi dan tarikh Hijriah.
2. **Jadual Waktu Solat Rasmi**: 7 waktu (Imsak, Subuh, Syuruk, Zohor, Asar, Maghrib, Isyak). Waktu solat yang sedang aktif akan bercahaya warna hijau/emas.
3. **Kiraan Undur ke Waktu Solat Seterusnya**: Contohnya `- 00:14:22` menuju Zohor.
4. **Putaran Poster & Slaid Pengumuman**: Poster kuliah mingguan, hadis harian, peringatan adab, dan nombor akaun tabung surau.
5. **Teks Hebahan Bergerak (Running Ticker)**: Mesej pengumuman bergerak di bahagian paling bawah skrin.

### Kitaran Automatik Semasa Waktu Solat:
- **3 Minit Sebelum Azan (Pra-Azan)**: TV mengeluarkan nada chime lembut dan memaparkan peringatan masuk waktu solat.
- **Waktu Azan Tiba**: TV memaparkan kaligrafi *"Allahu Akbar"* skrin penuh berserta alunan Azan MP3 (atau nada panggilan untuk Bilal bertugas).
- **Selepas Azan**: Paparan Doa Selepas Azan berserta terjemahan.
- **Kiraan Undur Iqamah**: Paparan digit masa undur yang besar (contoh: `10:00` hingga `00:00`) agar seluruh jemaah tahu bila solat akan bermula.
- **Mod Solat**: Paparan *"Sila Rapatkan Saf & Matikan Telefon Bimbit"*, kemudian skrin menjadi malap/tenang agar tidak menyilaukan jemaah semasa solat.

---

## 📱 3. Cara Membuka Panel Kawalan di Telefon Pintar

Anda boleh menguruskan sistem ini menggunakan mana-mana telefon pintar (Android atau iPhone) yang disambungkan ke Wi-Fi surau.

### Langkah 1: Sambung ke Wi-Fi Surau
Pastikan Wi-Fi telefon anda disambungkan ke rangkaian Wi-Fi yang sama dengan komputer TV surau.

### Langkah 2: Buka Pelayar Web
Buka aplikasi **Google Chrome** (Android) atau **Safari** (iPhone) di telefon anda.

### Langkah 3: Masukkan Alamat IP Surau
Taip alamat IP komputer surau diikuti dengan `:8080/admin` pada ruangan carian laman web:
```text
http://<IP_KOMPUTER_SURAU>:8080/admin
Contoh: http://192.168.1.104:8080/admin
```
*(Tip: Sila simpan alamat ini sebagai **Bookmark** atau tambah ke **Home Screen** telefon anda untuk kemudahan masa hadapan).*

---

## 🔐 4. Log Masuk & Keselamatan

### Log Masuk Kali Pertama
1. Masukkan maklumat lalai:
   - **Nama Pengguna**: `admin`
   - **Kata Laluan**: `admin@surau`
2. Tekan butang **Log Masuk**.

### Menukar Kata Laluan (Wajib Pada Kali Pertama)
Demi keselamatan surau anda daripada digodam, sistem mewajibkan penukaran kata laluan pada kali pertama log masuk:
1. Kotak dialog amaran kuning akan terpapar secara automatik.
2. Masukkan **Kata Laluan Baharu** (sekurang-kurangnya 6 aksara).
3. Masukkan semula kata laluan tersebut di ruangan **Sahkan Kata Laluan Baharu**.
4. Tekan **Simpan Kata Laluan Baharu**.
5. Sila catat kata laluan baharu ini dan kongsikan kepada AJK surau yang diamanahkan sahaja.

---

## 📋 5. Panduan Lengkap Mengikut Fungsi

Bahagian bawah panel kawalan telefon pintar mempunyai 6 menu navigasi utama:

```text
┌─────────┬─────────┬─────────┬─────────┬─────────┬─────────┐
│   📊    │   📍    │   🕌    │   🖼️    │   📢    │   🔑    │
│  Utama  │ Takwim  │  Azan   │ Poster  │  Teks   │  Lesen  │
└─────────┴─────────┴─────────┴─────────┴─────────┴─────────┘
```

---

### Menu 1: UTAMA (Status & Ujian Pantas)
Menu ini memaparkan gambaran keseluruhan sistem dan membolehkan anda membuat ujian segera:
- **Status Masa Nyata**: Melihat waktu sekarang, solat seterusnya, dan status lesen sistem.
- **Ujian Output Pembesar Suara**:
  - Tekan **"🔊 Uji Azan (MP3)"** untuk memastikan bunyi azan keluar ke speaker surau.
  - Tekan **"🔊 Uji Azan Subuh"** untuk mendengar azan subuh.
  - Tekan **"🔔 Uji Nada Bilal"** untuk mendengar nada amaran bilal.
  - Tekan **"🎐 Uji Chime Pra-Azan"** untuk menguji chime amaran 3 minit.
- **Simulasi Paparan Skrin TV (30 Saat)**:
  - Tekan mana-mana butang seperti **"Paparan Azan"** atau **"Kiraan Iqamah"** untuk melihat bagaimana ia kelihatan di TV surau selama 30 saat tanpa perlu menunggu waktu solat sebenar tiba.
- **Muat Semula TV Kiosk**: Tekan ikon 🔄 di bahagian atas skrin sekiranya anda mahu memuat semula skrin TV secara serta-merta.

---

### Menu 2: TAKWIM (Zon Solat JAKIM & Pelarasan Minit)
Menu ini digunakan untuk menentukan zon jadual waktu solat surau anda.

#### Cara A: Mengesan Zon Menggunakan GPS Telefon (Paling Mudah)
1. Buka tab **Takwim**.
2. Tekan butang biru **"📍 Kesan Zon Melalui GPS Telefon"**.
3. Sekiranya telefon meminta kebenaran lokasi (*Allow Location Access*), tekan **Allow / Benarkan**.
4. Sistem akan mengira koordinat GPS anda dan memadankan zon JAKIM terdekat (contohnya: `SGR01 - Gombak, Petaling, Shah Alam`).
5. Kotak pengesahan akan muncul, tekan **OK** untuk menyimpan dan memuat turun takwim waktu solat secara automatik.

#### Cara B: Memilih Zon Secara Manual
1. Pilih negeri dan daerah surau anda pada ruangan **"Pilih Zon JAKIM Secara Manual"**.
2. Tekan butang hijau **"🔄 Segerakkan Takwim JAKIM Sekarang"**.
3. Sistem akan memuat turun jadual waktu solat rasmi bagi sebulan penuh dan menyimpannya di dalam memori komputer surau.

#### Melaraskan Minit Waktu Solat (Offset +/-)
Sekiranya Jawatankuasa Fatwa Negeri atau Pejabat Agama Islam Daerah menetapkan penambahan atau pengurangan minit tertentu:
1. Ubah nombor pada kotak waktu solat yang berkaitan (contohnya: `+1` atau `-1`).
2. Tekan butang **"Simpan Pelarasan Waktu"**.

> [!TIP]
> **Adakah e-Solat ini perlukan internet sepanjang masa?**  
> **TIDAK**. Sistem ini menyimpan jadual takwim lengkap di dalam komputer surau. Sekiranya internet terputus, paparan dan azan tetap berfungsi 100% tepat seperti biasa!

---

### Menu 3: AZAN (Mod Azan & Tempoh Iqamah)

#### 1. Tetapan Mod Azan
Bagi setiap waktu (Subuh, Zohor, Asar, Maghrib, Isyak), anda boleh memilih salah satu daripada 3 mod:
- **Auto MP3**: TV akan memainkan alunan rakaman Azan penuh secara automatik melalui pembesar suara.
- **Beep Notifikasi (Untuk Bilal)**: TV hanya mengeluarkan nada "beep" amaran lembut sebanyak dua kali untuk memaklumkan masuk waktu, supaya Bilal bertugas boleh melaungkan azan sendiri di mikrofon surau.
- **Senyap (Paparan Sahaja)**: Tiada sebarang audio dikeluarkan, hanya paparan visual di skrin TV.

#### 2. Tempoh Kiraan Undur Iqamah (Minit)
Anda boleh melaraskan berapa minit masa menunggu antara azan dan iqamah:
- **Subuh**: Contohnya `15` minit (memberi masa jemaah solat sunat fajar).
- **Zohor**: Contohnya `10` minit.
- **Asar**: Contohnya `10` minit.
- **Maghrib**: Contohnya `10` minit.
- **Isyak**: Contohnya `10` minit (boleh ditambah kepada `15` minit semasa bulan Ramadhan).
- **Mod Solat Senyap**: Tempoh skrin dimalapkan semasa solat berjemaah berlangsung (contohnya `12` minit).
3. Tekan butang **"Simpan Tetapan Azan & Iqamah"** selepas membuat perubahan.

---

### Menu 4: POSTER (Memuat Naik Poster & Slaid Hebahan)
Anda boleh memuat naik poster hebahan kuliah, aktiviti gotong-royong, atau gambar program surau terus dari galeri gambar telefon anda!

#### Cara Memuat Naik Poster Baharu:
1. Buka tab **Poster**.
2. Masukkan **Tajuk / Penerangan Slaid** (contoh: *Kuliah Maghrib Ustaz Azhar*).
3. Tekan **"Pilih Fail"** dan pilih gambar daripada **Galeri / Photo Library** telefon anda (format JPG, PNG, atau video MP4).
4. Masukkan **Tempoh Paparan (Saat)** (contoh: `12` saat setiap slaid).
5. Masukkan nombor **Susunan** (contoh: `1` untuk slaid pertama).
6. Tekan butang **"📤 Muat Naik Slaid"**.
7. Poster tersebut akan terus muncul dalam giliran slaid di skrin TV dewan solat!

#### Cara Memadam Poster Lama:
Pada senarai slaid di bawah, tekan ikon tong sampah 🗑️ pada poster yang telah selesai programnya, dan tekan **OK**.

---

### Menu 5: TEKS (Nama Surau, Teks Bergerak & Tabung Infaq)

#### 1. Maklumat Nama Surau:
- Masukkan nama penuh surau pada kotak **Nama Masjid / Surau** (contoh: *Surau Darul Taqwa*).
- Masukkan alamat ringkas pada kotak **Lokasi** (contoh: *Seksyen 7, Shah Alam*).

#### 2. Teks Marquee Pengumuman (Ticker Bawah):
- Tulis sebarang pengumuman untuk jemaah surau pada kotak teks yang disediakan.
- Contoh:  
  *"Selamat datang ke Surau Darul Taqwa. Kuliah Dhuha bulanan akan diadakan pada hari Ahad ini jam 9.00 pagi bersama Ustaz Fauzi. Semua jemaah dijemput hadir. Sila pastikan telefon bimbit dimatikan."*
- Tekan butang **"Simpan Maklumat & Pengumuman"**. Teks di bahagian bawah TV surau akan bertukar serta-merta!

#### 3. Butiran Akaun Bank / Infaq Surau:
- Masukkan **Nama Bank** (contoh: *Bank Islam*).
- Masukkan **Nombor Akaun** (contoh: *1202-9010-0456-78*).
- Masukkan **Penama Akaun** (contoh: *Tabung Surau Darul Taqwa*).
- Tekan **"Simpan Maklumat Tabung"**.

---

### Menu 6: LESEN (Status & Pengaktifan Lesen Surau)

Sistem ini didatangkan dengan **Tempoh Percubaan Percuma 7 Hari**. Sebelum tempoh 7 hari tamat, anda perlu memasukkan kunci pengaktifan lesen daripada pembekal.

#### Cara Mengaktifkan Lesen:
1. Buka tab **Lesen**.
2. Anda akan melihat **Machine ID** unik surau anda (contoh: `SURAU-088B-8FF8-5E93`).
3. Tekan butang **"📋 Salin Machine ID"** dan hantarkan kod tersebut kepada pembekal sistem e-Solat anda (melalui WhatsApp/Emel).
4. Pembekal akan memberikan anda satu kod **Activation PIN** (contoh: `PIN-609B-F671-9E26`).
5. Masukkan kod PIN tersebut pada ruangan **Activation PIN**.
6. Tekan butang **"⚡ Sahkan & Aktifkan Lesen"**.
7. Sistem akan memaparkan lencana hijau: `✓ SISTEM AKTIF (PERMANENT)`.
8. Paparan TV kini diaktifkan sepenuhnya untuk kegunaan kekal!

---

### Menu Tambahan: KAMERA & RAKAMAN KULIAH (Siaran Langsung di TV & Rakam MP4)

Sekiranya surau anda mempunyai kamera video HDMI (yang dipasang menghadap mimbar/meja kuliah) dan disambungkan ke komputer melalui kad *USB HDMI Capture*:

```text
[ Telefon Pintar AJK ] 
      │ (Tekan "Papar Kamera di TV" / "Mula Rakam MP4")
      ▼ (Melalui Wi-Fi Surau)
[ Komputer Kiosk e-Solat ] 
      │ 
      ├──► Paparkan video live penceramah di TV Dewan Solat (dengan nama surau & waktu solat)
      └──► Rakam video & audio kuliah sebagai fail MP4 (1080p Full HD)
```

#### Cara Memaparkan Video Penceramah ke TV Surau:
1. Hidupkan kamera video surau.
2. Buka panel admin di telefon anda pada menu **Utama**.
3. Di bahagian kad **Kamera & Rakaman Kuliah**, pastikan penunjuk berwarna hijau: `🟢 Kamera Dikesan`.
4. Tekan butang **"📺 Papar Kamera di TV"**.
5. Skrin TV di dewan solat akan terus memaparkan wajah penceramah secara langsung skrin penuh berserta waktu solat di bahagian bawah!
6. Apabila kuliah selesai, tekan **"⏹️ Hentikan Siaran TV"** untuk kembali semula ke paparan biasa waktu solat dan slaid hebahan.

#### Cara Merakam Kuliah Sebagai Fail MP4:
1. Semasa kuliah bermula, tekan butang merah **"🔴 Mula Rakam MP4"**.
2. Penunjuk akan bertukar menjadi `SEDANG MERAKAM: 00:00` dan mengira masa rakaman secara langsung.
3. Audio penceramah daripada mikrofon surau akan dirakam secara automatik bersama video ke dalam fail MP4 berkualiti tinggi.
4. Apabila kuliah tamat, tekan butang **"⏹️ Hentikan Rakaman"**.
5. Fail rakaman akan tersimpan di dalam komputer surau dan disenaraikan di bawah ruangan **Senarai Rakaman Kuliah (MP4)**.
6. Anda boleh menekan butang muat turun **⬇️** untuk memuat turun fail video MP4 tersebut terus ke dalam telefon anda untuk dikongsikan di WhatsApp jemaah, Facebook, atau YouTube surau!

---

## ❓ 6. Soalan Lazim (FAQ) & Penyelesaian Pantas

### S1: Mengapa skrin TV memaparkan kotak merah "Tempoh Percubaan Tamat"?
**Jawapan**: Tempoh percubaan 7 hari telah berakhir. Dapatkan kod PIN pengaktifan daripada pembekal sistem dengan memberikan Machine ID surau anda, kemudian masukkan PIN tersebut di tab **Lesen** dalam telefon anda.

### S2: Tiada bunyi azan keluar dari pembesar suara surau?
**Jawapan**:
1. Pastikan suis kabel audio 3.5mm atau kabel HDMI telah dipasang dengan kemas ke *Amplifier* surau.
2. Pastikan volume *Master* amplifier surau dibuka pada tahap yang sesuai.
3. Buka tab **Utama** di telefon dan tekan butang **"Uji Azan (MP3)"** untuk menyemak saluran bunyi.
4. Periksa tab **Azan** untuk memastikan waktu tersebut tidak ditetapkan kepada mod *"Senyap"*.

### S3: Gambar poster yang dimuat naik kelihatan senget atau terpotong di TV?
**Jawapan**: Saiz nisbah standard bagi skrin TV adalah **16:9** (resolusi 1920x1080 piksel). Untuk hasil paparan yang paling cantik, sediakan poster kuliah dalam format melintang (*landscape*) 16:9.

### S4: Bagaimana jika saya terlupa kata laluan Admin?
**Jawapan**: Hubungi juruteknik sistem surau atau pembekal anda. Juruteknik boleh menetapkan semula kata laluan kepada `admin@surau` melalui arahan terminal pangkalan data komputer surau.

### S5: Adakah waktu solat akan terganggu sekiranya bekalan elektrik terputus?
**Jawapan**: Komputer surau telah dikonfigurasikan untuk menyala semula secara automatik sebaik sahaja elektrik pulih (*Power-On After Power Failure*). Jam dan waktu solat akan terus tepat kerana sistem mempunyai bateri jam dalaman (RTC) dan simpanan takwim luar talian.

---

## 📞 Maklumat Pembekal & Khidmat Sokongan Rasmi

- **Nama Syarikat**: Skywalker Consortium
- **No. Pendaftaran SSM**: AS0463209-A (202303102311)
- **Alamat Perniagaan (Business Address)**: Block A8-3A, Jalan Selaman, 68000 Ampang, Selangor
- **Emel Rasmi**: skywalker.co@proton.me
- **Talian Sokongan / WhatsApp**: +6011-1871 2388
- **Laman Web Rasmi**: https://sky12388.github.io/esolat/

*Sebarang bantuan teknikal lanjut, pertanyaan pembelian lesen, atau pembaharuan takwim, sila hubungi pihak sokongan teknikal Skywalker Consortium.*
