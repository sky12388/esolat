"""
Robust Multi-Threaded HTTP REST & Static Server for e-Solat System
Pure Python 3 standard library with zero external pip dependencies.
Handles static assets, REST API, JSON payloads, multipart file uploads, and session authentication.
"""

import os
import sys
import json
import time
import uuid
import socket
import shutil
import subprocess
import mimetypes
import urllib.parse
from pathlib import Path
from http.server import HTTPServer, SimpleHTTPRequestHandler
from socketserver import ThreadingMixIn
from typing import Dict, Any, Optional, Tuple

try:
    from core.hwid import get_hardware_id
    from core.jakim_zones import JAKIM_ZONES, find_nearest_zone
    from core.diagnostics import SystemDiagnostics
    from core.camera_discovery import CameraDiscovery
    from core.rtsp_bridge import RTSPBridgeManager
except ImportError:
    from ..core.hwid import get_hardware_id
    from ..core.jakim_zones import JAKIM_ZONES, find_nearest_zone
    from ..core.diagnostics import SystemDiagnostics
    from ..core.camera_discovery import CameraDiscovery
    from ..core.rtsp_bridge import RTSPBridgeManager

class ThreadedHTTPServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True
    allow_reuse_address = True

class EsolatRequestHandler(SimpleHTTPRequestHandler):
    # Class-level shared references injected by runner
    db = None
    jakim_mgr = None
    audio_mgr = None
    license_mgr = None
    scheduler = None
    recorder_mgr = None
    rtsp_bridge_mgr = None
    web_dir = Path("/opt/esolat/web")
    media_dir = Path("/var/lib/esolat/media")
    content_dir = Path("/var/lib/esolat/content/posters")
    active_sessions: Dict[str, float] = {}  # token -> expiry_timestamp
    kiosk_reload_counter = 0

    @classmethod
    def _get_rtsp_bridge_mgr(cls):
        if cls.rtsp_bridge_mgr is None:
            cls.rtsp_bridge_mgr = RTSPBridgeManager()
        return cls.rtsp_bridge_mgr

    def log_message(self, format, *args):
        # Suppress routine GET logging for polling endpoints to keep logs clean
        if "GET /api/state" in args[0]:
            return
        sys.stderr.write(f"[{self.log_date_time_string()}] {args[0]} {args[1]} {args[2]}\n")

    def _send_json(self, data: Any, status: int = 200):
        body = json.dumps(data).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "*")
        self.send_header("Access-Control-Allow-Private-Network", "true")
        self.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
        self.end_headers()
        self.wfile.write(body)

    def _send_error(self, message: str, status: int = 400):
        self._send_json({"error": True, "message": message}, status=status)

    def _read_json_body(self) -> Dict[str, Any]:
        try:
            content_length = int(self.headers.get("Content-Length", 0))
            if content_length > 0:
                raw_bytes = self.rfile.read(content_length)
                return json.loads(raw_bytes.decode("utf-8"))
        except Exception:
            pass
        return {}

    def _get_auth_token(self) -> Optional[str]:
        auth_header = self.headers.get("Authorization", "")
        if auth_header.startswith("Bearer "):
            return auth_header[7:].strip()
        # Fallback to cookie
        cookies = self.headers.get("Cookie", "")
        for c in cookies.split(";"):
            c = c.strip()
            if c.startswith("esolat_session="):
                return c.split("=")[1].strip()
        return None

    def _is_authenticated(self) -> bool:
        token = self._get_auth_token()
        if not token:
            return False
        expiry = self.active_sessions.get(token)
        if expiry and time.time() < expiry:
            # Refresh session
            self.active_sessions[token] = time.time() + 86400 * 7
            return True
        return False

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "*")
        self.send_header("Access-Control-Allow-Private-Network", "true")
        self.send_header("Access-Control-Max-Age", "86400")
        self.end_headers()

    def _get_network_info(self) -> Dict[str, Any]:
        """
        Discovers local IP addresses, network interfaces, hostname, and direct URLs
        for phone / tablet connection by AJK and administrators.
        """
        hostname = socket.gethostname()
        ips = []

        # 1. Probe outbound UDP socket to detect primary LAN IP
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.settimeout(0.5)
            s.connect(("8.8.8.8", 80))
            p_ip = s.getsockname()[0]
            s.close()
            if p_ip and not p_ip.startswith("127."):
                ips.append(p_ip)
        except Exception:
            pass

        # 2. Query Linux hostname -I for all interfaces (Ethernet + Wi-Fi)
        try:
            out = subprocess.check_output(["hostname", "-I"], text=True, timeout=2).strip()
            for ip in out.split():
                ip = ip.strip()
                if ip and ip not in ips and not ip.startswith("127.") and ":" not in ip:
                    ips.append(ip)
        except Exception:
            pass

        if not ips:
            ips = ["127.0.0.1"]

        primary_ip = ips[0]
        port = self.server.server_port if hasattr(self, "server") and hasattr(self.server, "server_port") else 8080

        return {
            "hostname": hostname,
            "primary_ip": primary_ip,
            "all_ips": ips,
            "port": port,
            "admin_url": f"http://{primary_ip}:{port}/admin",
            "kiosk_url": f"http://{primary_ip}:{port}/",
            "admin_urls": [f"http://{ip}:{port}/admin" for ip in ips],
            "kiosk_urls": [f"http://{ip}:{port}/" for ip in ips],
            "mdns_admin_url": f"http://{hostname}.local:{port}/admin"
        }

    @classmethod
    def _format_permission_error_msg(cls, path_str: str) -> str:
        return (
            f"Ralat Kebenaran Fail [Errno 13]: Sistem tidak mempunyai kebenaran menulis ke '{path_str}'. "
            f"Sila jalankan 'sudo ./setup_kiosk.sh' atau 'sudo chmod -R 775 /var/lib/esolat' pada terminal untuk membaiki kebenaran."
        )

    @classmethod
    def _get_writable_dir(cls, primary: Path, fallback_rel: str) -> Path:
        """
        Ensures a writable target directory. If primary (/var/lib/esolat/...)
        fails write probe due to PermissionError [Errno 13], falls back to local directory.
        """
        try:
            primary.mkdir(parents=True, exist_ok=True)
            probe = primary / ".write_probe"
            with open(probe, "w") as f:
                f.write("ok")
            probe.unlink()
            return primary
        except (PermissionError, OSError):
            pass

        candidates = [
            Path(f"./{fallback_rel}").resolve(),
            Path(f"./opt/esolat/{fallback_rel}").resolve(),
            Path(f"./data/{fallback_rel}").resolve()
        ]
        for cand in candidates:
            try:
                cand.mkdir(parents=True, exist_ok=True)
                probe = cand / ".write_probe"
                with open(probe, "w") as f:
                    f.write("ok")
                probe.unlink()
                return cand
            except (PermissionError, OSError):
                continue

        return primary

    @classmethod
    def _get_media_dir(cls) -> Path:
        return cls._get_writable_dir(cls.media_dir, "media")

    @classmethod
    def _get_quran_dir(cls) -> Path:
        media_dir = cls._get_media_dir()
        q_dir = media_dir / "quran"
        try:
            q_dir.mkdir(parents=True, exist_ok=True)
            os.chmod(str(q_dir), 0o777)
        except Exception:
            pass
        return q_dir

    @classmethod
    def _get_posters_dir(cls) -> Path:
        return cls._get_writable_dir(cls.content_dir, "content/posters")

    @classmethod
    def _get_azan_dir(cls) -> Path:
        azan_candidates = [
            cls.web_dir / "kiosk" / "audio" / "azan",
            Path("./opt/esolat/web/kiosk/audio/azan"),
            Path("/opt/esolat/web/kiosk/audio/azan")
        ]
        for c in azan_candidates:
            if c.exists():
                return c
        target = cls.web_dir / "kiosk" / "audio" / "azan"
        try:
            target.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
        return target

    @classmethod
    def _save_qr_image(cls, qr_bytes: bytes, raw_header: str = "") -> Tuple[str, Path]:
        """
        Saves decoded QR image bytes (PNG/JPG/WEBP) to media directory with public read permissions (chmod 644).
        Returns (qr_url, saved_file_path).
        """
        ext = "png"
        if qr_bytes.startswith(b"\xff\xd8\xff") or "image/jpeg" in raw_header or "image/jpg" in raw_header:
            ext = "jpg"
        elif qr_bytes.startswith(b"RIFF") and b"WEBP" in qr_bytes[:16]:
            ext = "webp"
        elif qr_bytes.startswith(b"\x89PNG\r\n\x1a\n") or "image/png" in raw_header:
            ext = "png"

        target_dir = cls._get_media_dir()
        target_dir.mkdir(parents=True, exist_ok=True)
        try:
            os.chmod(target_dir, 0o755)
        except Exception:
            pass

        filename = f"bank_qr.{ext}"
        qr_file = target_dir / filename

        for old_ext in ["png", "jpg", "jpeg", "webp"]:
            if old_ext != ext:
                try:
                    (target_dir / f"bank_qr.{old_ext}").unlink(missing_ok=True)
                except Exception:
                    pass

        with open(qr_file, "wb") as f:
            f.write(qr_bytes)

        try:
            os.chmod(qr_file, 0o644)
        except Exception:
            pass

        cache_buster = int(time.time() * 1000)
        qr_url = f"/media/{filename}?v={cache_buster}"
        return qr_url, qr_file

    @classmethod
    def _save_qr_image_fallback(cls, qr_bytes: bytes, raw_header: str = "") -> Tuple[str, Path]:
        ext = "png"
        if qr_bytes.startswith(b"\xff\xd8\xff") or "image/jpeg" in raw_header or "image/jpg" in raw_header:
            ext = "jpg"
        elif qr_bytes.startswith(b"RIFF") and b"WEBP" in qr_bytes[:16]:
            ext = "webp"
        elif qr_bytes.startswith(b"\x89PNG\r\n\x1a\n") or "image/png" in raw_header:
            ext = "png"

        fallback_dir = Path("./media").resolve()
        fallback_dir.mkdir(parents=True, exist_ok=True)
        try:
            os.chmod(fallback_dir, 0o755)
        except Exception:
            pass

        filename = f"bank_qr.{ext}"
        qr_file = fallback_dir / filename

        for old_ext in ["png", "jpg", "jpeg", "webp"]:
            if old_ext != ext:
                try:
                    (fallback_dir / f"bank_qr.{old_ext}").unlink(missing_ok=True)
                except Exception:
                    pass

        with open(qr_file, "wb") as f:
            f.write(qr_bytes)

        try:
            os.chmod(qr_file, 0o644)
        except Exception:
            pass

        cache_buster = int(time.time() * 1000)
        qr_url = f"/media/{filename}?v={cache_buster}"
        return qr_url, qr_file

    @classmethod
    def _get_x11_env(cls) -> Dict[str, str]:
        env = os.environ.copy()
        env["DISPLAY"] = env.get("DISPLAY") or os.environ.get("DISPLAY", ":0")

        if not env.get("XAUTHORITY"):
            candidates = []
            if os.environ.get("XAUTHORITY"):
                candidates.append(Path(os.environ["XAUTHORITY"]))

            try:
                candidates.append(Path(os.path.expanduser("~/.Xauthority")))
            except Exception:
                pass

            try:
                candidates.append(Path.home() / ".Xauthority")
            except Exception:
                pass

            # Inspect all user homes in /home/
            try:
                home_base = Path("/home")
                if home_base.exists() and home_base.is_dir():
                    for udir in sorted(home_base.iterdir()):
                        if udir.is_dir():
                            candidates.append(udir / ".Xauthority")
            except Exception:
                pass

            # Common user candidates (e.g. ajk, ma, esolat)
            for username in ["ajk", "ma", "esolat", "surau", "admin", os.environ.get("SUDO_USER"), os.environ.get("USER")]:
                if username and username != "root":
                    candidates.append(Path(f"/home/{username}/.Xauthority"))

            for xa in candidates:
                try:
                    if xa.is_file() and os.access(xa, os.R_OK):
                        env["XAUTHORITY"] = str(xa)
                        break
                except (PermissionError, OSError):
                    continue

        return env

    @classmethod
    def _set_maintenance_flag(cls):
        flag_file = Path("/tmp/esolat-maintenance.flag")
        flags = os.O_CREAT | os.O_WRONLY | os.O_TRUNC
        fd = os.open(str(flag_file), flags, 0o666)
        try:
            os.write(fd, b"maintenance_mode=1\n")
        finally:
            os.close(fd)
        try:
            os.chmod(str(flag_file), 0o666)
        except (PermissionError, OSError):
            pass

    @classmethod
    def _clear_maintenance_flag(cls):
        flag_file = Path("/tmp/esolat-maintenance.flag")
        if flag_file.exists():
            flag_file.unlink()

    @classmethod
    def _execute_minimize_or_switch_desktop(cls) -> Dict[str, Any]:
        """
        Executes lightweight backend commands (wmctrl, xdotool) to switch to Debian/MATE Workspace 2
        or minimize / terminate Chromium kiosk to reveal desktop.
        """
        import subprocess
        try:
            cls._set_maintenance_flag()
            env = cls._get_x11_env()
            executed_cmds = []

            # Sequence of workspace switch, desktop focus & window minimize/close commands
            cmd_attempts = [
                ["wmctrl", "-k", "on"],                                    # MATE Show Desktop
                ["wmctrl", "-s", "1"],                                     # Switch to Workspace 2
                ["xdotool", "set_current_desktop", "1"],                   # Xdotool workspace switch
                ["xdotool", "search", "--onlyvisible", "--class", "chromium", "windowminimize"],
                ["xdotool", "key", "Super+d"],                             # Super+D minimize all
                ["xdotool", "search", "--onlyvisible", "--class", "chromium", "windowclose"],
                ["pkill", "-f", "chromium.*--kiosk"],
                ["killall", "-TERM", "chromium"],
                ["killall", "-TERM", "chromium-browser"]
            ]

            success_count = 0
            for cmd in cmd_attempts:
                try:
                    res = subprocess.run(cmd, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=2)
                    if res.returncode == 0:
                        success_count += 1
                        executed_cmds.append(" ".join(cmd))
                except (subprocess.SubprocessError, FileNotFoundError, PermissionError, OSError):
                    continue

            return {
                "success": True,
                "in_maintenance": True,
                "message": "Paparan kiosk diminimakan / ditutup. Desktop kini boleh diakses.",
                "executed_commands": executed_cmds,
                "triggered_count": success_count
            }
        except Exception as e:
            return {
                "success": False,
                "message": str(e)
            }

    @classmethod
    def _execute_exit_kiosk_browser(cls):
        """
        Terminates the foreground Chromium kiosk browser process and reveals MATE desktop.
        """
        import subprocess
        try:
            cls._set_maintenance_flag()
            env = cls._get_x11_env()
            close_cmds = [
                ["xdotool", "search", "--onlyvisible", "--class", "chromium", "windowclose"],
                ["pkill", "-f", "chromium.*--kiosk"],
                ["pkill", "-f", "chromium-browser.*--kiosk"],
                ["killall", "-TERM", "chromium"],
                ["killall", "-TERM", "chromium-browser"],
                ["pkill", "-9", "-f", "chromium.*--kiosk"],
                ["pkill", "-9", "-f", "chromium-browser.*--kiosk"],
                ["wmctrl", "-k", "on"]
            ]
            for cmd in close_cmds:
                try:
                    subprocess.run(cmd, env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=2)
                except Exception:
                    pass
        except Exception:
            pass

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        query = urllib.parse.parse_qs(parsed.query)

        # Static routing
        if path == "/" or path == "/kiosk" or path == "/display" or path == "/display/":
            return self._serve_file(self.web_dir / "kiosk" / "index.html", "text/html")
        elif path == "/admin" or path == "/admin/":
            return self._serve_file(self.web_dir / "admin" / "index.html", "text/html")
        elif path == "/admin/manual" or path == "/manual":
            return self._serve_file(self.web_dir / "admin" / "manual.html", "text/html")
        elif path == "/pricing" or path == "/pakej" or path == "/admin/pricing":
            return self._serve_file(self.web_dir / "admin" / "pricing.html", "text/html")
        elif path.startswith("/kiosk/audio/azan/"):
            rel = path[len("/kiosk/audio/azan/"):]
            return self._serve_file(self._get_azan_dir() / rel)
        elif path.startswith("/assets/"):
            rel = path[len("/assets/"):]
            return self._serve_file(self.web_dir / "assets" / rel)
        elif path.startswith("/content/posters/"):
            rel = path[len("/content/posters/"):]
            return self._serve_file(self._get_posters_dir() / rel)
        elif path.startswith("/content/"):
            rel = path[len("/content/"):]
            return self._serve_file(self._get_posters_dir().parent / rel)
        elif path.startswith("/api/media/"):
            rel = path[len("/api/media/"):]
            return self._serve_file(self._get_media_dir() / rel)
        elif path.startswith("/assets/media/"):
            rel = path[len("/assets/media/"):]
            return self._serve_file(self._get_media_dir() / rel)
        elif path.startswith("/media/recordings/"):
            fname = path[len("/media/recordings/"):]
            if self.recorder_mgr:
                fpath = self.recorder_mgr.get_file_path(fname)
                if fpath and fpath.exists():
                    return self._serve_file(fpath, "video/mp4")
            return self._serve_file(self._get_media_dir() / "recordings" / fname, "video/mp4")
        elif path.startswith("/media/"):
            rel = path[len("/media/"):]
            return self._serve_file(self._get_media_dir() / rel)
        elif path == "/keygen" or path == "/keygen/":
            return self._serve_file(self.web_dir / "keygen" / "index.html", "text/html")
        elif path.startswith("/keygen/"):
            rel = path[len("/keygen/"):]
            return self._serve_file(self.web_dir / "keygen" / rel)
        elif path == "/manifest.json" or path == "/admin/manifest.json":
            return self._serve_file(self.web_dir / "admin" / "manifest.json", "application/manifest+json")
        elif path == "/sw.js" or path == "/admin/sw.js":
            return self._serve_file(self.web_dir / "admin" / "sw.js", "application/javascript", extra_headers={"Service-Worker-Allowed": "/"})
        elif path.startswith("/stream/"):
            fname = path[len("/stream/"):]
            stream_dir = Path("/dev/shm/esolat_stream")
            if not stream_dir.exists():
                stream_dir = Path("/tmp/esolat_stream")
            file_path = stream_dir / fname
            if file_path.exists() and file_path.is_file():
                content_type = "application/vnd.apple.mpegurl" if fname.endswith(".m3u8") else "video/MP2T"
                return self._serve_file(file_path, content_type)
            return self._send_error("Fail strim belum sedia.", code=404)
        elif path.startswith("/kiosk/"):
            rel = path[len("/kiosk/"):]
            return self._serve_file(self.web_dir / "kiosk" / rel)
        elif path.startswith("/admin/"):
            rel = path[len("/admin/"):]
            return self._serve_file(self.web_dir / "admin" / rel)

        # REST API Routes
        if path == "/api/state":
            state = self.scheduler.get_current_signage_state()
            state["kiosk_reload_counter"] = self.kiosk_reload_counter
            state["network"] = self._get_network_info()
            return self._send_json(state)

        elif path == "/api/camera/bridge/status" or path == "/api/kuliah/status":
            mgr = self._get_rtsp_bridge_mgr()
            status = mgr.get_status()
            settings = self.db.get_all_settings() if self.db else {}
            status["camera_ip"] = settings.get("camera_ip", "")
            status["camera_port"] = settings.get("camera_port", "554")
            status["camera_user"] = settings.get("camera_user", "admin")
            status["camera_pass"] = settings.get("camera_pass", "")
            status["camera_subtype"] = settings.get("camera_subtype", "1")
            status["camera_rtsp_url"] = settings.get("camera_rtsp_url", "")
            status["kuliah_live_active"] = (settings.get("kuliah_live_active", "0") == "1")
            status["kuliah_title"] = settings.get("kuliah_title", "Kuliah Maghrib")
            status["kuliah_ustaz"] = settings.get("kuliah_ustaz", "Ustaz Hj. Ahmad Fauzi")
            status["kuliah_kitab"] = settings.get("kuliah_kitab", "Kitab: Bahrul Mazi")
            return self._send_json(status)

        elif path == "/api/settings":
            settings = self.db.get_all_settings()
            # Do not expose password hash in public settings
            settings.pop("admin_password_hash", None)
            settings["network"] = self._get_network_info()
            return self._send_json(settings)

        elif path == "/api/system/network":
            return self._send_json(self._get_network_info())

        elif path == "/api/system/diagnostics" or path == "/api/system/diagnostics/all":
            # Runs full system diagnostics
            diag_res = SystemDiagnostics.run_full_diagnostics(scan_network=True)
            return self._send_json(diag_res)

        elif path == "/api/system/diagnostics/hardware":
            # Instant hardware check (USB, HDMI, Audio, Ports) without network sweep
            diag_res = SystemDiagnostics.run_full_diagnostics(scan_network=False)
            return self._send_json(diag_res)

        elif path == "/api/system/diagnostics/network":
            # Network sweep to detect live IP devices & RTSP cameras
            net_devices = SystemDiagnostics.scan_network_devices()
            return self._send_json({
                "success": True,
                "timestamp": int(time.time()),
                "network_devices": net_devices,
                "total_found": len(net_devices)
            })

        elif path == "/api/zones":
            return self._send_json({
                "zones": JAKIM_ZONES
            })

        elif path == "/api/slides":
            slides = self.db.get_slides()
            return self._send_json({"slides": slides})

        elif path == "/api/ptz/discover" or path == "/api/camera/discover":
            discovery_res = CameraDiscovery.discover_all_cameras()
            return self._send_json(discovery_res)

        elif path == "/api/camera/status":
            if self.recorder_mgr:
                settings = self.db.get_all_settings() if self.db else {}
                rtsp_url = settings.get("camera_rtsp_url", "")
                return self._send_json(self.recorder_mgr.get_status(rtsp_url=rtsp_url))
            return self._send_json({"camera_detected": False, "is_recording": False})

        elif path == "/api/camera/recordings":
            if self.recorder_mgr:
                return self._send_json({"recordings": self.recorder_mgr.list_recordings()})
            return self._send_json({"recordings": []})

        elif path == "/api/camera/storage":
            if self.recorder_mgr:
                return self._send_json({
                    "success": True,
                    "storage_info": self.recorder_mgr.get_storage_info(),
                    "available_drives": self.recorder_mgr.scan_available_drives()
                })
            return self._send_error("Modul rakaman tidak aktif.")

        elif path == "/api/layout/custom":
            zones = self.db.get_custom_layout_zones() if self.db else {}
            settings = self.db.get_all_settings() if self.db else {}
            return self._send_json({
                "success": True,
                "custom_layout_enabled": settings.get("custom_layout_enabled", "0"),
                "layout_edit_mode": settings.get("layout_edit_mode", "0"),
                "zones": zones
            })

        elif path == "/api/audio/list":
            azan_dir = self._get_azan_dir()
            presets_meta = {
                "azan_mekah.mp3": "Azan Makkah Al-Mukarramah",
                "azan_madinah.mp3": "Azan Madinah Al-Munawwarah",
                "azan_mesir.mp3": "Azan Mesir (Syeikh Mustafa Ismail)",
                "azan_aqsa.mp3": "Azan Masjid Al-Aqsa",
                "azan_subuh_special.mp3": "Azan Subuh Khas (As-Salatu Khairum Minan Naum)"
            }
            db_tracks = self.db.get_all_audio_tracks() if self.db else {}
            settings = self.db.get_all_settings() if self.db else {}
            curr_reg = settings.get("audio_azan_regular") or settings.get("audio_azan_standard_file", "azan_mekah.mp3")
            curr_sub = settings.get("audio_azan_subuh") or settings.get("audio_azan_subuh_file", "azan_subuh_special.mp3")
            vol = int(settings.get("audio_volume", settings.get("audio_azan_volume", 80)))

            tracks = []
            if azan_dir.exists():
                for f in sorted(azan_dir.iterdir()):
                    if f.is_file() and f.suffix.lower() in [".mp3", ".wav", ".ogg"]:
                        fname = f.name
                        stat = f.stat()
                        size_bytes = stat.st_size
                        modified_at = int(stat.st_mtime)
                        modified_iso = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(stat.st_mtime))

                        # Check DB custom label first, then presets, then filename
                        db_meta = db_tracks.get(fname, {})
                        label = db_meta.get("label") or presets_meta.get(fname)
                        if not label:
                            clean_stem = f.stem.replace("_", " ").replace("-", " ").title()
                            label = clean_stem

                        is_subuh = ("subuh" in fname.lower()) or bool(db_meta.get("is_subuh"))
                        is_preset = fname in presets_meta
                        is_active_subuh = (fname == curr_sub)
                        is_active_regular = (fname == curr_reg)
                        is_active = is_active_subuh or is_active_regular

                        tracks.append({
                            "file_name": fname,
                            "file_url": f"/kiosk/audio/azan/{fname}",
                            "label": label,
                            "type": f.suffix.lower().lstrip("."),
                            "size_bytes": size_bytes,
                            "modified_at": modified_at,
                            "modified_iso": modified_iso,
                            "is_subuh": is_subuh,
                            "is_preset": is_preset,
                            "is_active_subuh": is_active_subuh,
                            "is_active_regular": is_active_regular,
                            "is_active": is_active
                        })

            return self._send_json({
                "success": True,
                "tracks": tracks,
                "current_regular": curr_reg,
                "current_standard": curr_reg,
                "current_subuh": curr_sub,
                "volume": vol
            })

        elif path == "/api/quran/list":
            quran_dir = self._get_quran_dir()
            tracks = []
            if self.audio_mgr and hasattr(self.audio_mgr, "list_quran_tracks"):
                tracks = self.audio_mgr.list_quran_tracks()
            else:
                if quran_dir.exists():
                    for f in sorted(quran_dir.iterdir()):
                        if f.is_file() and f.suffix.lower() in [".mp3", ".wav", ".ogg", ".m4a", ".aac"]:
                            stat = f.stat()
                            clean_title = f.stem.replace("_", " ").replace("-", " ").title()
                            tracks.append({
                                "file_name": f.name,
                                "title": clean_title,
                                "file_url": f"/media/quran/{f.name}",
                                "type": f.suffix.lower().lstrip("."),
                                "size_bytes": stat.st_size,
                                "size_formatted": f"{stat.st_size / (1024 * 1024):.1f} MB",
                                "modified_at": int(stat.st_mtime)
                            })

            settings = self.db.get_all_settings() if self.db else {}
            is_playing = self.audio_mgr.is_quran_playing() if (self.audio_mgr and hasattr(self.audio_mgr, "is_quran_playing")) else False
            curr_track = getattr(self.audio_mgr, "current_quran_track", None) if self.audio_mgr else None

            return self._send_json({
                "success": True,
                "tracks": tracks,
                "total_tracks": len(tracks),
                "storage_dir": str(quran_dir),
                "is_playing": is_playing,
                "current_track": curr_track,
                "config": {
                    "quran_pre_azan_enabled": settings.get("quran_pre_azan_enabled", "1"),
                    "quran_pre_azan_lead_minutes": int(settings.get("quran_pre_azan_lead_minutes", 10)),
                    "quran_pre_azan_mode": settings.get("quran_pre_azan_mode", "random"),
                    "quran_pre_azan_file": settings.get("quran_pre_azan_file", ""),
                    "quran_pre_azan_prayers": settings.get("quran_pre_azan_prayers", '["subuh","zohor","asar","maghrib","isyak","jumaat"]'),
                    "quran_pre_azan_volume": int(settings.get("quran_pre_azan_volume", 70))
                }
            })

        elif path == "/api/maintenance/status":
            try:
                flag_file = Path("/tmp/esolat-maintenance.flag")
                in_maint = False
                try:
                    in_maint = flag_file.exists()
                except (PermissionError, OSError):
                    in_maint = False
                return self._send_json({
                    "success": True,
                    "in_maintenance": in_maint,
                    "maintenance_flag_path": str(flag_file)
                })
            except Exception as e:
                return self._send_json({"success": False, "message": str(e)}, status=500)

        elif path == "/api/license/status":
            status = self.license_mgr.get_full_system_status()
            return self._send_json(status)

        elif path == "/api/auth/me":
            if self._is_authenticated():
                settings = self.db.get_all_settings()
                return self._send_json({
                    "authenticated": True,
                    "user": settings.get("admin_user", "admin"),
                    "force_password_change": settings.get("force_password_change") == "1"
                })
            else:
                return self._send_json({"authenticated": False}, status=401)

        # Not found
        self._send_error("Not Found", status=404)

    def do_POST(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path

        # 1. Login
        if path == "/api/auth/login":
            data = self._read_json_body()
            username = data.get("username", "admin").strip()
            password = data.get("password", "")
            if isinstance(password, str):
                password = password.strip()
            else:
                password = str(password or "")

            if self.db.verify_admin_login(username, password):
                token = str(uuid.uuid4())
                self.active_sessions[token] = time.time() + 86400 * 7 # 7 days validity
                settings = self.db.get_all_settings()
                return self._send_json({
                    "success": True,
                    "token": token,
                    "force_password_change": settings.get("force_password_change") == "1"
                })
            else:
                return self._send_error("Nama pengguna atau kata laluan tidak sah.", status=401)

        # 1b. Fast Action / Emergency Iqamah Now Trigger
        elif path in ("/api/iqamah/trigger", "/api/iqamah/now", "/api/prayer/iqamah-now"):
            data = self._read_json_body() if (self.headers.get("Content-Length") and int(self.headers.get("Content-Length", 0)) > 0) else {}
            prayer_name = data.get("prayer") or data.get("prayer_name")
            if self.scheduler:
                res = self.scheduler.trigger_immediate_iqamah(prayer_name)
            else:
                res = {"success": True, "state": "SOLAT", "message": "Iqamah beralih ke mod solat."}
            return self._send_json(res)

        # 2. GPS Zone Match (Public / Admin helper)
        elif path == "/api/zones/match_gps":
            data = self._read_json_body()
            try:
                lat = float(data.get("lat"))
                lon = float(data.get("lon"))
                nearest_zone, distance_km = find_nearest_zone(lat, lon)
                return self._send_json({
                    "matched_zone": nearest_zone,
                    "distance_km": distance_km
                })
            except Exception as e:
                return self._send_error(f"Koordinat GPS tidak sah: {e}")

        # 3. Custom Canvas Drag & Resize Layout Update (Kiosk & Admin)
        elif path == "/api/layout/custom":
            data = self._read_json_body()
            updates = {}
            if "custom_layout_enabled" in data:
                updates["custom_layout_enabled"] = str(data["custom_layout_enabled"])
            if "layout_edit_mode" in data:
                updates["layout_edit_mode"] = str(data["layout_edit_mode"])

            if "zone_id" in data:
                zone_id = str(data.get("zone_id")).strip()
                x = int(data.get("x", 0))
                y = int(data.get("y", 0))
                w = int(data.get("width", 300))
                h = int(data.get("height", 200))
                if self.db:
                    self.db.update_custom_layout_zone(zone_id, x, y, w, h)
            elif "zones" in data and isinstance(data["zones"], dict):
                if self.db:
                    self.db.save_all_custom_layout_zones(data["zones"])

            if updates and self.db:
                self.db.update_settings(updates)

            zones = self.db.get_custom_layout_zones() if self.db else {}
            settings = self.db.get_all_settings() if self.db else {}
            return self._send_json({
                "success": True,
                "message": "Geometri susun atur layout berjaya disimpan.",
                "zones": zones,
                "custom_layout_enabled": settings.get("custom_layout_enabled", "1"),
                "layout_edit_mode": settings.get("layout_edit_mode", "0")
            })

        # 4. Reset Custom Canvas Layout to Default Preset (Kiosk & Admin)
        elif path == "/api/layout/reset":
            zones = self.db.reset_custom_layout() if self.db else {}
            return self._send_json({
                "success": True,
                "message": "Susun atur layout berjaya direset ke konfigurasi asal.",
                "zones": zones,
                "custom_layout_enabled": "0",
                "layout_edit_mode": "0"
            })

        # 5. Maintenance: Verify PIN (Kiosk / Admin)
        elif path == "/api/maintenance/verify_pin":
            data = self._read_json_body()
            pin = str(data.get("pin", "")).strip()
            if self.db and self.db.verify_maintenance_pin(pin):
                return self._send_json({
                    "success": True,
                    "message": "Pengesahan PIN berjaya."
                })
            else:
                return self._send_json({
                    "success": False,
                    "error": True,
                    "message": "PIN keselamatan tidak tepat. Sila cuba lagi."
                }, status=401)

        # 6. Maintenance: Execute Action (Kiosk / Admin)
        elif path == "/api/maintenance/action":
            try:
                data = self._read_json_body()
                pin = str(data.get("pin", "")).strip()
                action = str(data.get("action", "")).strip().lower()

                if not (self.db and self.db.verify_maintenance_pin(pin)):
                    return self._send_json({
                        "success": False,
                        "error": True,
                        "message": "PIN keselamatan tidak sah atau tidak tepat."
                    }, status=401)

                if action in ["minimize", "switch_desktop", "switch_workspace"]:
                    res = self._execute_minimize_or_switch_desktop()
                    if not res.get("success"):
                        return self._send_json({"success": False, "message": res.get("message", "Ralat sistem")}, status=500)
                    return self._send_json(res)

                elif action in ["exit_loop", "exit_kiosk", "enable_maintenance"]:
                    try:
                        self._set_maintenance_flag()
                        self._execute_exit_kiosk_browser()
                        return self._send_json({
                            "success": True,
                            "in_maintenance": True,
                            "message": "Mod penyelenggaraan aktif. Flag /tmp/esolat-maintenance.flag dicipta dan gelung kiosk dihentikan."
                        })
                    except Exception as e:
                        return self._send_json({"success": False, "message": str(e)}, status=500)

                elif action in ["resume_loop", "resume_kiosk", "disable_maintenance"]:
                    try:
                        self._clear_maintenance_flag()
                        return self._send_json({
                            "success": True,
                            "in_maintenance": False,
                            "message": "Flag penyelenggaraan dipadam. Gelung kiosk kembali beroperasi."
                        })
                    except Exception as e:
                        return self._send_json({"success": False, "message": str(e)}, status=500)

                elif action in ["reload", "reload_kiosk"]:
                    EsolatRequestHandler.kiosk_reload_counter += 1
                    return self._send_json({
                        "success": True,
                        "message": "Arahan muat semula kiosk dihantar."
                    })

                else:
                    return self._send_json({"success": False, "message": f"Tindakan penyelenggaraan tidak sah: {action}"}, status=400)

            except Exception as e:
                return self._send_json({"success": False, "message": str(e)}, status=500)

        # Protected Endpoints below this line
        if not self._is_authenticated():
            return self._send_error("Sila log masuk terlebih dahulu.", status=401)

        # 5. Change Password
        if path == "/api/auth/change_password":
            data = self._read_json_body()
            new_pass = data.get("new_password", "")
            if isinstance(new_pass, str):
                new_pass = new_pass.strip()
            else:
                new_pass = str(new_pass or "")
            if new_pass != "" and len(new_pass) < 4:
                return self._send_error("Kata laluan mestilah sekurang-kurangnya 4 aksara (atau kosongkan untuk log masuk tanpa kata laluan).")
            self.db.change_admin_password(new_pass)
            msg = "Kata laluan pentadbir berjaya dikemas kini." if new_pass else "Kata laluan telah dikosongkan. Anda boleh log masuk terus tanpa kata laluan."
            return self._send_json({"success": True, "message": msg})

        # 4. Update Settings
        elif path == "/api/settings":
            updates = self._read_json_body()
            # Filter protected keys
            updates.pop("admin_password_hash", None)
            updates.pop("admin_user", None)
            updates.pop("force_password_change", None)

            # Bank QR Base64 image upload support
            if "bank_qr_base64" in updates:
                qr_b64 = updates.pop("bank_qr_base64")
                if qr_b64:
                    import base64
                    raw_header = ""
                    if "," in qr_b64:
                        raw_header, qr_b64 = qr_b64.split(",", 1)
                    try:
                        qr_bytes = base64.b64decode(qr_b64)
                        try:
                            qr_url, _ = self._save_qr_image(qr_bytes, raw_header)
                        except (PermissionError, OSError) as e:
                            if getattr(e, "errno", None) == 13 or isinstance(e, PermissionError):
                                qr_url, _ = self._save_qr_image_fallback(qr_bytes, raw_header)
                            else:
                                raise
                        updates["bank_qr_url"] = qr_url
                    except Exception as e:
                        return self._send_error(f"Gagal memproses gambar QR: {str(e)}", status=500)

            old_zone = self.db.get_setting("jakim_zone")
            self.db.update_settings(updates)

            new_zone = updates.get("jakim_zone")
            # If zone changed, trigger automatic sync in background
            if new_zone and new_zone != old_zone:
                try:
                    self.jakim_mgr.sync_takwim_for_zone(new_zone, period="month")
                except Exception:
                    pass

            # Only increment reload counter if force_reload is explicitly requested, allowing smooth real-time layout updates
            if updates.get("force_reload"):
                EsolatRequestHandler.kiosk_reload_counter += 1
            return self._send_json({"success": True, "message": "Tetapan berjaya disimpan."})

        # 4b. Upload Bank QR Code directly
        elif path == "/api/settings/upload_qr":
            data = self._read_json_body()
            qr_b64 = data.get("qr_base64") or data.get("file_base64")
            if not qr_b64:
                return self._send_error("Fail imej QR diperlukan.")
            import base64
            raw_header = ""
            if "," in qr_b64:
                raw_header, qr_b64 = qr_b64.split(",", 1)
            try:
                qr_bytes = base64.b64decode(qr_b64)
                try:
                    qr_url, _ = self._save_qr_image(qr_bytes, raw_header)
                except (PermissionError, OSError) as e:
                    if getattr(e, "errno", None) == 13 or isinstance(e, PermissionError):
                        qr_url, _ = self._save_qr_image_fallback(qr_bytes, raw_header)
                    else:
                        raise
                self.db.update_settings({"bank_qr_url": qr_url})
                return self._send_json({"success": True, "message": "Imej QR Kod Bank berjaya dimuat naik.", "bank_qr_url": qr_url})
            except Exception as e:
                return self._send_error(f"Gagal menyimpan imej QR: {str(e)}", status=500)


        # 5. Trigger JAKIM Sync
        elif path == "/api/jakim/sync":
            data = self._read_json_body()
            zone = data.get("zone") or self.db.get_setting("jakim_zone", "WLY01")
            period = data.get("period", "month")
            res = self.jakim_mgr.sync_takwim_for_zone(zone, period=period)
            return self._send_json(res)

        # 6. License: Activate via PIN
        elif path == "/api/license/activate_pin":
            data = self._read_json_body()
            pin = data.get("pin", "").strip()
            ok, msg, lic_data = self.license_mgr.verify_pin(pin)
            if ok:
                return self._send_json({"success": True, "message": msg, "license": lic_data})
            else:
                return self._send_error(msg)

        # 7. License: Upload .lic
        elif path == "/api/license/upload_lic":
            data = self._read_json_body()
            lic_content = data.get("license_content", "")
            ok, msg = self.license_mgr.install_license_file(lic_content)
            if ok:
                return self._send_json({"success": True, "message": msg})
            else:
                return self._send_error(msg)

        # 8. Media Upload / New Slide
        elif path == "/api/slides":
            data = self._read_json_body()
            title = data.get("title", "Slaid").strip()
            duration = int(data.get("duration", 10))
            sort_order = int(data.get("sort_order", 0))
            media_type = data.get("media_type", "image")

            # Check if file data is Base64
            file_base64 = data.get("file_base64")
            file_name = data.get("file_name", "slide.jpg")

            if file_base64:
                import base64
                if "," in file_base64:
                    file_base64 = file_base64.split(",", 1)[1]
                try:
                    file_bytes = base64.b64decode(file_base64)
                except Exception as e:
                    return self._send_error(f"Data Base64 slaid tidak sah: {str(e)}")

                ext = Path(file_name).suffix.lower()
                clean_name = f"slide_{int(time.time())}_{uuid.uuid4().hex[:6]}{ext}"
                target_dir = self._get_posters_dir()
                dest = target_dir / clean_name
                try:
                    target_dir.mkdir(parents=True, exist_ok=True)
                    with open(dest, "wb") as f:
                        f.write(file_bytes)
                    file_url = f"/content/posters/{clean_name}"
                except (PermissionError, OSError) as e:
                    if getattr(e, "errno", None) == 13 or isinstance(e, PermissionError):
                        try:
                            fallback_dir = Path("./content/posters").resolve()
                            fallback_dir.mkdir(parents=True, exist_ok=True)
                            dest = fallback_dir / clean_name
                            with open(dest, "wb") as f:
                                f.write(file_bytes)
                            file_url = f"/content/posters/{clean_name}"
                        except Exception:
                            return self._send_error(self._format_permission_error_msg(str(target_dir)), status=500)
                    else:
                        return self._send_error(f"Gagal menyimpan fail: {str(e)}", status=500)
                except Exception as e:
                    return self._send_error(f"Gagal menyimpan fail: {str(e)}", status=500)
            else:
                file_url = data.get("file_url", "").strip()
                if not file_url:
                    return self._send_error("Fail atau URL slaid diperlukan.")

            days_active = data.get("days_active", "all")
            slide_id = self.db.add_slide(title, file_url, media_type, duration, sort_order, days_active=days_active)
            return self._send_json({"success": True, "slide_id": slide_id, "file_url": file_url})

        # 9. Test Audio (Legacy alias)
        elif path == "/api/system/test_audio":
            data = self._read_json_body()
            sound = data.get("sound", "beep")
            if sound == "adhan":
                self.audio_mgr.play_sound("adhan.mp3")
            elif sound == "subuh":
                self.audio_mgr.play_sound("adhan_subuh.mp3")
            elif sound == "pre_adhan":
                self.audio_mgr.play_sound("pre_adhan.wav")
            else:
                self.audio_mgr.play_sound("beep.wav")
            return self._send_json({"success": True, "message": f"Ujian audio '{sound}' dimainkan."})

        # 9b. Dedicated Kiosk Hardware Audio Test Endpoint (HDMI / 3.5mm Output)
        elif path == "/api/audio/test-kiosk" or path == "/api/audio/test_kiosk":
            data = self._read_json_body()
            action = data.get("action", "play").lower()
            if action == "stop":
                if self.audio_mgr:
                    self.audio_mgr.stop_sound()
                return self._send_json({"success": True, "message": "Audio kiosk dihentikan."})

            sound = data.get("file_name") or data.get("sound") or data.get("file") or data.get("sound_name") or "beep.wav"
            if sound == "adhan":
                sound = "adhan.mp3"
            elif sound == "subuh":
                sound = "adhan_subuh.mp3"
            elif sound == "pre_adhan":
                sound = "pre_adhan.wav"
            elif sound == "beep":
                sound = "beep.wav"

            if self.audio_mgr:
                self.audio_mgr.play_sound(sound)
            return self._send_json({
                "success": True,
                "message": f"Ujian audio kiosk dimainkan: {sound}",
                "sound": sound
            })

        # 9c. Quran / Tarhim Pre-Azan Audio Management
        elif path == "/api/quran/upload":
            data = self._read_json_body()
            file_base64 = data.get("file_base64")
            raw_filename = data.get("file_name", "quran_recitation.mp3")

            if not file_base64:
                return self._send_error("Data fail audio (Base64) diperlukan.")

            import base64
            if "," in file_base64:
                file_base64 = file_base64.split(",", 1)[1]

            try:
                file_bytes = base64.b64decode(file_base64)
            except Exception as e:
                return self._send_error(f"Format Base64 tidak sah: {str(e)}")

            ext = Path(raw_filename).suffix.lower()
            if ext not in [".mp3", ".wav", ".ogg", ".m4a", ".aac"]:
                ext = ".mp3"

            # Clean filename: replace spaces with underscores, preserve readable name
            clean_stem = Path(raw_filename).stem
            safe_stem = "".join([c if c.isalnum() or c in "_- " else "" for c in clean_stem]).strip().replace(" ", "_")
            if not safe_stem:
                safe_stem = f"quran_{int(time.time())}"
            target_name = f"{safe_stem}{ext}"

            quran_dir = self._get_quran_dir()
            dest_file = quran_dir / target_name

            try:
                with open(dest_file, "wb") as f:
                    f.write(file_bytes)
                os.chmod(str(dest_file), 0o666)
            except Exception as e:
                return self._send_error(f"Gagal menyimpan fail audio Quran: {str(e)}", status=500)

            return self._send_json({
                "success": True,
                "message": f"Fail audio '{target_name}' berjaya dimuat naik ke pustaka Quran.",
                "file_name": target_name,
                "file_url": f"/media/quran/{target_name}"
            })

        elif path == "/api/quran/delete":
            data = self._read_json_body()
            fname = data.get("file_name", "").strip()
            if not fname:
                return self._send_error("Nama fail audio diperlukan.")

            # Prevent directory traversal
            clean_fname = Path(fname).name
            quran_dir = self._get_quran_dir()
            target = quran_dir / clean_fname

            if target.exists():
                try:
                    target.unlink()
                    return self._send_json({"success": True, "message": f"Fail '{clean_fname}' berjaya dipadam."})
                except Exception as e:
                    return self._send_error(f"Gagal memadam fail: {str(e)}", status=500)
            else:
                return self._send_error(f"Fail '{clean_fname}' tidak dijumpai.", status=404)

        elif path == "/api/quran/test_play":
            data = self._read_json_body()
            action = data.get("action", "play").lower()

            if action == "stop":
                if self.audio_mgr and hasattr(self.audio_mgr, "stop_quran"):
                    self.audio_mgr.stop_quran()
                return self._send_json({"success": True, "message": "Bacaan al-Quran dihentikan."})

            fname = data.get("file_name", "").strip()
            vol = int(data.get("volume", 70))
            if not fname:
                # If no file specified, pick first track from library
                tracks = self.audio_mgr.list_quran_tracks() if (self.audio_mgr and hasattr(self.audio_mgr, "list_quran_tracks")) else []
                if tracks:
                    fname = tracks[0]["file_name"]
                else:
                    return self._send_error("Tiada fail MP3 dalam pustaka Quran untuk dimainkan.")

            if self.audio_mgr and hasattr(self.audio_mgr, "play_quran"):
                self.audio_mgr.play_quran(fname, volume=vol)

            return self._send_json({
                "success": True,
                "message": f"Memainkan ujian audio Quran pada pembesar suara TV/PA: {fname}",
                "file_name": fname
            })

        elif path == "/api/quran/config":
            data = self._read_json_body()
            allowed_keys = [
                "quran_pre_azan_enabled",
                "quran_pre_azan_lead_minutes",
                "quran_pre_azan_mode",
                "quran_pre_azan_file",
                "quran_pre_azan_prayers",
                "quran_pre_azan_volume"
            ]
            updates = {k: str(v) for k, v in data.items() if k in allowed_keys}
            if updates and self.db:
                self.db.update_settings(updates)
            return self._send_json({"success": True, "message": "Konfigurasi bacaan al-Quran sebelum azan berjaya disimpan."})

        # 10. Test State Simulator
        elif path == "/api/system/test_state":
            data = self._read_json_body()
            state = data.get("state", "ADHAN")
            prayer = data.get("prayer", "Zohor")
            duration = int(data.get("duration", 30))
            self.scheduler.set_test_mode(state, prayer, duration)
            return self._send_json({"success": True, "message": f"Mod ujian '{state}' diaktifkan selama {duration} saat."})

        # 11. Clear Test State Simulator
        elif path == "/api/system/clear_test_state":
            self.scheduler.clear_test_mode()
            return self._send_json({"success": True, "message": "Mod ujian dibatalkan."})

        # 12. Reload Kiosk
        elif path == "/api/system/reload_kiosk":
            EsolatRequestHandler.kiosk_reload_counter += 1
            return self._send_json({"success": True, "message": "Arahan muat semula kiosk dihantar."})

        # 13. Camera & MP4 Recording
        elif path == "/api/camera/record/start":
            if not self.recorder_mgr:
                return self._send_error("Modul rakaman video tidak aktif.")
            data = self._read_json_body()
            settings = self.db.get_all_settings() if self.db else {}
            
            # Auto-resolve source: explicit param > rtsp_url from db (if configured) > usb device
            source = data.get("source") or data.get("device")
            if not source:
                cam_type = settings.get("camera_source_type", "auto")
                rtsp_url = settings.get("camera_rtsp_url", "").strip()
                if cam_type == "rtsp" and rtsp_url:
                    source = rtsp_url
                elif cam_type == "auto" and rtsp_url and not self.recorder_mgr.detect_video_devices():
                    source = rtsp_url
                else:
                    source = settings.get("camera_device", "/dev/video0")
            
            res = self.recorder_mgr.start_recording(source=source)
            if res.get("success"):
                return self._send_json(res)
            return self._send_error(res.get("message", "Gagal memulakan rakaman."))

        elif path == "/api/camera/record/stop":
            if not self.recorder_mgr:
                return self._send_error("Modul rakaman video tidak aktif.")
            res = self.recorder_mgr.stop_recording()
            return self._send_json(res)

        elif path == "/api/camera/storage":
            if not self.recorder_mgr:
                return self._send_error("Modul rakaman video tidak aktif.")
            data = self._read_json_body()
            new_path = data.get("storage_path", "").strip()
            res = self.recorder_mgr.set_storage_path(new_path)
            if res.get("success"):
                if self.db:
                    self.db.set_setting("recording_storage_path", res.get("storage_path", new_path))
                return self._send_json(res)
            return self._send_error(res.get("message", "Gagal menetapkan lokasi storan."))

        elif path == "/api/camera/test":
            data = self._read_json_body()
            url = data.get("rtsp_url", "").strip()
            if not url:
                return self._send_error("Sila berikan URL RTSP untuk diuji.")
            
            # Test RTSP connectivity using ffprobe with 5s timeout
            ffprobe_bin = shutil.which("ffprobe")
            if not ffprobe_bin:
                return self._send_json({
                    "success": True, 
                    "warning": True, 
                    "message": "URL RTSP disimpan. (ffprobe belum dipasang untuk pra-semakan, rakaman tetap disokong via ffmpeg)"
                })
            
            try:
                probe_cmd = [
                    ffprobe_bin,
                    "-v", "error",
                    "-rtsp_transport", "tcp",
                    "-i", url,
                    "-show_entries", "stream=codec_type,width,height",
                    "-of", "json"
                ]
                proc = subprocess.run(probe_cmd, capture_output=True, text=True, timeout=6)
                if proc.returncode == 0:
                    return self._send_json({
                        "success": True,
                        "message": "Sambungan kamera PTZ berjaya! Strim video dikesan.",
                        "details": proc.stdout
                    })
                else:
                    return self._send_error(f"Gagal menyambung ke RTSP: {proc.stderr[:120] if proc.stderr else 'Timeout'}")
            except subprocess.TimeoutExpired:
                return self._send_error("Masa tamat (Timeout): Kamera tidak membalas dalam 6 saat. Sila pastikan IP & kata laluan betul.")
            except Exception as e:
                return self._send_error(f"Ralat ujian RTSP: {str(e)}")

        elif path == "/api/camera/bridge/start":
            data = self._read_json_body()
            settings = self.db.get_all_settings() if self.db else {}
            rtsp_url = (data.get("rtsp_url") or settings.get("camera_rtsp_url", "")).strip()
            mgr = self._get_rtsp_bridge_mgr()
            res = mgr.start_bridge(rtsp_url)
            return self._send_json(res)

        elif path == "/api/camera/bridge/stop":
            mgr = self._get_rtsp_bridge_mgr()
            res = mgr.stop_bridge()
            return self._send_json(res)

        elif path == "/api/camera/bridge/test":
            data = self._read_json_body()
            ip = data.get("ip", "").strip()
            port = int(data.get("port", 554))
            mgr = self._get_rtsp_bridge_mgr()
            res = mgr.test_connection(ip, port)
            return self._send_json(res)

        elif path == "/api/camera/toggle_live_display" or path == "/api/kuliah/toggle_live":
            data = self._read_json_body()
            enable = bool(data.get("enable"))
            settings = self.db.get_all_settings() if self.db else {}
            mgr = self._get_rtsp_bridge_mgr()

            if "camera_ip" in data and self.db:
                self.db.set_setting("camera_ip", str(data["camera_ip"]))
            if "camera_port" in data and self.db:
                self.db.set_setting("camera_port", str(data["camera_port"]))
            if "camera_user" in data and self.db:
                self.db.set_setting("camera_user", str(data["camera_user"]))
            if "camera_pass" in data and self.db:
                self.db.set_setting("camera_pass", str(data["camera_pass"]))
            if "camera_subtype" in data and self.db:
                self.db.set_setting("camera_subtype", str(data["camera_subtype"]))
            if "camera_rtsp_url" in data and self.db:
                self.db.set_setting("camera_rtsp_url", str(data["camera_rtsp_url"]))
            if "kuliah_title" in data and self.db:
                self.db.set_setting("kuliah_title", str(data["kuliah_title"]))
            if "kuliah_ustaz" in data and self.db:
                self.db.set_setting("kuliah_ustaz", str(data["kuliah_ustaz"]))
            if "kuliah_kitab" in data and self.db:
                self.db.set_setting("kuliah_kitab", str(data["kuliah_kitab"]))

            rtsp_url = (data.get("rtsp_url") or settings.get("camera_rtsp_url", "")).strip()

            if enable:
                if self.db:
                    self.db.set_setting("kuliah_live_active", "1")
                    self.db.set_setting("lower_third_enabled", "1")
                    if "kuliah_title" in data:
                        self.db.set_setting("lower_third_topic", str(data["kuliah_title"]))
                    if "kuliah_ustaz" in data:
                        self.db.set_setting("lower_third_speaker", str(data["kuliah_ustaz"]))
                    if "kuliah_kitab" in data:
                        self.db.set_setting("lower_third_kitab", str(data["kuliah_kitab"]))

                bridge_res = mgr.start_bridge(rtsp_url) if rtsp_url else {"success": True, "engine": "none"}
                stream_url = "/stream/live.m3u8"
                if bridge_res.get("engine") == "go2rtc":
                    host_ip = self.headers.get("Host", "localhost").split(":")[0]
                    stream_url = f"http://{host_ip}:1984/stream.html?src=kuliah"

                return self._send_json({
                    "success": True,
                    "kuliah_live_active": True,
                    "bridge": bridge_res,
                    "stream_url": stream_url,
                    "message": "Siaran Kuliah LIVE ke TV Kiosk berjaya diaktifkan."
                })
            else:
                if self.db:
                    self.db.set_setting("kuliah_live_active", "0")
                mgr.stop_bridge()
                return self._send_json({
                    "success": True,
                    "kuliah_live_active": False,
                    "message": "Siaran Kuliah LIVE ditutup. TV kembali ke paparan biasa."
                })

        # 14. Azan Audio Upload & Replacement
        elif path == "/api/audio/upload":
            content_type = self.headers.get("Content-Type", "")
            azan_dir = self._get_azan_dir()
            try:
                azan_dir.mkdir(parents=True, exist_ok=True)
            except Exception:
                pass

            file_bytes = None
            orig_filename = ""
            label = ""
            target_file = ""

            if "multipart/form-data" in content_type:
                try:
                    content_length = int(self.headers.get("Content-Length", 0))
                    raw_body = self.rfile.read(content_length)
                    boundary = content_type.split("boundary=")[1].strip()
                    if boundary.startswith('"') and boundary.endswith('"'):
                        boundary = boundary[1:-1]
                    parts = raw_body.split(b"--" + boundary.encode())
                    for part in parts:
                        if b'filename="' in part:
                            headers_part, body_part = part.split(b"\r\n\r\n", 1)
                            headers_text = headers_part.decode("latin1", errors="ignore")
                            for line in headers_text.split("\r\n"):
                                if 'filename="' in line:
                                    f_start = line.find('filename="') + 10
                                    f_end = line.find('"', f_start)
                                    orig_filename = line[f_start:f_end]
                            if body_part.endswith(b"\r\n"):
                                body_part = body_part[:-2]
                            file_bytes = body_part
                        elif b'name="label"' in part or b'name="title"' in part:
                            _, body_part = part.split(b"\r\n\r\n", 1)
                            if body_part.endswith(b"\r\n"):
                                body_part = body_part[:-2]
                            label = body_part.decode("utf-8", errors="ignore").strip()
                        elif b'name="target_file"' in part or b'name="replace_file"' in part:
                            _, body_part = part.split(b"\r\n\r\n", 1)
                            if body_part.endswith(b"\r\n"):
                                body_part = body_part[:-2]
                            target_file = body_part.decode("utf-8", errors="ignore").strip()
                except Exception as e:
                    return self._send_error(f"Ralat memproses muat naik multipart: {str(e)}")
            else:
                data = self._read_json_body()
                file_base64 = data.get("file_base64")
                orig_filename = data.get("file_name", "custom_azan.mp3")
                label = data.get("label", "").strip()
                target_file = data.get("target_file", "").strip() or data.get("replace_file", "").strip()

                if file_base64:
                    import base64
                    if "," in file_base64:
                        file_base64 = file_base64.split(",", 1)[1]
                    try:
                        file_bytes = base64.b64decode(file_base64)
                    except Exception as e:
                        return self._send_error(f"Data Base64 tidak sah: {str(e)}")

            if not file_bytes or not orig_filename:
                return self._send_error("Fail audio diperlukan (.mp3, .wav, atau .ogg).")

            ext = Path(orig_filename).suffix.lower()
            if ext not in [".mp3", ".wav", ".ogg"]:
                return self._send_error("Format fail tidak disokong. Hanya fail .mp3, .wav dan .ogg dibenarkan.")

            import re
            if target_file:
                clean_target = os.path.basename(target_file).strip()
                clean_name = clean_target
                # Ensure correct extension match if target extension differs
                if not clean_name.lower().endswith(ext):
                    clean_name = f"{Path(clean_name).stem}{ext}"
            else:
                clean_stem = re.sub(r"[^a-zA-Z0-9_\-]", "_", Path(orig_filename).stem).strip("_")
                if not clean_stem:
                    clean_stem = f"azan_{int(time.time())}"
                clean_name = f"{clean_stem}{ext}"

            dest = azan_dir / clean_name
            try:
                azan_dir.mkdir(parents=True, exist_ok=True)
                with open(dest, "wb") as f:
                    f.write(file_bytes)
            except (PermissionError, OSError) as e:
                if getattr(e, "errno", None) == 13 or isinstance(e, PermissionError):
                    try:
                        fallback_azan = Path("./opt/esolat/web/kiosk/audio/azan").resolve()
                        fallback_azan.mkdir(parents=True, exist_ok=True)
                        dest = fallback_azan / clean_name
                        with open(dest, "wb") as f:
                            f.write(file_bytes)
                    except Exception:
                        return self._send_error(self._format_permission_error_msg(str(azan_dir)), status=500)
                else:
                    return self._send_error(f"Gagal menyimpan fail audio: {str(e)}", status=500)
            except Exception as e:
                return self._send_error(f"Gagal menyimpan fail audio: {str(e)}", status=500)

            presets_meta = {
                "azan_mekah.mp3": "Azan Makkah Al-Mukarramah",
                "azan_madinah.mp3": "Azan Madinah Al-Munawwarah",
                "azan_mesir.mp3": "Azan Mesir (Syeikh Mustafa Ismail)",
                "azan_aqsa.mp3": "Azan Masjid Al-Aqsa",
                "azan_subuh_special.mp3": "Azan Subuh Khas (As-Salatu Khairum Minan Naum)"
            }
            display_label = label or presets_meta.get(clean_name) or Path(clean_name).stem.replace("_", " ").title()
            is_subuh = 1 if "subuh" in clean_name.lower() else 0
            is_preset = 1 if clean_name in presets_meta else 0
            now_ts = int(time.time())

            if self.db:
                self.db.set_audio_track(
                    file_name=clean_name,
                    label=display_label,
                    audio_type=ext.lstrip("."),
                    is_subuh=is_subuh,
                    is_preset=is_preset,
                    size_bytes=len(file_bytes),
                    updated_at=now_ts
                )

            return self._send_json({
                "success": True,
                "message": f"Fail audio '{clean_name}' berjaya dimuat naik.",
                "file_name": clean_name,
                "file_url": f"/kiosk/audio/azan/{clean_name}",
                "label": display_label,
                "size_bytes": len(file_bytes),
                "modified_at": now_ts,
                "type": ext.lstrip(".")
            })

        # 15. Azan Audio Delete (POST alias)
        elif path == "/api/audio/delete":
            data = self._read_json_body()
            fname = data.get("file_name") or data.get("id") or data.get("file")
            ok, msg = self._delete_audio_file(fname)
            if ok:
                return self._send_json({"success": True, "message": msg, "deleted_file": fname})
            return self._send_error(msg)

        self._send_error("Not Found", status=404)

    def _delete_audio_file(self, fname: Optional[str]):
        if not fname:
            return False, "Nama fail audio tidak dinyatakan."
        clean_name = os.path.basename(fname).strip()
        if not clean_name or clean_name in [".", ".."]:
            return False, "Nama fail tidak sah."

        azan_dir = self._get_azan_dir()
        target_path = azan_dir / clean_name
        if not target_path.exists() or not target_path.is_file():
            return False, f"Fail audio '{clean_name}' tidak dijumpai."

        # Safety Fallback: if active in settings, reset to default preset
        if self.db:
            settings = self.db.get_all_settings()
            curr_sub = settings.get("audio_azan_subuh") or settings.get("audio_azan_subuh_file")
            curr_reg = settings.get("audio_azan_regular") or settings.get("audio_azan_standard_file")
            updates = {}
            if curr_sub == clean_name:
                updates["audio_azan_subuh"] = "azan_subuh_special.mp3"
                updates["audio_azan_subuh_file"] = "azan_subuh_special.mp3"
            if curr_reg == clean_name:
                updates["audio_azan_regular"] = "azan_mekah.mp3"
                updates["audio_azan_standard_file"] = "azan_mekah.mp3"
            if updates:
                self.db.update_settings(updates)
            self.db.delete_audio_track(clean_name)

        try:
            target_path.unlink()
            return True, f"Fail audio '{clean_name}' berjaya dipadamkan."
        except Exception as e:
            return False, f"Gagal memadamkan fail: {str(e)}"

    def do_PUT(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path

        if not self._is_authenticated():
            return self._send_error("Sila log masuk terlebih dahulu.", status=401)

        if path.startswith("/api/slides/"):
            try:
                slide_id = int(path[len("/api/slides/"):])
                updates = self._read_json_body()
                self.db.update_slide(slide_id, updates)
                return self._send_json({"success": True, "message": "Slaid berjaya dikemaskini."})
            except Exception as e:
                return self._send_error(f"Ralat: {str(e)}")

        self._send_error("Not Found", status=404)

    def do_DELETE(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        query = urllib.parse.parse_qs(parsed.query)

        if not self._is_authenticated():
            return self._send_error("Sila log masuk terlebih dahulu.", status=401)

        if path.startswith("/api/slides/"):
            try:
                slide_id = int(path[len("/api/slides/"):])
                self.db.delete_slide(slide_id)
                return self._send_json({"success": True, "message": "Slaid berjaya dipadamkan."})
            except Exception as e:
                return self._send_error(f"Ralat: {str(e)}")

        elif path.startswith("/api/camera/recordings/"):
            fname = path[len("/api/camera/recordings/"):]
            if self.recorder_mgr and self.recorder_mgr.delete_recording(fname):
                return self._send_json({"success": True, "message": "Fail rakaman berjaya dipadam."})
            return self._send_error("Gagal memadam fail rakaman.")

        elif path == "/api/audio" or path.startswith("/api/audio?") or path.startswith("/api/audio/"):
            fname = None
            if path.startswith("/api/audio/"):
                fname = path[len("/api/audio/"):]
            if not fname:
                fname = query.get("id", [None])[0] or query.get("file", [None])[0] or query.get("file_name", [None])[0]
            ok, msg = self._delete_audio_file(fname)
            if ok:
                return self._send_json({"success": True, "message": msg, "deleted_file": fname})
            return self._send_error(msg)

        self._send_error("Not Found", status=404)

    def _serve_file(self, file_path: Path, content_type: Optional[str] = None, extra_headers: Optional[Dict[str, str]] = None):
        # Resolve fallbacks if running in local dev mode vs /opt/esolat
        if not file_path.exists():
            resolved = False
            fname = file_path.name

            # Check web dir relative paths
            if self.web_dir in file_path.parents:
                try:
                    rel = file_path.relative_to(self.web_dir)
                    for candidate in [Path("./opt/esolat/web") / rel, Path("./opt/esolat") / rel, Path("./web") / rel]:
                        if candidate.exists():
                            file_path = candidate
                            resolved = True
                            break
                except Exception:
                    pass

            # Check media & posters candidate directories
            if not resolved:
                qr_aliases = []
                if fname in ("bank_qr.png", "bank_qr.jpg", "bank_qr.jpeg", "bank_qr.webp", "qr.png", "qr.jpg", "qr.jpeg", "qr.webp"):
                    qr_aliases = [
                        "bank_qr.png", "bank_qr.jpg", "bank_qr.jpeg", "bank_qr.webp",
                        "qr.png", "qr.jpg", "qr.jpeg", "qr.webp"
                    ]
                check_names = [fname] + [a for a in qr_aliases if a != fname]

                media_dirs = [
                    self._get_media_dir(),
                    self._get_posters_dir(),
                    self.media_dir,
                    self.content_dir,
                    Path("./media"),
                    Path("./content/posters"),
                    Path("./data/media"),
                    Path("./data/content/posters"),
                    Path("./opt/esolat/media"),
                    Path("/var/lib/esolat/media"),
                    Path("/var/lib/esolat/content/posters")
                ]
                for mdir in media_dirs:
                    for name in check_names:
                        cand = mdir / name
                        if cand.exists() and cand.is_file():
                            file_path = cand
                            resolved = True
                            break
                    if resolved:
                        break

            if not resolved and not file_path.exists():
                self._send_error(f"File not found: {file_path.name}", status=404)
                return

        try:
            with open(file_path, "rb") as f:
                content = f.read()

            if not content_type:
                content_type, _ = mimetypes.guess_type(str(file_path))
                if not content_type:
                    content_type = "application/octet-stream"

            self.send_response(200)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(content)))
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
            self.send_header("Access-Control-Allow-Headers", "*")
            self.send_header("Access-Control-Allow-Private-Network", "true")
            self.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
            self.send_header("Pragma", "no-cache")
            self.send_header("Expires", "0")
            if extra_headers:
                for k, v in extra_headers.items():
                    self.send_header(k, v)
            self.end_headers()
            self.wfile.write(content)
        except Exception as e:
            self._send_error(f"Error serving file: {str(e)}", status=500)
