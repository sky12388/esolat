@echo off
TITLE Skywalker e-Solat Windows Installer & Setup
SETLOCAL EnableDelayedExpansion

echo ==========================================================================
echo 🕌 Skywalker e-Solat Mosque Digital Signage & Kiosk Setup (Windows)
echo Version: 1.3.9 (Commercial Standalone)
echo Vendor : Skywalker Consortium (AS0463209-A)
echo ==========================================================================
echo.

SET "INSTALL_DIR=%~dp0"

:: 1. Check Python Availability
echo [1/4] Checking Python Runtime environment...
SET "PYTHON_CMD="
where python >nul 2>nul
IF %ERRORLEVEL% EQU 0 (
    SET "PYTHON_CMD=python"
) ELSE (
    where py >nul 2>nul
    IF %ERRORLEVEL% EQU 0 (
        SET "PYTHON_CMD=py"
    )
)

IF NOT DEFINED PYTHON_CMD (
    IF NOT EXIST "%INSTALL_DIR%bin\esolat-server.exe" (
        echo.
        echo [WARNING] Python tidak dijumpai dalam PATH Windows anda.
        echo Sila muat turun dan pasang Python 3.10+ dari https://www.python.org/
        echo Pastikan anda menandakan kotak "Add Python to PATH" semasa pemasangan.
        echo.
        pause
        EXIT /B 1
    ) ELSE (
        echo [OK] Standalone backend binary esolat-server.exe dikesan.
    )
) ELSE (
    echo [OK] Python runtime dikesan (!PYTHON_CMD!).
)

:: 2. Create Desktop Shortcut for Kiosk using VBScript
echo [2/4] Creating Desktop Shortcut for e-Solat Kiosk...
SET "DESKTOP_DIR=%USERPROFILE%\Desktop"
SET "VBS_SCRIPT=%TEMP%\create_esolat_shortcut.vbs"

(
echo Set oWS = WScript.CreateObject^("WScript.Shell"^)
echo sLinkFile = "%DESKTOP_DIR%\Skywalker e-Solat Kiosk.lnk"
echo Set oLink = oWS.CreateShortcut^(sLinkFile^)
echo oLink.TargetPath = "%INSTALL_DIR%esolat-kiosk.bat"
echo oLink.WorkingDirectory = "%INSTALL_DIR%"
echo oLink.Description = "Skywalker e-Solat Mosque Digital Signage"
echo oLink.Save
) > "%VBS_SCRIPT%"

cscript //nologo "%VBS_SCRIPT%" >nul 2>nul
del "%VBS_SCRIPT%" >nul 2>nul
echo [OK] Desktop Shortcut e-Solat Kiosk berjaya dicipta.

:: 3. Create Admin Shortcut
echo [3/4] Creating Desktop Shortcut for Admin Panel...
(
echo Set oWS = WScript.CreateObject^("WScript.Shell"^)
echo sLinkFile = "%DESKTOP_DIR%\e-Solat Phone Admin.lnk"
echo Set oLink = oWS.CreateShortcut^(sLinkFile^)
echo oLink.TargetPath = "http://localhost:8080/admin"
echo oLink.Description = "Skywalker e-Solat Admin Panel"
echo oLink.Save
) > "%VBS_SCRIPT%"

cscript //nologo "%VBS_SCRIPT%" >nul 2>nul
del "%VBS_SCRIPT%" >nul 2>nul
echo [OK] Admin Shortcut berjaya dicipta di Desktop.

:: 4. Completion & Options
echo [4/4] Memasang pintasan sistem...
echo.
echo ==========================================================================
echo ✅ PEMASANGAN SELESAI (INSTALLATION COMPLETED)
echo.
echo Pintasan "Skywalker e-Solat Kiosk" telah dicipta di Desktop anda.
echo.
echo Pilihan Pelancaran:
echo   1. Lancarkan Paparan e-Solat Kiosk sekarang (Fullscreen)
echo   2. Buka Panel Kawalan Pentadbir (Admin Panel)
echo   3. Aktifkan Auto-Start semasa Windows dihidupkan (Startup)
echo   4. Keluar
echo ==========================================================================
echo.
set /p CHOICE="Sila pilih nombor (1-4): "

IF "%CHOICE%"=="1" (
    start "" "%INSTALL_DIR%esolat-kiosk.bat"
) ELSE IF "%CHOICE%"=="2" (
    start "" "http://localhost:8080/admin"
) ELSE IF "%CHOICE%"=="3" (
    SET "STARTUP_DIR=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup"
    (
    echo Set oWS = WScript.CreateObject^("WScript.Shell"^)
    echo sLinkFile = "%STARTUP_DIR%\Skywalker e-Solat Server.lnk"
    echo Set oLink = oWS.CreateShortcut^(sLinkFile^)
    echo oLink.TargetPath = "%INSTALL_DIR%start-server-hidden.vbs"
    echo oLink.WorkingDirectory = "%INSTALL_DIR%"
    echo oLink.Description = "Skywalker e-Solat Background Server"
    echo oLink.Save
    ) > "%TEMP%\create_startup.vbs"
    cscript //nologo "%TEMP%\create_startup.vbs" >nul 2>nul
    del "%TEMP%\create_startup.vbs" >nul 2>nul
    echo.
    echo [OK] Auto-Start e-Solat telah berjaya ditambah ke folder Startup Windows!
    pause
)

EXIT /B 0
