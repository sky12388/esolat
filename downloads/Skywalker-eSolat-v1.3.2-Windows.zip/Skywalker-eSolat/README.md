# 🪟 Skywalker e-Solat for Windows OS

Panduan membina aplikasi **Skywalker e-Solat Mosque Signage** untuk sistem operasi Windows (Windows 10, Windows 11, Windows Server).

---

## 🚀 Cara Bina untuk Windows

### 1. Prasyarat di Komputer Windows
1. **Python 3.10+** terpasang (tandakan *"Add Python to PATH"* semasa pemasangan).
2. **Inno Setup 6** (Pilihan: untuk membina fail pemasang `.exe` - muat turun dari [jrsoftware.org/isdl.php](https://jrsoftware.org/isdl.php)).

---

### 2. Kompilasi Binari (`esolat-server.exe`)
Buka `Command Prompt` (cmd) atau `PowerShell` di dalam folder `windows\`:
```cmd
cd windows
build-windows.bat
```
Skrip ini akan:
- Memasang `pyinstaller` (jika belum ada).
- Mengkompilasi backend Python ke dalam binari terlindung tunggal: `windows\bin\esolat-server.exe`.

---

### 3. Membina Pemasang Setup (`Skywalker-eSolat-Setup-v1.0.0.exe`)
1. Buka fail [`windows\installer.iss`](file:///home/ma/Documents/skywalker.esolat/windows/installer.iss) menggunakan perisian **Inno Setup Compiler**.
2. Klik **Build > Compile** (atau tekan `Ctrl + F9`).
3. Fail pemasang siap guna akan disimpan di dalam folder `windows\dist\Skywalker-eSolat-Setup-v1.0.0.exe`.

---

## 🖥️ Struktur Fail di Windows Selepas Pemasangan (`C:\Program Files\Skywalker e-Solat`)
```text
C:\Program Files\Skywalker e-Solat\
├── bin\
│   └── esolat-server.exe          <-- Backend compiled binary (Hardened)
├── ui\                            <-- Kiosk & Phone Admin Web assets
│   ├── kiosk\
│   ├── admin\
│   └── assets\
├── docs\
│   ├── USER_MANUAL.md
│   └── PANDUAN_PENGGUNA.md
├── esolat-kiosk.bat               <-- Kiosk Launcher (Edge/Chrome Fullscreen)
├── start-server-hidden.vbs        <-- Silent Autostart background service
└── unins000.exe                   <-- Windows Uninstaller
```

---

## 🌟 Ciri-Ciri Khas Versi Windows
1. **Rentas Platform HWID:** Menggunakan WMI / PowerShell CIM UUID Motherboard & MAC address untuk pengesahan lesen.
2. **Autoplay Audio:** Menggunakan pemain media Windows & fallback PowerShell untuk memutarkan azan tanpa perlu pasang perisian pihak ketiga.
3. **Kiosk Edge / Chrome:** Membuka paparan masjid skrin penuh secara automatik pada Microsoft Edge atau Google Chrome.
