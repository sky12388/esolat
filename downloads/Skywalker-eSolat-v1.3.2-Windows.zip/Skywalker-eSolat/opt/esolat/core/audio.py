"""
Audio Playback and Sound Management Engine for Mosque Digital Signage & e-Solat System
Supports direct ALSA / PulseAudio playback via mpg123, aplay, and paplay with volume controls.
"""

import os
import sys
import shutil
import subprocess
import threading
from pathlib import Path
from typing import Optional

class AudioManager:
    def __init__(self, assets_dir: str = "/opt/esolat/web/assets/audio"):
        self.assets_dir = Path(assets_dir)
        self.current_process: Optional[subprocess.Popen] = None
        self.current_quran_process: Optional[subprocess.Popen] = None
        self.current_quran_track: Optional[str] = None
        self.lock = threading.Lock()
        self._find_players()

    def _find_players(self):
        self.player_mp3 = shutil.which("mpg123") or shutil.which("ffplay") or shutil.which("cvlc")
        self.player_wav = shutil.which("aplay") or shutil.which("paplay") or self.player_mp3

    def get_quran_dir(self) -> Path:
        """
        Locates or creates the Quran/Tarhim audio storage directory.
        Priority: /var/lib/esolat/media/quran -> ./media/quran -> /opt/esolat/web/assets/audio/quran
        """
        candidates = [
            Path("/var/lib/esolat/media/quran"),
            Path("./media/quran"),
            Path("./opt/esolat/web/assets/audio/quran"),
            self.assets_dir / "quran"
        ]
        for c in candidates:
            try:
                c.mkdir(parents=True, exist_ok=True)
                probe = c / ".write_probe"
                with open(probe, "w") as f:
                    f.write("ok")
                probe.unlink()
                return c
            except (PermissionError, OSError):
                continue
        # Fallback to first candidate
        target = candidates[0]
        try:
            target.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
        return target

    def list_quran_tracks(self) -> list:
        """
        Scans Quran audio directory and returns list of valid audio files.
        """
        q_dir = self.get_quran_dir()
        tracks = []
        if q_dir.exists():
            for f in sorted(q_dir.iterdir()):
                if f.is_file() and f.suffix.lower() in [".mp3", ".wav", ".ogg", ".m4a", ".aac"]:
                    stat = f.stat()
                    clean_title = f.stem.replace("_", " ").replace("-", " ").title()
                    tracks.append({
                        "file_name": f.name,
                        "title": clean_title,
                        "file_url": f"/media/quran/{f.name}",
                        "type": f.suffix.lower().lstrip("."),
                        "size_bytes": stat.st_size,
                        "size_formatted": f"{stat.st_size / (1024 * 1024):.1f} MB",
                        "modified_at": int(stat.st_mtime)
                    })
        return tracks

    def play_quran(self, sound_name_or_path: str, volume: Optional[int] = None, wait: bool = False):
        """
        Plays a Quran / Tarhim recitation track through the sound system.
        """
        q_dir = self.get_quran_dir()
        sound_path = q_dir / sound_name_or_path
        if not sound_path.exists():
            alt = Path(sound_name_or_path)
            if alt.exists():
                sound_path = alt
            else:
                # Check fallback dirs
                found = False
                for c in [Path("./media/quran") / sound_name_or_path, self.assets_dir / sound_name_or_path]:
                    if c.exists():
                        sound_path = c
                        found = True
                        break
                if not found:
                    print(f"[AUDIO QURAN] Track not found: {sound_name_or_path}")
                    return

        def _play():
            with self.lock:
                self.stop_quran()
                self.current_quran_track = sound_path.name
                ext = sound_path.suffix.lower()
                cmd = None

                if sys.platform == "win32":
                    if shutil.which("mpg123"):
                        cmd = ["mpg123", "-q", str(sound_path)]
                    elif shutil.which("ffplay"):
                        cmd = ["ffplay", "-nodisp", "-autoexit", "-loglevel", "quiet", str(sound_path)]
                    else:
                        ps_script = f"$w = New-Object -ComObject 'WMPlayer.OCX'; $w.URL = '{sound_path}'; $w.controls.play(); while($w.playState -ne 1 -and $w.playState -ne 0){{Start-Sleep -Milliseconds 250}}"
                        cmd = ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", ps_script]
                elif ext in [".wav"]:
                    if shutil.which("aplay"):
                        cmd = ["aplay", "-q", str(sound_path)]
                    elif shutil.which("paplay"):
                        cmd = ["paplay", str(sound_path)]
                    elif self.player_mp3:
                        cmd = [self.player_mp3, str(sound_path)]
                elif ext in [".ogg", ".oga"]:
                    if shutil.which("ogg123"):
                        cmd = ["ogg123", "-q", str(sound_path)]
                    elif shutil.which("paplay"):
                        cmd = ["paplay", str(sound_path)]
                    elif self.player_mp3:
                        cmd = [self.player_mp3, str(sound_path)]
                else:  # .mp3, .m4a, .aac
                    if shutil.which("mpg123"):
                        cmd = ["mpg123", "-q", str(sound_path)]
                    elif shutil.which("paplay"):
                        cmd = ["paplay", str(sound_path)]
                    elif shutil.which("ffplay"):
                        cmd = ["ffplay", "-nodisp", "-autoexit", "-loglevel", "quiet", str(sound_path)]

                if not cmd:
                    print(f"[AUDIO QURAN] No player found for {sound_path}")
                    return

                try:
                    self.current_quran_process = subprocess.Popen(
                        cmd,
                        stdout=subprocess.DEVNULL,
                        stderr=subprocess.DEVNULL
                    )
                except Exception as e:
                    print(f"[AUDIO QURAN] Error starting Quran playback: {e}")
                    return

            if self.current_quran_process:
                self.current_quran_process.wait()
                self.current_quran_track = None

        thread = threading.Thread(target=_play, daemon=True)
        thread.start()
        if wait:
            thread.join()

    def stop_quran(self):
        """
        Stops active Quran / Tarhim audio playback.
        """
        if self.current_quran_process:
            try:
                self.current_quran_process.terminate()
                self.current_quran_process.kill()
            except Exception:
                pass
            self.current_quran_process = None
            self.current_quran_track = None

    def is_quran_playing(self) -> bool:
        return self.current_quran_process is not None and self.current_quran_process.poll() is None

    def play_sound(self, sound_name: str, wait: bool = False):
        """
        Plays sound file by name (e.g. 'adhan.mp3', 'adhan_subuh.mp3', 'beep.wav', 'pre_adhan.wav')
        or absolute file path.
        """
        sound_path = self.assets_dir / sound_name
        if not sound_path.exists():
            # Check if provided as absolute or relative path
            alt_path = Path(sound_name)
            if alt_path.exists():
                sound_path = alt_path
            else:
                # Check azan audio directory and media storage
                azan_candidates = [
                    self.assets_dir.parent.parent / "kiosk" / "audio" / "azan" / sound_name,
                    self.assets_dir.parent / "kiosk" / "audio" / "azan" / sound_name,
                    Path("/opt/esolat/ui/kiosk/audio/azan") / sound_name,
                    Path("/opt/esolat/web/kiosk/audio/azan") / sound_name,
                    Path("/opt/esolat/web/assets/audio") / sound_name,
                    Path("/opt/esolat/ui/assets/audio") / sound_name,
                    Path("/var/lib/esolat/media") / sound_name,
                    Path("/var/lib/esolat/media/quran") / sound_name,
                    Path("./opt/esolat/web/kiosk/audio/azan") / sound_name,
                    Path("./opt/esolat/ui/kiosk/audio/azan") / sound_name,
                    Path("./opt/esolat/web/assets/audio") / sound_name,
                    Path("./web/kiosk/audio/azan") / sound_name,
                    Path("./media") / sound_name,
                    Path("./media/quran") / sound_name
                ]
                found = False
                for candidate in azan_candidates:
                    if candidate.exists():
                        sound_path = candidate
                        found = True
                        break
                if not found:
                    print(f"[AUDIO] Sound file not found: {sound_name}")
                    return

        def _play():
            with self.lock:
                self.stop_sound()

                ext = sound_path.suffix.lower()
                cmd = None

                if sys.platform == "win32":
                    if ext in [".wav"]:
                        # Native winsound on Windows
                        try:
                            import winsound
                            winsound.PlaySound(str(sound_path), winsound.SND_FILENAME | (winsound.SND_ASYNC if not wait else 0))
                            return
                        except Exception:
                            pass
                    # Fallback to PowerShell MediaPlayer COM or mpg123/ffplay on Windows
                    if shutil.which("mpg123"):
                        cmd = ["mpg123", "-q", str(sound_path)]
                    elif shutil.which("ffplay"):
                        cmd = ["ffplay", "-nodisp", "-autoexit", "-loglevel", "quiet", str(sound_path)]
                    else:
                        ps_script = f"$p = New-Object System.Media.SoundPlayer '{sound_path}'; $p.PlaySync()" if ext == ".wav" else f"$w = New-Object -ComObject 'WMPlayer.OCX'; $w.URL = '{sound_path}'; $w.controls.play(); while($w.playState -ne 1 -and $w.playState -ne 0){{Start-Sleep -Milliseconds 250}}"
                        cmd = ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", ps_script]
                elif ext in [".wav"]:
                    if shutil.which("aplay"):
                        cmd = ["aplay", "-q", str(sound_path)]
                    elif shutil.which("paplay"):
                        cmd = ["paplay", str(sound_path)]
                    elif self.player_mp3:
                        cmd = [self.player_mp3, str(sound_path)]
                elif ext in [".ogg", ".oga"]:
                    if shutil.which("ogg123"):
                        cmd = ["ogg123", "-q", str(sound_path)]
                    elif shutil.which("paplay"):
                        cmd = ["paplay", str(sound_path)]
                    elif shutil.which("ffplay"):
                        cmd = ["ffplay", "-nodisp", "-autoexit", "-loglevel", "quiet", str(sound_path)]
                    elif self.player_mp3:
                        cmd = [self.player_mp3, str(sound_path)]
                else: # .mp3
                    if shutil.which("mpg123"):
                        cmd = ["mpg123", "-q", str(sound_path)]
                    elif shutil.which("paplay"):
                        cmd = ["paplay", str(sound_path)]
                    elif shutil.which("ffplay"):
                        cmd = ["ffplay", "-nodisp", "-autoexit", "-loglevel", "quiet", str(sound_path)]
                    elif shutil.which("aplay"):
                        cmd = ["aplay", "-q", str(sound_path)]

                if not cmd:
                    print(f"[AUDIO] No suitable audio player found (e.g. mpg123, aplay, ogg123) for {sound_path}")
                    return

                try:
                    self.current_process = subprocess.Popen(
                        cmd,
                        stdout=subprocess.DEVNULL,
                        stderr=subprocess.DEVNULL
                    )
                except Exception as e:
                    print(f"[AUDIO] Error launching sound player: {e}")
                    return

            if self.current_process:
                self.current_process.wait()

        thread = threading.Thread(target=_play, daemon=True)
        thread.start()
        if wait:
            thread.join()

    def stop_sound(self):
        """
        Stops any ongoing audio playback.
        """
        if self.current_process:
            try:
                self.current_process.terminate()
                self.current_process.kill()
            except Exception:
                pass
            self.current_process = None

    def set_system_volume(self, percentage: int):
        """
        Sets master output volume using ALSA amixer / PulseAudio pactl on Linux, or PowerShell/nircmd on Windows.
        """
        pct = max(0, min(100, int(percentage)))
        if sys.platform == "win32":
            if shutil.which("nircmd"):
                try:
                    vol_val = int(pct * 65535 / 100)
                    subprocess.run(["nircmd", "setsysvolume", str(vol_val)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=2)
                except Exception:
                    pass
            return

        if shutil.which("amixer"):
            try:
                subprocess.run(["amixer", "sset", "Master", f"{pct}%"],
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=2)
            except Exception:
                pass
        if shutil.which("pactl"):
            try:
                subprocess.run(["pactl", "set-sink-volume", "@DEFAULT_SINK@", f"{pct}%"],
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=2)
            except Exception:
                pass
