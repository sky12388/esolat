"""
SQLite Database Layer for Mosque Digital Signage & e-Solat System
Manages settings, cached JAKIM takwim, slideshow media entries, and audit logs.
"""

import os
import sqlite3
import hashlib
import json
from pathlib import Path
from typing import Dict, Any, List, Optional

DEFAULT_ADMIN_USER = "admin"
DEFAULT_ADMIN_PASS = ""

def hash_password(password: str) -> str:
    salt = "ESOLAT_ADMIN_SALT_2026"
    return hashlib.sha256(f"{salt}::{password}".encode("utf-8")).hexdigest()

class Database:
    def __init__(self, db_path: str = "/var/lib/esolat/data/esolat.db"):
        self.db_path = Path(db_path)
        try:
            self.db_path.parent.mkdir(parents=True, exist_ok=True)
        except Exception:
            # Fallback to local ./data
            self.db_path = Path("./data/esolat.db")
            self.db_path.parent.mkdir(parents=True, exist_ok=True)

        self._init_tables()
        self._seed_default_data()

    def get_connection(self) -> sqlite3.Connection:
        conn = sqlite3.connect(str(self.db_path), timeout=10.0)
        conn.row_factory = sqlite3.Row
        return conn

    def _init_tables(self):
        with self.get_connection() as conn:
            cursor = conn.cursor()

            # Settings table
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS settings (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL
            );
            """)

            # Prayer Takwim Cache table
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS prayer_schedule (
                zone TEXT NOT NULL,
                date TEXT NOT NULL,
                hijri TEXT NOT NULL,
                day TEXT NOT NULL,
                imsak TEXT NOT NULL,
                fajr TEXT NOT NULL,
                syuruk TEXT NOT NULL,
                dhuha TEXT NOT NULL,
                dhuhr TEXT NOT NULL,
                asr TEXT NOT NULL,
                maghrib TEXT NOT NULL,
                isha TEXT NOT NULL,
                updated_at INTEGER NOT NULL,
                PRIMARY KEY (zone, date)
            );
            """)

            # Slides table
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS slides (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                file_url TEXT NOT NULL,
                media_type TEXT NOT NULL DEFAULT 'image',
                sort_order INTEGER NOT NULL DEFAULT 0,
                duration INTEGER NOT NULL DEFAULT 10,
                enabled INTEGER NOT NULL DEFAULT 1,
                created_at INTEGER NOT NULL
            );
            """)

            # Audit / Event logs
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS system_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp INTEGER NOT NULL,
                category TEXT NOT NULL,
                message TEXT NOT NULL
            );
            """)

            # Azan Audio Tracks table
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS audio_tracks (
                file_name TEXT PRIMARY KEY,
                label TEXT NOT NULL,
                type TEXT NOT NULL DEFAULT 'mp3',
                is_subuh INTEGER NOT NULL DEFAULT 0,
                is_preset INTEGER NOT NULL DEFAULT 0,
                size_bytes INTEGER NOT NULL DEFAULT 0,
                updated_at INTEGER NOT NULL DEFAULT 0
            );
            """)

            conn.commit()

    def _seed_default_data(self):
        defaults = {
            "mosque_name": "Surau Al-Ikhlas",
            "mosque_location": "Seksyen 7, Shah Alam, Selangor",
            "jakim_zone": "SGR01",
            "admin_user": DEFAULT_ADMIN_USER,
            "admin_password_hash": hash_password(DEFAULT_ADMIN_PASS),
            "force_password_change": "0",  # 0 = Optional password change
            "kiosk_pin": "1234",
            "admin_pin": "1234",
            "maintenance_pin": "1234",
            # Adhan modes: auto (MP3) vs beep (Bilal prompt) vs silent
            "adhan_mode_subuh": "auto",
            "adhan_mode_zohor": "auto",
            "adhan_mode_asar": "auto",
            "adhan_mode_maghrib": "auto",
            "adhan_mode_isyak": "auto",
            # Iqamah countdown (minutes)
            "iqamah_subuh": "15",
            "iqamah_zohor": "10",
            "iqamah_asar": "10",
            "iqamah_maghrib": "10",
            "iqamah_isyak": "10",
            # Offsets (minutes +/-)
            "offset_imsak": "0",
            "offset_subuh": "0",
            "offset_syuruk": "0",
            "offset_zohor": "0",
            "offset_asar": "0",
            "offset_maghrib": "0",
            "offset_isyak": "0",
            # Lead time for pre-adhan alert (minutes)
            "pre_adhan_lead": "3",
            # Congregational prayer display mode duration (minutes)
            "solat_duration": "12",
            # Announcements & Marquee Ticker
            "ticker_text": "Selamat Datang ke Surau Al-Ikhlas. Sila pastikan telefon bimbit dimatikan atau diletakkan dalam mod senyap semasa berada di dalam dewan solat. Tabung infaq pembangunan surau kini dibuka.",
            "ticker_speed": "normal",
            # Bank donation details
            "bank_name": "Bank Islam Malaysia Berhad",
            "bank_account_no": "1202-9010-0456-78",
            "bank_account_holder": "Tabung Pembangunan Surau Al-Ikhlas",
            "slide_duration": "10",
            "system_volume": "85",
            # Typography / Font family selection: 'outfit', 'amiri', 'inter', 'montserrat', 'reem_kufi'
            "kiosk_font_family": "outfit",
            # Kiosk Layout: 'full' (100% slideshow), 'split_right' (68% slide left, 32% info right), 'split_left' (32% info left, 68% slide right)
            "kiosk_layout": "full",
            # Next Kuliah Side Widget details
            "kuliah_title": "Kuliah Maghrib Perdana: Menghayati Al-Quran",
            "kuliah_ustaz": "Ustaz Hj. Ahmad Fauzi",
            "kuliah_date": "Setiap Hari Rabu (Lepas Maghrib)",
            # Multi-Source Video & Picture-in-Picture (PiP) Layout System
            # Modes: 'fullscreen_signage', 'fullscreen_video', 'split_equal', 'split_video_focus', 'split_signage_focus', 'pip_video', 'pip_signage'
            "active_layout_mode": "fullscreen_signage",
            "kiosk_layout_mode": "split",
            "pip_mode": "none",
            "media_source_type": "slides",
            "media_stream_url": "",
            "video_source_type": "mp4",
            "video_source_url": "",
            "video_audio_enabled": "0",
            "video_volume": "80",
            "media_fullscreen_enabled": "0",
            "bank_qr_url": "",
            # Custom Drag & Resize Layout System
            "custom_layout_enabled": "0",
            "layout_edit_mode": "0",
            "custom_layout_zones": '{"media_stage":{"x":30,"y":270,"width":1250,"height":730},"sidebar_takwim":{"x":1300,"y":270,"width":590,"height":730},"pip_overlay":{"x":1340,"y":650,"width":540,"height":320}}',
            # Azan MP3 Audio Management
            "audio_azan_subuh": "azan_subuh_special.mp3",
            "audio_azan_regular": "azan_mekah.mp3",
            "audio_volume": "80",
            # PTZ / Broadcast Camera Integration (Supports Auto, USB V4L2 HDMI Capture, or Network RTSP)
            "camera_source_type": "auto",
            "camera_device": "/dev/video0",
            "camera_rtsp_url": "",
            # Pre-Azan Quran Recitation / Tarhim System
            "quran_pre_azan_enabled": "1",
            "quran_pre_azan_lead_minutes": "10",
            "quran_pre_azan_mode": "random",  # 'random', 'sequence', 'specific'
            "quran_pre_azan_file": "",
            "quran_pre_azan_prayers": '["subuh","zohor","asar","maghrib","isyak","jumaat"]',
            "quran_pre_azan_volume": "70",
            # Aliases for backwards compatibility
            "audio_azan_subuh_file": "azan_subuh_special.mp3",
            "audio_azan_standard_file": "azan_mekah.mp3",
            "audio_azan_volume": "80",
            # Maintenance & Kiosk Security PIN
            "kiosk_pin": "1234",
            "admin_pin": "1234",
            "maintenance_pin": "1234",
            "screen_lock_pin": "1234"
        }

        with self.get_connection() as conn:
            cursor = conn.cursor()
            for k, v in defaults.items():
                cursor.execute("INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)", (k, v))

            # Default slides if table is empty
            cursor.execute("SELECT COUNT(*) FROM slides")
            if cursor.fetchone()[0] == 0:
                now = 1774715500
                initial_slides = [
                    ("Adab & Hadis Masjid", "/assets/slides/slide1.svg", "image", 1, 12, 1, now),
                    ("Peringatan Rapatkan Saf", "/assets/slides/slide2.svg", "image", 2, 12, 1, now),
                    ("Tabung Infaq & Wakaf", "/assets/slides/slide3.svg", "image", 3, 15, 1, now)
                ]
                cursor.executemany("""
                INSERT INTO slides (title, file_url, media_type, sort_order, duration, enabled, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """, initial_slides)

            conn.commit()

    # ==================== SETTINGS API ====================
    def get_all_settings(self) -> Dict[str, str]:
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT key, value FROM settings")
            rows = cursor.fetchall()
            return {row["key"]: row["value"] for row in rows}

    def get_setting(self, key: str, default: str = "") -> str:
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT value FROM settings WHERE key = ?", (key,))
            row = cursor.fetchone()
            return row["value"] if row else default

    def verify_maintenance_pin(self, pin: str) -> bool:
        """
        Validates 4-digit maintenance/kiosk PIN against database setting or optional settings.json.
        Default PIN is '1234'.
        """
        clean_pin = str(pin).strip()
        if not clean_pin:
            return False

        # 1. Check settings.json override if present
        settings_paths = [
            Path("/var/lib/esolat/data/settings.json"),
            Path("/opt/esolat/config/settings.json"),
            Path("./data/settings.json"),
            Path("./settings.json")
        ]
        for sp in settings_paths:
            if sp.exists():
                try:
                    with open(sp, "r") as f:
                        data = json.load(f)
                        cfg_pin = str(data.get("kiosk_pin") or data.get("admin_pin") or data.get("maintenance_pin") or data.get("pin") or "").strip()
                        if cfg_pin and clean_pin == cfg_pin:
                            return True
                except Exception:
                    pass

        # 2. Check Database settings (kiosk_pin, admin_pin, maintenance_pin, screen_lock_pin)
        db_pin = (self.get_setting("kiosk_pin", "") or "").strip()
        if not db_pin:
            db_pin = (self.get_setting("admin_pin", "") or "").strip()
        if not db_pin:
            db_pin = (self.get_setting("maintenance_pin", "") or "").strip()
        if not db_pin:
            db_pin = (self.get_setting("screen_lock_pin", "") or "").strip()
        if not db_pin:
            db_pin = "1234"
        return clean_pin == db_pin

    def set_maintenance_pin(self, pin: str):
        """Sets 4-digit maintenance / kiosk PIN."""
        clean_pin = str(pin).strip()
        self.update_settings({
            "kiosk_pin": clean_pin,
            "admin_pin": clean_pin,
            "maintenance_pin": clean_pin
        })

    def update_settings(self, updates: Dict[str, Any]):
        synced_updates = dict(updates)

        # 1. Layout Mode synchronization
        if "kiosk_layout_mode" in synced_updates:
            mode = str(synced_updates["kiosk_layout_mode"]).lower()
            synced_updates["media_fullscreen_enabled"] = "1" if mode == "fullscreen" else "0"
        elif "media_fullscreen_enabled" in synced_updates:
            is_fs = str(synced_updates["media_fullscreen_enabled"]) in ["1", "true", "True"]
            synced_updates["kiosk_layout_mode"] = "fullscreen" if is_fs else "split"

        # 2. Media Source & URL synchronization
        if "media_source_type" in synced_updates and "video_source_type" not in synced_updates:
            mst = str(synced_updates["media_source_type"]).lower()
            if mst == "video":
                synced_updates["video_source_type"] = "mp4"
            elif mst == "stream":
                synced_updates["video_source_type"] = "hls"
            else:
                synced_updates["video_source_type"] = mst
        elif "video_source_type" in synced_updates and "media_source_type" not in synced_updates:
            vst = str(synced_updates["video_source_type"]).lower()
            if vst == "mp4":
                synced_updates["media_source_type"] = "video"
            elif vst in ["hls", "youtube"]:
                synced_updates["media_source_type"] = "stream"
            else:
                synced_updates["media_source_type"] = vst

        if "media_stream_url" in synced_updates and "video_source_url" not in synced_updates:
            synced_updates["video_source_url"] = synced_updates["media_stream_url"]
        elif "video_source_url" in synced_updates and "media_stream_url" not in synced_updates:
            synced_updates["media_stream_url"] = synced_updates["video_source_url"]

        # 3. Aliasing synchronization for azan audio settings
        if "audio_azan_subuh" in synced_updates and "audio_azan_subuh_file" not in synced_updates:
            synced_updates["audio_azan_subuh_file"] = synced_updates["audio_azan_subuh"]
        elif "audio_azan_subuh_file" in synced_updates and "audio_azan_subuh" not in synced_updates:
            synced_updates["audio_azan_subuh"] = synced_updates["audio_azan_subuh_file"]

        if "audio_azan_regular" in synced_updates and "audio_azan_standard_file" not in synced_updates:
            synced_updates["audio_azan_standard_file"] = synced_updates["audio_azan_regular"]
        elif "audio_azan_standard_file" in synced_updates and "audio_azan_regular" not in synced_updates:
            synced_updates["audio_azan_regular"] = synced_updates["audio_azan_standard_file"]

        if "audio_volume" in synced_updates and "audio_azan_volume" not in synced_updates:
            synced_updates["audio_azan_volume"] = synced_updates["audio_volume"]
        elif "audio_azan_volume" in synced_updates and "audio_volume" not in synced_updates:
            synced_updates["audio_volume"] = synced_updates["audio_azan_volume"]

        with self.get_connection() as conn:
            cursor = conn.cursor()
            for k, v in synced_updates.items():
                cursor.execute("""
                INSERT INTO settings (key, value) VALUES (?, ?)
                ON CONFLICT(key) DO UPDATE SET value = excluded.value
                """, (k, str(v)))
            conn.commit()

    # ==================== AUTH ====================
    def verify_admin_login(self, username: str, password: str) -> bool:
        clean_user = str(username or "").strip().lower()
        raw_pass = str(password or "")
        clean_pass = raw_pass.strip()

        if not clean_user:
            return False

        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT value FROM settings WHERE key = 'admin_user'")
            user_row = cursor.fetchone()
            cursor.execute("SELECT value FROM settings WHERE key = 'admin_password_hash'")
            pass_row = cursor.fetchone()

            db_user = (user_row["value"] if user_row else DEFAULT_ADMIN_USER).strip().lower()
            db_pass = pass_row["value"] if pass_row else hash_password(DEFAULT_ADMIN_PASS)

            if clean_user == db_user:
                # 1. Exact hash check on cleaned or raw password
                if hash_password(clean_pass) == db_pass or hash_password(raw_pass) == db_pass:
                    return True

                # 2. If DB has blank password / default blank hash, allow empty password
                if db_pass in ["", hash_password("")]:
                    if clean_pass == "":
                        return True

                # 3. If password in DB is default or unconfigured, allow blank or standard defaults
                if db_pass in [hash_password("admin@surau"), hash_password(""), "", hash_password("123456"), hash_password("admin")]:
                    if clean_pass in ["", "admin@surau", "admin@esolat", "123456", "admin123", "admin", "1234"]:
                        return True

            return False

    def change_admin_password(self, new_password: str):
        with self.get_connection() as conn:
            cursor = conn.cursor()
            new_hash = hash_password(new_password)
            cursor.execute("UPDATE settings SET value = ? WHERE key = 'admin_password_hash'", (new_hash,))
            cursor.execute("UPDATE settings SET value = '0' WHERE key = 'force_password_change'")
            conn.commit()

    # ==================== PRAYER SCHEDULE ====================
    def save_prayer_times(self, zone: str, entries: List[Dict[str, Any]]):
        import time
        now = int(time.time())
        with self.get_connection() as conn:
            cursor = conn.cursor()
            for e in entries:
                cursor.execute("""
                INSERT INTO prayer_schedule (zone, date, hijri, day, imsak, fajr, syuruk, dhuha, dhuhr, asr, maghrib, isha, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(zone, date) DO UPDATE SET
                    hijri = excluded.hijri,
                    day = excluded.day,
                    imsak = excluded.imsak,
                    fajr = excluded.fajr,
                    syuruk = excluded.syuruk,
                    dhuha = excluded.dhuha,
                    dhuhr = excluded.dhuhr,
                    asr = excluded.asr,
                    maghrib = excluded.maghrib,
                    isha = excluded.isha,
                    updated_at = excluded.updated_at
                """, (
                    zone,
                    e.get("date"),
                    e.get("hijri", ""),
                    e.get("day", ""),
                    e.get("imsak", ""),
                    e.get("fajr", ""),
                    e.get("syuruk", ""),
                    e.get("dhuha", ""),
                    e.get("dhuhr", ""),
                    e.get("asr", ""),
                    e.get("maghrib", ""),
                    e.get("isha", ""),
                    now
                ))
            conn.commit()

    def get_prayer_for_date(self, zone: str, date_str: str, candidate_keys: Optional[List[str]] = None) -> Optional[Dict[str, Any]]:
        with self.get_connection() as conn:
            cursor = conn.cursor()
            if candidate_keys and len(candidate_keys) > 0:
                placeholders = ",".join(["?"] * len(candidate_keys))
                query = f"SELECT * FROM prayer_schedule WHERE zone = ? AND date IN ({placeholders}) LIMIT 1"
                params = [zone] + list(candidate_keys)
                cursor.execute(query, params)
            else:
                cursor.execute("SELECT * FROM prayer_schedule WHERE zone = ? AND date = ?", (zone, date_str))
            row = cursor.fetchone()
            return dict(row) if row else None

    # ==================== SLIDES ====================
    def get_slides(self, enabled_only: bool = False) -> List[Dict[str, Any]]:
        with self.get_connection() as conn:
            cursor = conn.cursor()
            query = "SELECT * FROM slides"
            if enabled_only:
                query += " WHERE enabled = 1"
            query += " ORDER BY sort_order ASC, id ASC"
            cursor.execute(query)
            return [dict(row) for row in cursor.fetchall()]

    def add_slide(self, title: str, file_url: str, media_type: str = "image", duration: int = 10, sort_order: int = 0) -> int:
        import time
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
            INSERT INTO slides (title, file_url, media_type, sort_order, duration, enabled, created_at)
            VALUES (?, ?, ?, ?, ?, 1, ?)
            """, (title, file_url, media_type, sort_order, duration, int(time.time())))
            conn.commit()
            return cursor.lastrowid

    def delete_slide(self, slide_id: int):
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM slides WHERE id = ?", (slide_id,))
            conn.commit()

    def update_slide(self, slide_id: int, updates: Dict[str, Any]):
        fields = []
        vals = []
        for k, v in updates.items():
            if k in ["title", "sort_order", "duration", "enabled"]:
                fields.append(f"{k} = ?")
                vals.append(v)
        if not fields:
            return
        vals.append(slide_id)
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(f"UPDATE slides SET {', '.join(fields)} WHERE id = ?", vals)
            conn.commit()

    # ==================== AUDIO TRACKS ====================
    def get_all_audio_tracks(self) -> Dict[str, Dict[str, Any]]:
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM audio_tracks")
            rows = cursor.fetchall()
            return {row["file_name"]: dict(row) for row in rows}

    def set_audio_track(self, file_name: str, label: str, audio_type: str = "mp3", is_subuh: int = 0, is_preset: int = 0, size_bytes: int = 0, updated_at: int = 0):
        import time
        if not updated_at:
            updated_at = int(time.time())
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
            INSERT INTO audio_tracks (file_name, label, type, is_subuh, is_preset, size_bytes, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(file_name) DO UPDATE SET
                label = excluded.label,
                type = excluded.type,
                is_subuh = excluded.is_subuh,
                is_preset = excluded.is_preset,
                size_bytes = excluded.size_bytes,
                updated_at = excluded.updated_at
            """, (file_name, label, audio_type, is_subuh, is_preset, size_bytes, updated_at))
            conn.commit()

    def delete_audio_track(self, file_name: str):
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM audio_tracks WHERE file_name = ?", (file_name,))
            conn.commit()

    # ==================== CUSTOM CANVAS LAYOUT ZONES ====================
    def get_custom_layout_zones(self) -> Dict[str, Any]:
        default_zones = {
            "media_stage": {"x": 30, "y": 270, "width": 1250, "height": 730},
            "sidebar_takwim": {"x": 1300, "y": 270, "width": 590, "height": 730},
            "pip_overlay": {"x": 1340, "y": 650, "width": 540, "height": 320}
        }
        raw = self.get_setting("custom_layout_zones", "")
        if raw:
            try:
                import json
                parsed = json.loads(raw)
                if isinstance(parsed, dict):
                    for k, v in default_zones.items():
                        if k not in parsed:
                            parsed[k] = v
                    return parsed
            except Exception:
                pass
        return default_zones

    def update_custom_layout_zone(self, zone_id: str, x: int, y: int, width: int, height: int) -> Dict[str, Any]:
        import json
        zones = self.get_custom_layout_zones()
        zones[zone_id] = {
            "x": int(x),
            "y": int(y),
            "width": int(width),
            "height": int(height)
        }
        self.update_settings({
            "custom_layout_zones": json.dumps(zones),
            "custom_layout_enabled": "1"
        })
        return zones

    def save_all_custom_layout_zones(self, zones: Dict[str, Any]) -> Dict[str, Any]:
        import json
        curr = self.get_custom_layout_zones()
        for k, v in zones.items():
            if isinstance(v, dict):
                curr[k] = {
                    "x": int(v.get("x", 0)),
                    "y": int(v.get("y", 0)),
                    "width": int(v.get("width", 200)),
                    "height": int(v.get("height", 150))
                }
        self.update_settings({
            "custom_layout_zones": json.dumps(curr),
            "custom_layout_enabled": "1"
        })
        return curr

    def reset_custom_layout(self) -> Dict[str, Any]:
        import json
        default_zones = {
            "media_stage": {"x": 30, "y": 270, "width": 1250, "height": 730},
            "sidebar_takwim": {"x": 1300, "y": 270, "width": 590, "height": 730},
            "pip_overlay": {"x": 1340, "y": 650, "width": 540, "height": 320}
        }
        self.update_settings({
            "custom_layout_enabled": "0",
            "layout_edit_mode": "0",
            "custom_layout_zones": json.dumps(default_zones)
        })
        return default_zones

