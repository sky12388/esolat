"""
Hardware & Network Diagnostic Suite for Skywalker e-Solat System
Scans local IP network (detects PTZ cameras/RTSP), USB media capture devices,
HDMI display outputs, audio interfaces, and system listening ports.
Zero external pip dependencies (Pure Python 3 standard library + Linux sysfs/tools).
"""

import os
import sys
import glob
import time
import socket
import shutil
import subprocess
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Dict, Any, List, Optional

class SystemDiagnostics:
    @staticmethod
    def get_local_subnet_ips() -> List[str]:
        """
        Discovers the primary local subnet (e.g. 192.168.1.0/24)
        """
        ips = []
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.settimeout(0.5)
            s.connect(("8.8.8.8", 80))
            local_ip = s.getsockname()[0]
            s.close()
            
            parts = local_ip.split(".")
            if len(parts) == 4 and not local_ip.startswith("127."):
                subnet_prefix = f"{parts[0]}.{parts[1]}.{parts[2]}"
                for i in range(1, 255):
                    ips.append(f"{subnet_prefix}.{i}")
        except Exception:
            pass
        return ips

    @staticmethod
    def scan_network_devices(timeout: float = 0.4, max_workers: int = 40) -> List[Dict[str, Any]]:
        """
        Fast multi-threaded scanner across local subnet to find active IPs,
        RTSP cameras (port 554), web portals (port 80/8080/8000), and ONVIF devices.
        """
        # 1. Read existing ARP neighbor table first (instant response)
        arp_devices = {}
        try:
            if Path("/proc/net/arp").exists():
                with open("/proc/net/arp", "r") as f:
                    lines = f.readlines()[1:]
                    for line in lines:
                        parts = line.split()
                        if len(parts) >= 4:
                            ip = parts[0]
                            mac = parts[3]
                            device = parts[5] if len(parts) > 5 else "eth0"
                            if mac != "00:00:00:00:00:00" and not ip.startswith("127."):
                                arp_devices[ip] = {"mac": mac, "interface": device}
        except Exception:
            pass

        subnet_ips = SystemDiagnostics.get_local_subnet_ips()
        if not subnet_ips and arp_devices:
            subnet_ips = list(arp_devices.keys())

        results = []

        def check_host(ip: str):
            # Check common camera & management ports
            ports_to_check = [
                (554, "RTSP Camera"),
                (80, "HTTP / Web UI"),
                (8080, "e-Solat / Alt Web"),
                (8000, "Hikvision / DVR"),
                (37777, "Dahua DVR"),
                (22, "SSH")
            ]
            
            open_ports = []
            is_camera = False
            is_alive = False

            # If present in ARP table, mark as alive
            if ip in arp_devices:
                is_alive = True

            for port, label in ports_to_check:
                try:
                    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                    sock.settimeout(timeout)
                    res = sock.connect_ex((ip, port))
                    sock.close()
                    if res == 0:
                        is_alive = True
                        open_ports.append({"port": port, "service": label})
                        if port in [554, 8000, 37777]:
                            is_camera = True
                except Exception:
                    pass

            if is_alive:
                # Try resolving hostname
                hostname = ""
                try:
                    hostname = socket.gethostbyaddr(ip)[0]
                except Exception:
                    hostname = ""

                mac_info = arp_devices.get(ip, {})
                device_type = "Kamera PTZ / IP Stream" if is_camera else ("Penghala / Komputer" if open_ports else "Peranti Rangkaian")

                results.append({
                    "ip": ip,
                    "hostname": hostname,
                    "mac": mac_info.get("mac", "Tidak diketahui"),
                    "interface": mac_info.get("interface", "lan"),
                    "open_ports": open_ports,
                    "is_camera": is_camera,
                    "device_type": device_type,
                    "suggested_rtsp": f"rtsp://admin:password@{ip}:554/live/ch0" if is_camera else ""
                })

        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            executor.map(check_host, subnet_ips)

        # Sort: Cameras first, then by IP
        def sort_key(d):
            is_cam = 0 if d["is_camera"] else 1
            try:
                ip_num = tuple(int(x) for x in d["ip"].split("."))
            except Exception:
                ip_num = (0, 0, 0, 0)
            return (is_cam, ip_num)

        return sorted(results, key=sort_key)

    @staticmethod
    def scan_usb_and_media_devices() -> Dict[str, Any]:
        """
        Scans V4L2 video capture devices (/dev/video*), USB HDMI grabbers,
        and connected USB hardware.
        """
        video_devices = []
        for dev_path in sorted(glob.glob("/dev/video*")):
            dev_num = dev_path.replace("/dev/video", "")
            sysfs_name_path = f"/sys/class/video4linux/video{dev_num}/name"
            name = "Peranti Video V4L2"
            if Path(sysfs_name_path).exists():
                try:
                    with open(sysfs_name_path, "r") as f:
                        name = f.read().strip()
                except Exception:
                    pass

            is_capture_card = any(k in name.lower() for k in ["hdmi", "capture", "cam", "video", "usb", "uvc"])
            video_devices.append({
                "device": dev_path,
                "name": name,
                "is_capture_card": is_capture_card,
                "type": "HDMI Capture Card / USB Camera" if is_capture_card else "V4L2 Video Node"
            })

        # USB Devices via lsusb or sysfs
        usb_list = []
        if shutil.which("lsusb"):
            try:
                out = subprocess.check_output(["lsusb"], text=True, timeout=2)
                for line in out.strip().split("\n"):
                    line = line.strip()
                    if line:
                        usb_list.append(line)
            except Exception:
                pass

        # Block storage devices (USB Flash drives)
        storage_list = []
        if shutil.which("lsblk"):
            try:
                out = subprocess.check_output(["lsblk", "-o", "NAME,SIZE,TYPE,MOUNTPOINT,LABEL", "-n"], text=True, timeout=2)
                for line in out.strip().split("\n"):
                    line = line.strip()
                    if line:
                        storage_list.append(line)
            except Exception:
                pass

        return {
            "video_devices": video_devices,
            "total_video_nodes": len(video_devices),
            "usb_hardware": usb_list,
            "storage_devices": storage_list
        }

    @staticmethod
    def scan_hdmi_and_displays() -> Dict[str, Any]:
        """
        Detects connected HDMI screens, resolution, and DRM display status.
        """
        displays = []
        drm_connectors = glob.glob("/sys/class/drm/card*-*/status")
        for status_file in sorted(drm_connectors):
            try:
                connector_dir = Path(status_file).parent
                conn_name = connector_dir.name.replace("card0-", "").replace("card1-", "")
                with open(status_file, "r") as f:
                    status = f.read().strip()  # "connected" or "disconnected"

                modes = []
                modes_file = connector_dir / "modes"
                if modes_file.exists():
                    with open(modes_file, "r") as mf:
                        modes = [m.strip() for m in mf.readlines() if m.strip()]

                enabled = False
                enabled_file = connector_dir / "enabled"
                if enabled_file.exists():
                    with open(enabled_file, "r") as ef:
                        enabled = (ef.read().strip() == "enabled")

                is_hdmi = "hdmi" in conn_name.lower() or "dp" in conn_name.lower() or "vga" in conn_name.lower()
                displays.append({
                    "port": conn_name,
                    "status": status,
                    "connected": status == "connected",
                    "is_hdmi": is_hdmi,
                    "active_mode": modes[0] if modes else "Tidak dinyatakan",
                    "supported_modes": modes[:5],
                    "enabled": enabled
                })
            except Exception:
                continue

        # Optional xrandr query if available
        xrandr_summary = []
        if shutil.which("xrandr") and os.environ.get("DISPLAY"):
            try:
                out = subprocess.check_output(["xrandr", "--query"], text=True, timeout=2)
                for line in out.strip().split("\n"):
                    if " connected" in line:
                        xrandr_summary.append(line.strip())
            except Exception:
                pass

        return {
            "displays": displays,
            "connected_count": sum(1 for d in displays if d["connected"]),
            "xrandr_summary": xrandr_summary
        }

    @staticmethod
    def scan_audio_devices() -> Dict[str, Any]:
        """
        Scans ALSA audio playback and capture sound cards.
        """
        playback_cards = []
        capture_cards = []

        if shutil.which("aplay"):
            try:
                out = subprocess.check_output(["aplay", "-l"], text=True, timeout=2)
                for line in out.strip().split("\n"):
                    if line.startswith("card "):
                        playback_cards.append(line.strip())
            except Exception:
                pass

        if shutil.which("arecord"):
            try:
                out = subprocess.check_output(["arecord", "-l"], text=True, timeout=2)
                for line in out.strip().split("\n"):
                    if line.startswith("card "):
                        capture_cards.append(line.strip())
            except Exception:
                pass

        # ALSA cards from proc
        proc_cards = []
        if Path("/proc/asound/cards").exists():
            try:
                with open("/proc/asound/cards", "r") as f:
                    proc_cards = [line.strip() for line in f.readlines() if line.strip()]
            except Exception:
                pass

        return {
            "playback_devices": playback_cards,
            "capture_devices": capture_cards,
            "proc_soundcards": proc_cards
        }

    @staticmethod
    def scan_ports_and_services() -> List[Dict[str, Any]]:
        """
        Scans listening TCP ports on the system.
        """
        ports = []
        if shutil.which("ss"):
            try:
                out = subprocess.check_output(["ss", "-tulpn"], text=True, timeout=2)
                lines = out.strip().split("\n")[1:]
                for line in lines:
                    parts = line.split()
                    if len(parts) >= 5:
                        proto = parts[0]
                        state = parts[1]
                        local_addr = parts[4]
                        proc_info = parts[6] if len(parts) > 6 else ""
                        ports.append({
                            "protocol": proto,
                            "state": state,
                            "local_address": local_addr,
                            "process": proc_info
                        })
            except Exception:
                pass
        return ports

    @classmethod
    def run_full_diagnostics(cls, scan_network: bool = True) -> Dict[str, Any]:
        """
        Runs comprehensive system & hardware diagnostic report.
        """
        start_time = time.time()
        
        media_info = cls.scan_usb_and_media_devices()
        hdmi_info = cls.scan_hdmi_and_displays()
        audio_info = cls.scan_audio_devices()
        ports_info = cls.scan_ports_and_services()
        network_devices = cls.scan_network_devices() if scan_network else []

        duration = round(time.time() - start_time, 2)

        return {
            "success": True,
            "timestamp": int(time.time()),
            "scan_duration_seconds": duration,
            "summary": {
                "cameras_and_capture_cards": len(media_info.get("video_devices", [])),
                "connected_screens": hdmi_info.get("connected_count", 0),
                "network_devices_found": len(network_devices),
                "audio_outputs": len(audio_info.get("playback_devices", []))
            },
            "media_and_usb": media_info,
            "hdmi_and_displays": hdmi_info,
            "audio_hardware": audio_info,
            "listening_ports": ports_info,
            "network_scan": network_devices
        }
