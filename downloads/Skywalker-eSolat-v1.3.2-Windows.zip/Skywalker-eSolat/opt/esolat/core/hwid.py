"""
Hardware Fingerprint Generator for Mosque Digital Signage & e-Solat System
Extracts Motherboard UUID + Primary Network MAC address, hashed into tidy format:
SURAU-XXXX-XXXX-XXXX
"""

import os
import sys
import hashlib
import glob
import re
import subprocess
import uuid as py_uuid

SYSTEM_HW_SALT = "ESOLAT-SYSTEM-HWID-SALT-V1-2026-MALAYSIA"

def get_motherboard_uuid() -> str:
    """
    Extracts motherboard / system UUID across Linux and Windows.
    """
    if sys.platform == "win32":
        try:
            # 1. PowerShell CIM Query (Modern Windows 10/11/Server)
            cmd = ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", "(Get-CimInstance -ClassName Win32_ComputerSystemProduct).UUID"]
            out = subprocess.check_output(cmd, stderr=subprocess.DEVNULL, timeout=4, text=True).strip()
            if out and len(out) >= 16 and out != "00000000-0000-0000-0000-000000000000":
                return out.lower()
        except Exception:
            pass

        try:
            # 2. WMIC fallback
            cmd = ["wmic", "csproduct", "get", "uuid"]
            out = subprocess.check_output(cmd, stderr=subprocess.DEVNULL, timeout=4, text=True)
            lines = [line.strip() for line in out.splitlines() if line.strip() and "UUID" not in line.upper()]
            if lines and len(lines[0]) >= 16:
                return lines[0].lower()
        except Exception:
            pass

        return "win-00112233-4455-6677-8899-aabbccddeeff"

    candidates = [
        "/sys/class/dmi/id/product_uuid",
        "/sys/devices/virtual/dmi/id/product_uuid",
        "/etc/machine-id",
        "/var/lib/dbus/machine-id"
    ]
    for path in candidates:
        try:
            if os.path.exists(path) and os.access(path, os.R_OK):
                with open(path, "r", encoding="utf-8") as f:
                    val = f.read().strip()
                    if val and val != "00000000-0000-0000-0000-000000000000":
                        return val.lower()
        except Exception:
            continue
            
    # Generic fallback
    return "00112233-4455-6677-8899-aabbccddeeff"

def get_primary_mac_address() -> str:
    """
    Finds primary non-loopback MAC address across Linux and Windows.
    """
    if sys.platform == "win32":
        try:
            node = py_uuid.getnode()
            mac = ':'.join(f"{(node >> i) & 0xff:02x}" for i in range(0, 48, 8)[::-1])
            if mac and mac != "00:00:00:00:00:00":
                return mac.lower()
        except Exception:
            pass
        return "02:00:00:00:00:01"
    # Try finding default route interface from /proc/net/route
    default_iface = None
    try:
        if os.path.exists("/proc/net/route"):
            with open("/proc/net/route", "r") as f:
                for line in f:
                    parts = line.strip().split()
                    # Iface Destination Gateway Flags ...
                    if len(parts) >= 2 and parts[1] == "00000000":
                        default_iface = parts[0]
                        break
    except Exception:
        pass

    if default_iface:
        addr_file = f"/sys/class/net/{default_iface}/address"
        try:
            if os.path.exists(addr_file):
                with open(addr_file, "r") as f:
                    mac = f.read().strip().lower()
                    if mac and mac != "00:00:00:00:00:00":
                        return mac
        except Exception:
            pass

    # Scan /sys/class/net/*/address
    for addr_file in sorted(glob.glob("/sys/class/net/*/address")):
        iface = os.path.basename(os.path.dirname(addr_file))
        if iface.startswith(("lo", "docker", "veth", "virbr", "br-", "tun", "tap")):
            continue
        try:
            with open(addr_file, "r") as f:
                mac = f.read().strip().lower()
                if mac and mac != "00:00:00:00:00:00":
                    return mac
        except Exception:
            continue

    return "02:00:00:00:00:01"

def get_hardware_id() -> str:
    """
    Computes a deterministic, tidy 16-character payload formatted as:
    ESOLAT-XXXX-XXXX-XXXX
    """
    override = os.environ.get("ESOLAT_MOCK_HWID")
    if override and re.match(r"^(ESOLAT|SURAU|MASJID|SKY)-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}$", override):
        return override

    uuid_val = get_motherboard_uuid()
    mac_val = get_primary_mac_address()

    raw_fingerprint = f"{uuid_val}::{mac_val}::{SYSTEM_HW_SALT}".encode("utf-8")
    digest = hashlib.sha256(raw_fingerprint).hexdigest().upper()

    # Form 3 blocks of 4 alphanumeric chars: ESOLAT-XXXX-XXXX-XXXX
    block1 = digest[0:4]
    block2 = digest[4:8]
    block3 = digest[8:12]

    return f"ESOLAT-{block1}-{block2}-{block3}"

if __name__ == "__main__":
    print(f"Detected HWID: {get_hardware_id()}")
    print(f"Motherboard UUID: {get_motherboard_uuid()}")
    print(f"Primary MAC: {get_primary_mac_address()}")
