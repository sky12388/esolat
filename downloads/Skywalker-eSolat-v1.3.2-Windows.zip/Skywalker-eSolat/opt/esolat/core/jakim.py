"""
JAKIM Takwim Solat Sync & Offline Prayer Calculation Engine
Features:
1. Online sync from Official JAKIM e-solat API (year/month takwim)
2. Local SQLite caching for 100% offline operation
3. Robust astronomical solar calculation fallback (JAKIM parameters: Fajr 20°, Isha 18°, Asr Shafi'i)
4. Accurate Hijri date computation
"""

import json
import time
import math
import urllib.request
import urllib.parse
from datetime import datetime, date, timedelta
from typing import Dict, Any, List, Optional
from .jakim_zones import JAKIM_ZONES, find_nearest_zone

JAKIM_API_BASE = "https://www.e-solat.gov.my/index.php?r=esolatApi/takwimsolat"

MALAY_MONTHS = {
    1: "Jan", 2: "Feb", 3: "Mac", 4: "Apr", 5: "Mei", 6: "Jun",
    7: "Jul", 8: "Ogos", 9: "Sep", 10: "Okt", 11: "Nov", 12: "Dis"
}

ENGLISH_MONTHS = {
    1: "Jan", 2: "Feb", 3: "Mar", 4: "Apr", 5: "May", 6: "Jun",
    7: "Jul", 8: "Aug", 9: "Sep", 10: "Oct", 11: "Nov", 12: "Dec"
}

def get_candidate_date_keys(dt: datetime) -> List[str]:
    """
    Generates all possible representations of a date for JAKIM API matching:
    e.g. '01-Okt-2026', '01-Oct-2026', '1-Okt-2026', '1-Oct-2026', '2026-10-01'
    """
    d_two = f"{dt.day:02d}"
    d_one = str(dt.day)
    m_my = MALAY_MONTHS.get(dt.month, "")
    m_en = ENGLISH_MONTHS.get(dt.month, "")
    m_num = f"{dt.month:02d}"
    y = str(dt.year)

    candidates = [
        f"{d_two}-{m_my}-{y}",
        f"{d_two}-{m_en}-{y}",
        f"{d_one}-{m_my}-{y}",
        f"{d_one}-{m_en}-{y}",
        f"{y}-{m_num}-{d_two}",
        dt.strftime("%d-%b-%Y"),
        dt.strftime("%d-%B-%Y")
    ]
    # Deduplicate while preserving order
    return list(dict.fromkeys(candidates))

class JakimManager:
    def __init__(self, db):
        self.db = db

    def sync_takwim_for_zone(self, zone: str, period: str = "month") -> Dict[str, Any]:
        """
        Fetches official takwim from JAKIM API and saves into SQLite.
        """
        headers = {
            "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) eSolatKiosk/1.0"
        }
        url = f"{JAKIM_API_BASE}&period={period}&zone={urllib.parse.quote(zone)}"

        try:
            req = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(req, timeout=12) as response:
                if response.status == 200:
                    raw_data = response.read().decode("utf-8")
                    data = json.loads(raw_data)
                    prayer_list = data.get("prayerTime", [])
                    if prayer_list:
                        self.db.save_prayer_times(zone, prayer_list)
                        return {
                            "success": True,
                            "count": len(prayer_list),
                            "zone": zone,
                            "period": period,
                            "message": f"Berjaya memuat turun {len(prayer_list)} rekod takwim untuk zon {zone} dari JAKIM."
                        }
                    else:
                        return {"success": False, "message": "Tiada data jadual waktu solat diterima daripada JAKIM."}
        except Exception as e:
            # If annual/monthly fetch failed, try today
            return {"success": False, "message": f"Gagal menghubungi pelayan e-solat JAKIM: {str(e)}"}

    def get_today_prayer_times(self, zone: str, target_dt: datetime = None) -> Dict[str, Any]:
        """
        Retrieves today's prayer times for the specified zone.
        Tries:
        1. Local SQLite cache (matching all Malay & English date keys)
        2. Live JAKIM API
        3. Built-in Offline Astronomical Engine fallback
        """
        if target_dt is None:
            target_dt = datetime.now()

        candidate_keys = get_candidate_date_keys(target_dt)

        # 1. Check DB Cache
        cached = self.db.get_prayer_for_date(zone, candidate_keys[0], candidate_keys=candidate_keys)
        if cached:
            return cached

        # 2. Try fetching from JAKIM online
        sync_res = self.sync_takwim_for_zone(zone, period="month")
        if sync_res.get("success"):
            cached = self.db.get_prayer_for_date(zone, candidate_keys[0], candidate_keys=candidate_keys)
            if cached:
                return cached

        # 3. Fallback to Offline Astronomical Calculation
        return self.calculate_offline_times(zone, target_dt)

    def calculate_offline_times(self, zone: str, dt: datetime) -> Dict[str, Any]:
        """
        Astronomical calculation engine tailored to Malaysia (JAKIM standard):
        - Fajr: Sun altitude -20°
        - Sunrise / Syuruk: Sun altitude -0.833°
        - Asr: Shadow factor = 1 (Shafi'i)
        - Maghrib: Sun altitude -0.833°
        - Isha: Sun altitude -18°
        """
        # Lookup zone coordinates
        zone_info = next((z for z in JAKIM_ZONES if z["code"] == zone), JAKIM_ZONES[0])
        lat = zone_info["lat"]
        lon = zone_info["lon"]
        tz = 8.0 # Malaysia UTC+8

        # Day of year
        day_of_year = dt.timetuple().tm_yday
        year = dt.year

        # Solar calculations
        # B in radians
        B = 2 * math.pi * (day_of_year - 81) / 365.0
        # Equation of Time in minutes
        EoT = 9.87 * math.sin(2 * B) - 7.53 * math.cos(B) - 1.5 * math.sin(B)
        # Solar declination in degrees
        declination = 23.45 * math.sin(math.radians(360.0 / 365.0 * (day_of_year - 81)))
        dec_rad = math.radians(declination)
        lat_rad = math.radians(lat)

        # Solar noon (Zohor) in hours (Local Standard Time)
        # Local Solar Time = LST + (4 * (lon - 15 * tz) + EoT) / 60
        solar_noon = 12.0 - (4.0 * (lon - 15.0 * tz) + EoT) / 60.0

        def hour_angle_for_altitude(alt_deg):
            alt_rad = math.radians(alt_deg)
            cos_ha = (math.sin(alt_rad) - math.sin(lat_rad) * math.sin(dec_rad)) / (math.cos(lat_rad) * math.cos(dec_rad))
            if cos_ha < -1.0: return math.pi
            if cos_ha > 1.0: return 0.0
            return math.acos(cos_ha)

        # Fajr: -20°
        ha_fajr = hour_angle_for_altitude(-20.0)
        t_fajr = solar_noon - math.degrees(ha_fajr) / 15.0

        # Syuruk: -0.833°
        ha_syuruk = hour_angle_for_altitude(-0.833)
        t_syuruk = solar_noon - math.degrees(ha_syuruk) / 15.0

        # Dhuha: ~4.5°
        ha_dhuha = hour_angle_for_altitude(4.5)
        t_dhuha = solar_noon - math.degrees(ha_dhuha) / 15.0

        # Zohor: solar noon + 2 minutes safety margin
        t_dhuhr = solar_noon + 2.0 / 60.0

        # Asr: Shafi'i shadow factor = 1 -> altitude = arccot(1 + tan|lat - dec|)
        alt_asr = math.degrees(math.atan(1.0 / (1.0 + math.tan(abs(lat_rad - dec_rad)))))
        ha_asr = hour_angle_for_altitude(alt_asr)
        t_asr = solar_noon + math.degrees(ha_asr) / 15.0

        # Maghrib: -0.833° + 2 minutes margin
        t_maghrib = solar_noon + math.degrees(ha_syuruk) / 15.0 + 2.0 / 60.0

        # Isha: -18°
        ha_isha = hour_angle_for_altitude(-18.0)
        t_isha = solar_noon + math.degrees(ha_isha) / 15.0

        # Imsak: 10 minutes before Fajr
        t_imsak = t_fajr - (10.0 / 60.0)

        def to_time_str(h_float):
            total_sec = int(round(h_float * 3600.0))
            hours = (total_sec // 3600) % 24
            minutes = (total_sec % 3600) // 60
            seconds = total_sec % 60
            return f"{hours:02d}:{minutes:02d}:{seconds:02d}"

        # Approximate Hijri Date
        hijri_str = self.gregorian_to_hijri(dt)

        return {
            "zone": zone,
            "date": dt.strftime("%d-%b-%Y"),
            "hijri": hijri_str,
            "day": dt.strftime("%A"),
            "imsak": to_time_str(t_imsak),
            "fajr": to_time_str(t_fajr),
            "syuruk": to_time_str(t_syuruk),
            "dhuha": to_time_str(t_dhuha),
            "dhuhr": to_time_str(t_dhuhr),
            "asr": to_time_str(t_asr),
            "maghrib": to_time_str(t_maghrib),
            "isha": to_time_str(t_isha),
            "updated_at": int(time.time()),
            "is_calculated": True
        }

    def gregorian_to_hijri(self, dt: datetime) -> str:
        """
        Converts Gregorian date to approximate Islamic Hijri format (YYYY-MM-DD).
        """
        y, m, d = dt.year, dt.month, dt.day
        if m < 3:
            y -= 1
            m += 12
        a = math.floor(y / 100.0)
        b = 2 - a + math.floor(a / 4.0)
        jd = math.floor(365.25 * (y + 4716)) + math.floor(30.6001 * (m + 1)) + d + b - 1524.5

        # Islamic epoch JD 1948439.5
        l = jd - 1948440 + 10632
        n = math.floor((l - 1) / 10631.0)
        l = l - 10631 * n + 354
        j = (math.floor((10985 - l) / 5316.0)) * (math.floor((50 * l) / 17719.0)) + (math.floor(l / 5670.0)) * (math.floor((43 * l) / 15238.0))
        l = l - (math.floor((30 - j) / 15.0)) * (math.floor((17719 * j) / 50.0)) - (math.floor(j / 16.0)) * (math.floor((15238 * j) / 43.0)) + 29
        m_h = math.floor((24 * l) / 709.0)
        d_h = l - math.floor((709 * m_h) / 24.0)
        y_h = 30 * n + j - 30

        return f"{int(y_h):04d}-{int(m_h):02d}-{int(d_h):02d}"
