"""
JAKIM Malaysian Prayer Zones Database
Contains all 60+ zones across 14 states and federal territories with representative coordinates
for HTML5 GPS Haversine nearest-zone matching.
"""

JAKIM_ZONES = [
    # Wilayah Persekutuan
    {
        "code": "WLY01",
        "state": "Wilayah Persekutuan",
        "location": "Kuala Lumpur, Putrajaya",
        "lat": 3.1390,
        "lon": 101.6869
    },
    {
        "code": "WLY02",
        "state": "Wilayah Persekutuan",
        "location": "Labuan",
        "lat": 5.2831,
        "lon": 115.2308
    },

    # Selangor
    {
        "code": "SGR01",
        "state": "Selangor",
        "location": "Gombak, Petaling, Sepang, Hulu Langat, Hulu Selangor, Shah Alam",
        "lat": 3.0738,
        "lon": 101.5183
    },
    {
        "code": "SGR02",
        "state": "Selangor",
        "location": "Kuala Selangor, Sabak Bernam",
        "lat": 3.3400,
        "lon": 101.2500
    },
    {
        "code": "SGR03",
        "state": "Selangor",
        "location": "Klang, Kuala Langat",
        "lat": 3.0400,
        "lon": 101.4400
    },

    # Johor
    {
        "code": "JHR01",
        "state": "Johor",
        "location": "Pulau Aur dan Pulau Pemanggil",
        "lat": 2.4500,
        "lon": 104.5167
    },
    {
        "code": "JHR02",
        "state": "Johor",
        "location": "Johor Bahru, Kota Tinggi, Pasir Gudang, Kulai",
        "lat": 1.4927,
        "lon": 103.7414
    },
    {
        "code": "JHR03",
        "state": "Johor",
        "location": "Kluang, Pontian",
        "lat": 2.0251,
        "lon": 103.3328
    },
    {
        "code": "JHR04",
        "state": "Johor",
        "location": "Batu Pahat, Muar, Segamat, Tangkak",
        "lat": 1.8548,
        "lon": 102.9325
    },

    # Kedah
    {
        "code": "KDH01",
        "state": "Kedah",
        "location": "Kota Setar, Kubang Pasu, Pokok Sena",
        "lat": 6.1210,
        "lon": 100.3601
    },
    {
        "code": "KDH02",
        "state": "Kedah",
        "location": "Kuala Muda, Yan, Pendang",
        "lat": 5.6470,
        "lon": 100.4877
    },
    {
        "code": "KDH03",
        "state": "Kedah",
        "location": "Padang Terap, Sik",
        "lat": 5.8236,
        "lon": 100.7447
    },
    {
        "code": "KDH04",
        "state": "Kedah",
        "location": "Baling",
        "lat": 5.6764,
        "lon": 100.9167
    },
    {
        "code": "KDH05",
        "state": "Kedah",
        "location": "Bandar Baharu, Kulim",
        "lat": 5.3653,
        "lon": 100.5567
    },
    {
        "code": "KDH06",
        "state": "Kedah",
        "location": "Langkawi",
        "lat": 6.3500,
        "lon": 99.8000
    },
    {
        "code": "KDH07",
        "state": "Kedah",
        "location": "Puncak Gunung Jerai",
        "lat": 5.7947,
        "lon": 100.4358
    },

    # Kelantan
    {
        "code": "KTN01",
        "state": "Kelantan",
        "location": "Bachok, Kota Bharu, Machang, Pasir Mas, Pasir Puteh, Tanah Merah, Tumpat",
        "lat": 6.1254,
        "lon": 102.2386
    },
    {
        "code": "KTN02",
        "state": "Kelantan",
        "location": "Gua Musang, Jeli, Kuala Krai",
        "lat": 4.8823,
        "lon": 101.9686
    },

    # Melaka
    {
        "code": "MLK01",
        "state": "Melaka",
        "location": "Seluruh Negeri Melaka (Melaka Tengah, Alor Gajah, Jasin)",
        "lat": 2.1896,
        "lon": 102.2501
    },

    # Negeri Sembilan
    {
        "code": "NGS01",
        "state": "Negeri Sembilan",
        "location": "Tampin, Jempol",
        "lat": 2.4701,
        "lon": 102.2302
    },
    {
        "code": "NGS02",
        "state": "Negeri Sembilan",
        "location": "Jelebu, Kuala Pilah, Port Dickson, Rembau, Seremban",
        "lat": 2.7258,
        "lon": 101.9424
    },

    # Pahang
    {
        "code": "PHG01",
        "state": "Pahang",
        "location": "Pulau Tioman",
        "lat": 2.7903,
        "lon": 104.1706
    },
    {
        "code": "PHG02",
        "state": "Pahang",
        "location": "Kuantan, Pekan, Muadzam Shah, Rompin",
        "lat": 3.8077,
        "lon": 103.3260
    },
    {
        "code": "PHG03",
        "state": "Pahang",
        "location": "Jerantut, Temerloh, Maran, Bera, Chenor, Jengka",
        "lat": 3.4506,
        "lon": 102.4175
    },
    {
        "code": "PHG04",
        "state": "Pahang",
        "location": "Bentong, Lipis, Raub",
        "lat": 3.7933,
        "lon": 101.8574
    },
    {
        "code": "PHG05",
        "state": "Pahang",
        "location": "Genting Sempah, Janda Baik, Bukit Tinggi",
        "lat": 3.3556,
        "lon": 101.8622
    },
    {
        "code": "PHG06",
        "state": "Pahang",
        "location": "Cameron Highlands, Bukit Fraser, Gunung Tahan",
        "lat": 4.4700,
        "lon": 101.3800
    },

    # Perak
    {
        "code": "PRK01",
        "state": "Perak",
        "location": "Tapah, Slim River, Tanjung Malim",
        "lat": 3.8286,
        "lon": 101.3570
    },
    {
        "code": "PRK02",
        "state": "Perak",
        "location": "Ipoh, Batu Gajah, Kampar, Sg. Siput, Kuala Kangsar",
        "lat": 4.5975,
        "lon": 101.0901
    },
    {
        "code": "PRK03",
        "state": "Perak",
        "location": "Pengkalan Hulu, Grik, Lenggong",
        "lat": 5.4277,
        "lon": 101.1309
    },
    {
        "code": "PRK04",
        "state": "Perak",
        "location": "Temengor, Belum",
        "lat": 5.5167,
        "lon": 101.3667
    },
    {
        "code": "PRK05",
        "state": "Perak",
        "location": "Teluk Intan, Bagan Datuk, Kg. Gajah, Seri Iskandar, Beruas, Parit, Lumut, Sitiawan, Pulau Pangkor",
        "lat": 4.1550,
        "lon": 100.7000
    },
    {
        "code": "PRK06",
        "state": "Perak",
        "location": "Selama, Taiping, Bagan Serai, Parit Buntar",
        "lat": 4.8500,
        "lon": 100.7333
    },
    {
        "code": "PRK07",
        "state": "Perak",
        "location": "Bukit Larut",
        "lat": 4.8628,
        "lon": 100.7925
    },

    # Perlis
    {
        "code": "PLS01",
        "state": "Perlis",
        "location": "Kangar, Padang Besar, Arau",
        "lat": 6.4449,
        "lon": 100.1986
    },

    # Pulau Pinang
    {
        "code": "PNG01",
        "state": "Pulau Pinang",
        "location": "Seluruh Negeri Pulau Pinang",
        "lat": 5.4164,
        "lon": 100.3327
    },

    # Sabah
    {
        "code": "SBH01",
        "state": "Sabah",
        "location": "Bahagian Sandakan (Timur), Bukit Garam, Semawang, Temanggong, Tambisan, Sukau",
        "lat": 5.8394,
        "lon": 118.1172
    },
    {
        "code": "SBH02",
        "state": "Sabah",
        "location": "Beluran, Telupid, Pinangah, Terusan, Kuamut",
        "lat": 5.8114,
        "lon": 117.5558
    },
    {
        "code": "SBH03",
        "state": "Sabah",
        "location": "Lahad Datu, Silabukan, Kunak, Sahabat, Semporna, Tungku",
        "lat": 5.0268,
        "lon": 118.3270
    },
    {
        "code": "SBH04",
        "state": "Sabah",
        "location": "Tawau, Balung, Merotai, Kalabakan",
        "lat": 4.2498,
        "lon": 117.8871
    },
    {
        "code": "SBH05",
        "state": "Sabah",
        "location": "Kudat, Kota Marudu, Pitas, Pulau Banggi",
        "lat": 6.8844,
        "lon": 116.8471
    },
    {
        "code": "SBH06",
        "state": "Sabah",
        "location": "Gunung Kinabalu",
        "lat": 6.0750,
        "lon": 116.5583
    },
    {
        "code": "SBH07",
        "state": "Sabah",
        "location": "Kota Kinabalu, Penampang, Tuaran, Papar, Ranau, Kota Belud",
        "lat": 5.9804,
        "lon": 116.0735
    },
    {
        "code": "SBH08",
        "state": "Sabah",
        "location": "Pensiangan, Keningau, Tambunan, Nabawan",
        "lat": 5.3442,
        "lon": 116.1601
    },
    {
        "code": "SBH09",
        "state": "Sabah",
        "location": "Beaufort, Kuala Penyu, Sipitang, Tenom, Long Pa Sia",
        "lat": 5.3473,
        "lon": 115.7455
    },

    # Sarawak
    {
        "code": "SWK01",
        "state": "Sarawak",
        "location": "Limbang, Lawas, Sundar, Trusan",
        "lat": 4.7500,
        "lon": 115.0000
    },
    {
        "code": "SWK02",
        "state": "Sarawak",
        "location": "Miri, Niah, Bekenu, Sibuti, Marudi",
        "lat": 4.3995,
        "lon": 113.9914
    },
    {
        "code": "SWK03",
        "state": "Sarawak",
        "location": "Pandan, Belaga, Suai, Tatau, Sebauh, Bintulu",
        "lat": 3.1667,
        "lon": 113.0333
    },
    {
        "code": "SWK04",
        "state": "Sarawak",
        "location": "Sibu, Mukah, Dalat, Song, Igan, Oya, Balingian, Kanowit, Kapit",
        "lat": 2.3000,
        "lon": 111.8167
    },
    {
        "code": "SWK05",
        "state": "Sarawak",
        "location": "Sarikei, Matu, Julau, Rajang, Daro, Bintangor, Belawai",
        "lat": 2.1167,
        "lon": 111.5167
    },
    {
        "code": "SWK06",
        "state": "Sarawak",
        "location": "Lubok Antu, Sri Aman, Roban, Debak, Betong, Saratok, Kabong",
        "lat": 1.2333,
        "lon": 111.4667
    },
    {
        "code": "SWK07",
        "state": "Sarawak",
        "location": "Serian, Simunjan, Samarahan, Sebuyau, Meludam",
        "lat": 1.4500,
        "lon": 110.6667
    },
    {
        "code": "SWK08",
        "state": "Sarawak",
        "location": "Kuching, Bau, Lundu, Sematan",
        "lat": 1.5533,
        "lon": 110.3592
    },
    {
        "code": "SWK09",
        "state": "Sarawak",
        "location": "Zon Khas (Kampung Patarikan)",
        "lat": 1.8333,
        "lon": 109.8333
    },

    # Terengganu
    {
        "code": "TRG01",
        "state": "Terengganu",
        "location": "Kuala Terengganu, Marang, Kuala Nerus",
        "lat": 5.3117,
        "lon": 103.1324
    },
    {
        "code": "TRG02",
        "state": "Terengganu",
        "location": "Besut, Setiu",
        "lat": 5.7600,
        "lon": 102.5500
    },
    {
        "code": "TRG03",
        "state": "Terengganu",
        "location": "Hulu Terengganu",
        "lat": 5.0667,
        "lon": 103.0167
    },
    {
        "code": "TRG04",
        "state": "Terengganu",
        "location": "Dungun, Kemaman",
        "lat": 4.7733,
        "lon": 103.4217
    }
]

def find_nearest_zone(user_lat, user_lon):
    """
    Finds the nearest JAKIM zone given latitude and longitude using Haversine formula.
    Returns (zone_dict, distance_km).
    """
    import math

    def haversine(lat1, lon1, lat2, lon2):
        R = 6371.0 # Earth radius in km
        dLat = math.radians(lat2 - lat1)
        dLon = math.radians(lon2 - lon1)
        a = (math.sin(dLat / 2) ** 2 +
             math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) *
             math.sin(dLon / 2) ** 2)
        c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
        return R * c

    best_zone = None
    min_dist = float('inf')

    for z in JAKIM_ZONES:
        dist = haversine(user_lat, user_lon, z["lat"], z["lon"])
        if dist < min_dist:
            min_dist = dist
            best_zone = z

    return best_zone, round(min_dist, 2)
