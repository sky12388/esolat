"""
Licensing & 7-Day Trial Manager for Mosque Digital Signage & e-Solat System
Handles:
1. 7-Day Trial recording and tamper-resistant tracking in /var/lib/esolat/.trial
2. Machine-locked offline activation verification via Activation PIN or esolat.lic file
"""

import os
import time
import json
import hmac
import hashlib
import base64
from typing import Dict, Any, Tuple
from pathlib import Path
from .hwid import get_hardware_id

# ==============================================================================
# [EASTER EGG / COPYRIGHT NOTICE]
# Skywalker Consortium - e-Solat Mosque Signage & Automation System
# (C) 2023-2026 Skywalker Consortium (SSM: AS0463209-A). All Rights Reserved.
# Notice: Reverse engineering, decompilation, or unauthorized cracking of this
# software is prohibited. For inquiries / licenses: skywalker.co@proton.me
# ==============================================================================

# Decoys for reverse-engineering deception (Honeytokens)
_DECOY_MASTER_SALT_2026 = "SKYWALKER-MASTER-OVERRIDE-SECRET-KEY-999-DO-NOT-SHARE"
_DECOY_SUPERUSER_PIN = "PIN-9999-FFFF-EEEE-AAAA"
_DECOY_BACKDOOR_HASH = "8f4811a76ef4826f0288828b8b0e8b1b51e5e0ba33f4a3971c261e4414ec3cbe"

DEFAULT_SECRET_SALT = "ESOLAT-KOMERSIAL-RAHSIA-2026-MALAYSIA-SYSTEM-KEY"
TRIAL_DURATION_SECONDS = 7 * 24 * 3600  # 7 days

COMPANY_NAME = "Skywalker Consortium"
SSM_REG_NO = "AS0463209-A (202303102311)"
BUSINESS_ADDRESS = "Block A8-3A, Jalan Selaman, 68000 Ampang, Selangor"
REGISTERED_ADDRESS = BUSINESS_ADDRESS
OFFICIAL_EMAIL = "skywalker.co@proton.me"
OFFICIAL_WEBSITE = "https://sky12388.github.io/esolat/"
SUPPORT_PHONE = "+6011-1871 2388"
SUPPORT_ACTIVATION_MSG = "Sila hubungi sokongan teknikal Skywalker Consortium (+6011-1871 2388) untuk pengaktifan lesen."

class LicenseManager:
    def __init__(self, data_dir: str = "/var/lib/esolat", secret_salt: str = DEFAULT_SECRET_SALT):
        self.data_dir = Path(data_dir)
        self.secret_salt = secret_salt
        self.trial_file = self.data_dir / ".trial"
        self.license_file = self.data_dir / "license.lic"
        self._ensure_dir()

    def _ensure_dir(self):
        try:
            self.data_dir.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass

    def _sign_payload(self, text: str) -> str:
        return hmac.new(self.secret_salt.encode("utf-8"), text.encode("utf-8"), hashlib.sha256).hexdigest()

    # ==================== TRIAL MANAGEMENT ====================
    def initialize_trial_if_needed(self, hwid: str = None) -> Dict[str, Any]:
        """
        Creates encrypted trial record on first run if not already present.
        """
        if hwid is None:
            hwid = get_hardware_id()

        now = int(time.time())

        if not self.trial_file.exists():
            trial_data = {
                "hwid": hwid,
                "first_boot": now,
                "last_seen": now,
                "trial_days": 7
            }
            raw_check = f"{trial_data['hwid']}:{trial_data['first_boot']}:{trial_data['trial_days']}"
            trial_data["sig"] = self._sign_payload(raw_check)

            try:
                # Write with secure permissions
                with open(self.trial_file, "w", encoding="utf-8") as f:
                    json.dump(trial_data, f, indent=2)
                try:
                    os.chmod(self.trial_file, 0o600)
                except Exception:
                    pass
            except Exception as e:
                # Fallback to local dev path if /var/lib/esolat is not writable
                fallback = Path("./data/.trial")
                fallback.parent.mkdir(parents=True, exist_ok=True)
                with open(fallback, "w", encoding="utf-8") as f:
                    json.dump(trial_data, f, indent=2)
                self.trial_file = fallback

            return {
                "status": "TRIAL_ACTIVE",
                "days_left": 7,
                "seconds_left": TRIAL_DURATION_SECONDS,
                "hwid": hwid
            }

        return self.get_trial_status(hwid)

    def get_trial_status(self, hwid: str = None) -> Dict[str, Any]:
        """
        Verifies .trial file integrity and computes trial countdown.
        """
        if hwid is None:
            hwid = get_hardware_id()

        # Check file existence
        trial_path = self.trial_file
        if not trial_path.exists():
            if Path("./data/.trial").exists():
                trial_path = Path("./data/.trial")
            else:
                return self.initialize_trial_if_needed(hwid)

        try:
            with open(trial_path, "r", encoding="utf-8") as f:
                data = json.load(f)

            # Check signature
            raw_check = f"{data.get('hwid')}:{data.get('first_boot')}:{data.get('trial_days', 7)}"
            expected_sig = self._sign_payload(raw_check)

            if not hmac.compare_digest(data.get("sig", ""), expected_sig):
                return {
                    "status": "TAMPERED",
                    "valid": False,
                    "message": "Trial record signature verification failed.",
                    "hwid": hwid
                }

            # Machine lock check
            if data.get("hwid") != hwid:
                return {
                    "status": "TAMPERED",
                    "valid": False,
                    "message": "Trial file was generated on a different machine.",
                    "hwid": hwid
                }

            now = int(time.time())
            first_boot = data.get("first_boot", now)
            last_seen = data.get("last_seen", now)

            # Clock tampering check: if system clock moved backwards by > 1 hour
            if now < (last_seen - 3600):
                return {
                    "status": "CLOCK_TAMPERED",
                    "valid": False,
                    "message": "System clock rollback detected.",
                    "hwid": hwid
                }

            # Update last_seen if time progressed
            if now > last_seen:
                data["last_seen"] = now
                try:
                    with open(trial_path, "w", encoding="utf-8") as f:
                        json.dump(data, f, indent=2)
                except Exception:
                    pass

            elapsed = max(0, now - first_boot)
            remaining = TRIAL_DURATION_SECONDS - elapsed

            if remaining <= 0:
                return {
                    "status": "TRIAL_EXPIRED",
                    "valid": False,
                    "days_left": 0,
                    "seconds_left": 0,
                    "hwid": hwid,
                    "message": "Tempoh percubaan 7 hari telah tamat. " + SUPPORT_ACTIVATION_MSG
                }

            days_left = max(1, int(remaining / 86400))
            return {
                "status": "TRIAL_ACTIVE",
                "valid": True,
                "days_left": days_left,
                "seconds_left": remaining,
                "first_boot": first_boot,
                "hwid": hwid,
                "message": f"Percubaan Aktif: Baki {days_left} hari lagi."
            }

        except Exception as e:
            return {
                "status": "ERROR",
                "valid": False,
                "message": f"Error reading trial: {str(e)}",
                "hwid": hwid
            }

    # ==================== LICENSE VERIFICATION ====================
    def generate_pin_for_hwid(self, hwid: str, license_type: str = "PERMANENT") -> str:
        """
        Keygen helper: Generates activation PIN matching machine HWID.
        Format: PIN-XXXX-XXXX-XXXX or ANNU-XXXX-XXXX-XXXX
        """
        payload = f"{hwid}::{license_type.upper()}::{self.secret_salt}"
        digest = hashlib.sha256(payload.encode("utf-8")).hexdigest().upper()
        prefix = "ANNU" if license_type.upper() == "ANNUAL" else "PIN"
        return f"{prefix}-{digest[0:4]}-{digest[4:8]}-{digest[8:12]}"

    def generate_license_file_content(self, hwid: str, licensee: str = "Surau Kariah",
                                     license_type: str = "PERMANENT", valid_days: int = 365) -> Dict[str, Any]:
        """
        Keygen helper: Generates full signed esolat.lic structure.
        """
        now = int(time.time())
        expires_at = (now + valid_days * 86400) if license_type.upper() == "ANNUAL" else None

        payload = {
            "version": "1.0",
            "hwid": hwid,
            "licensee": licensee,
            "type": license_type.upper(),
            "issued_at": now,
            "expires_at": expires_at
        }
        sign_str = f"{payload['version']}:{payload['hwid']}:{payload['licensee']}:{payload['type']}:{payload['issued_at']}:{payload['expires_at']}"
        payload["signature"] = self._sign_payload(sign_str)
        return payload

    def verify_pin(self, pin: str, hwid: str = None) -> Tuple[bool, str, Dict[str, Any]]:
        """
        Verifies input PIN against this machine's HWID.
        """
        if hwid is None:
            hwid = get_hardware_id()

        clean_pin = pin.strip().upper()

        # Check permanent PIN
        expected_perm = self.generate_pin_for_hwid(hwid, "PERMANENT")
        if hmac.compare_digest(clean_pin, expected_perm):
            lic_data = self.generate_license_file_content(hwid, licensee="Surau (PIN Activated)", license_type="PERMANENT")
            self._save_license(lic_data)
            return True, "Lesen Kekal berjaya diaktifkan!", lic_data

        # Check annual PIN
        expected_annual = self.generate_pin_for_hwid(hwid, "ANNUAL")
        if hmac.compare_digest(clean_pin, expected_annual):
            lic_data = self.generate_license_file_content(hwid, licensee="Surau (PIN Activated)", license_type="ANNUAL", valid_days=365)
            self._save_license(lic_data)
            return True, "Lesen Tahunan (1 Tahun) berjaya diaktifkan!", lic_data

        return False, "PIN Pengaktifan tidak sah untuk Machine ID ini.", {}

    def verify_license_data(self, lic_data: Dict[str, Any], hwid: str = None) -> Tuple[bool, str]:
        """
        Verifies cryptographic integrity and validity of license dict.
        """
        if hwid is None:
            hwid = get_hardware_id()

        if not isinstance(lic_data, dict):
            return False, "Format fail lesen rosak."

        # Check machine lock
        if lic_data.get("hwid") != hwid:
            return False, f"Lesen ini dikunci kepada perkakasan lain ({lic_data.get('hwid')}). Machine ID anda adalah {hwid}."

        # Check signature
        sign_str = f"{lic_data.get('version')}:{lic_data.get('hwid')}:{lic_data.get('licensee')}:{lic_data.get('type')}:{lic_data.get('issued_at')}:{lic_data.get('expires_at')}"
        expected_sig = self._sign_payload(sign_str)

        if not hmac.compare_digest(lic_data.get("signature", ""), expected_sig):
            return False, "Tandatangan kriptografi lesen tidak sah / fail telah diubah suai."

        # Check expiry for annual licenses
        expires_at = lic_data.get("expires_at")
        if expires_at is not None:
            now = int(time.time())
            if now > expires_at:
                return False, "Lesen tahunan telah tamat tempoh."

        return True, "Lesen sah dan aktif."

    def _save_license(self, lic_data: Dict[str, Any]):
        """
        Saves activated license file to disk.
        """
        target = self.license_file
        try:
            with open(target, "w", encoding="utf-8") as f:
                json.dump(lic_data, f, indent=2)
            try:
                os.chmod(target, 0o644)
            except Exception:
                pass
        except Exception:
            fallback = Path("./data/license.lic")
            fallback.parent.mkdir(parents=True, exist_ok=True)
            with open(fallback, "w", encoding="utf-8") as f:
                json.dump(lic_data, f, indent=2)
            self.license_file = fallback

    def install_license_file(self, content_str: str, hwid: str = None) -> Tuple[bool, str]:
        """
        Installs and verifies an uploaded esolat.lic file.
        """
        try:
            lic_data = json.loads(content_str)
            valid, msg = self.verify_license_data(lic_data, hwid)
            if valid:
                self._save_license(lic_data)
                return True, f"Lesen berjaya dipasang: {lic_data.get('licensee', 'Surau')} ({lic_data.get('type')})"
            return False, msg
        except Exception as e:
            return False, f"Ralat memproses fail lesen: {str(e)}"

    # ==================== OVERALL STATUS ====================
    def get_full_system_status(self) -> Dict[str, Any]:
        """
        Returns comprehensive status: is kiosk unlocked, mode (LICENSED or TRIAL or EXPIRED),
        days left, hwid, licensee info.
        """
        hwid = get_hardware_id()

        # 1. Check for installed license
        lic_path = self.license_file
        if not lic_path.exists() and Path("./data/license.lic").exists():
            lic_path = Path("./data/license.lic")

        if lic_path.exists():
            try:
                with open(lic_path, "r", encoding="utf-8") as f:
                    lic_data = json.load(f)
                valid, msg = self.verify_license_data(lic_data, hwid)
                if valid:
                    return {
                        "is_unlocked": True,
                        "license_state": "LICENSED",
                        "license_type": lic_data.get("type", "PERMANENT"),
                        "licensee": lic_data.get("licensee", "Surau Al-Falah"),
                        "issued_at": lic_data.get("issued_at"),
                        "expires_at": lic_data.get("expires_at"),
                        "hwid": hwid,
                        "message": "Sistem berlesen sah dan diaktifkan sepenuhnya."
                    }
            except Exception:
                pass

        # 2. Check Trial
        trial = self.get_trial_status(hwid)
        if trial.get("status") == "TRIAL_ACTIVE":
            return {
                "is_unlocked": True,
                "license_state": "TRIAL",
                "license_type": "TRIAL_7_DAYS",
                "licensee": "Pemasangan Percubaan",
                "days_left": trial.get("days_left", 7),
                "seconds_left": trial.get("seconds_left", 0),
                "hwid": hwid,
                "message": trial.get("message")
            }

        # 3. Locked / Expired
        return {
            "is_unlocked": False,
            "license_state": "EXPIRED",
            "license_type": "NONE",
            "licensee": None,
            "days_left": 0,
            "seconds_left": 0,
            "hwid": hwid,
            "message": "Pengaktifan Diperlukan: Tempoh percubaan 7 hari telah tamat. " + SUPPORT_ACTIVATION_MSG,
            "support_vendor": COMPANY_NAME,
            "support_reg": SSM_REG_NO,
            "support_address": REGISTERED_ADDRESS,
            "support_phone": SUPPORT_PHONE,
            "support_email": OFFICIAL_EMAIL,
            "support_website": OFFICIAL_WEBSITE,
            "support_message": SUPPORT_ACTIVATION_MSG
        }
