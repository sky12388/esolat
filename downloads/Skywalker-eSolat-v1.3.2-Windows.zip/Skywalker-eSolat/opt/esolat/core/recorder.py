"""
Video Recording & Live Camera Manager for Mosque Kuliah & Friday Khutbah
Handles Linux V4L2 HDMI capture cards (/dev/video*) and MP4 recording using ffmpeg.
"""

import os
import sys
import glob
import time
import shutil
import subprocess
import threading
from pathlib import Path
from typing import Dict, Any, List, Optional

class RecordingManager:
    def __init__(self, recordings_dir: str = "/var/lib/esolat/media/recordings"):
        self.default_recordings_dir = Path(recordings_dir)
        self.recordings_dir = self.default_recordings_dir
        try:
            self.recordings_dir.mkdir(parents=True, exist_ok=True)
        except Exception:
            self.default_recordings_dir = Path("./data/media/recordings")
            self.recordings_dir = self.default_recordings_dir
            self.recordings_dir.mkdir(parents=True, exist_ok=True)

        self.current_process: Optional[subprocess.Popen] = None
        self.recording_start_time: float = 0.0
        self.current_filename: str = ""
        self.lock = threading.Lock()

    def set_storage_path(self, new_path: str) -> Dict[str, Any]:
        """
        Sets a new storage path (e.g. external USB/SSD drive) for recordings.
        """
        if not new_path or not new_path.strip():
            self.recordings_dir = self.default_recordings_dir
            return {
                "success": True,
                "message": f"Lokasi storan ditetapkan ke lalai: {self.recordings_dir}",
                "storage_path": str(self.recordings_dir),
                "storage_info": self.get_storage_info()
            }

        target = Path(new_path.strip())
        try:
            target.mkdir(parents=True, exist_ok=True)
            # Test write access
            test_file = target / ".write_test"
            test_file.touch()
            test_file.unlink()
            self.recordings_dir = target
            return {
                "success": True,
                "message": f"Lokasi storan berjaya ditukar ke: {self.recordings_dir}",
                "storage_path": str(self.recordings_dir),
                "storage_info": self.get_storage_info()
            }
        except Exception as e:
            return {
                "success": False,
                "message": f"Gagal mengakses folder '{new_path}': {str(e)}",
                "storage_path": str(self.recordings_dir),
                "storage_info": self.get_storage_info()
            }

    def get_storage_info(self) -> Dict[str, Any]:
        """
        Returns disk usage and status for the currently active storage path.
        """
        target_path = self.recordings_dir
        try:
            usage = shutil.disk_usage(str(target_path))
            free_gb = round(usage.free / (1024**3), 2)
            total_gb = round(usage.total / (1024**3), 2)
            used_gb = round(usage.used / (1024**3), 2)
            percent_used = round((usage.used / usage.total) * 100, 1)
        except Exception:
            free_gb = 0.0
            total_gb = 0.0
            used_gb = 0.0
            percent_used = 0.0

        is_external = str(target_path) != str(self.default_recordings_dir)
        return {
            "path": str(target_path),
            "is_external": is_external,
            "free_gb": free_gb,
            "total_gb": total_gb,
            "used_gb": used_gb,
            "percent_used": percent_used,
            "is_writable": os.access(str(target_path), os.W_OK)
        }

    def scan_available_drives(self) -> List[Dict[str, Any]]:
        """
        Scans system for available storage options (Internal SSD, External USB drives, Mounted SSDs).
        """
        drives = []

        # 1. Internal Default Storage
        try:
            usage = shutil.disk_usage(str(self.default_recordings_dir))
            free_gb = round(usage.free / (1024**3), 1)
            total_gb = round(usage.total / (1024**3), 1)
            drives.append({
                "type": "internal",
                "name": "Internal Storage",
                "label": f"Penyimpanan Dalaman ({free_gb} GB bebas / {total_gb} GB)",
                "path": str(self.default_recordings_dir),
                "mount_point": "/",
                "free_gb": free_gb,
                "total_gb": total_gb,
                "is_current": str(self.recordings_dir) == str(self.default_recordings_dir)
            })
        except Exception:
            drives.append({
                "type": "internal",
                "name": "Internal Storage",
                "label": "Penyimpanan Dalaman (Lalai)",
                "path": str(self.default_recordings_dir),
                "mount_point": "/",
                "free_gb": 0,
                "total_gb": 0,
                "is_current": str(self.recordings_dir) == str(self.default_recordings_dir)
            })

        # 2. Linux Mounted External Drives (/media, /run/media, /mnt)
        seen = {str(self.default_recordings_dir), "/"}
        for pattern in ["/media/*/*", "/run/media/*/*", "/mnt/*"]:
            for p in sorted(glob.glob(pattern)):
                if os.path.isdir(p) and not os.path.islink(p):
                    real = os.path.realpath(p)
                    if real not in seen and real != "/" and not real.startswith("/var") and not real.startswith("/home"):
                        seen.add(real)
                        drive_name = os.path.basename(p)
                        rec_path = str(Path(p) / "esolat_recordings")
                        try:
                            usage = shutil.disk_usage(p)
                            free_gb = round(usage.free / (1024**3), 1)
                            total_gb = round(usage.total / (1024**3), 1)
                            drives.append({
                                "type": "external",
                                "name": drive_name,
                                "label": f"Pemacu Luar: {drive_name} ({free_gb} GB bebas / {total_gb} GB)",
                                "path": rec_path,
                                "mount_point": p,
                                "free_gb": free_gb,
                                "total_gb": total_gb,
                                "is_current": str(self.recordings_dir) == rec_path or str(self.recordings_dir) == p
                            })
                        except Exception:
                            pass

        # 3. If currently selected path is custom and not already in drives list
        cur_str = str(self.recordings_dir)
        if not any(d["path"] == cur_str or d.get("mount_point") == cur_str for d in drives):
            try:
                usage = shutil.disk_usage(cur_str)
                free_gb = round(usage.free / (1024**3), 1)
                total_gb = round(usage.total / (1024**3), 1)
            except Exception:
                free_gb = 0
                total_gb = 0
            drives.append({
                "type": "custom",
                "name": "Custom Location",
                "label": f"Lokasi Pilihan: {cur_str} ({free_gb} GB bebas)",
                "path": cur_str,
                "mount_point": cur_str,
                "free_gb": free_gb,
                "total_gb": total_gb,
                "is_current": True
            })

        return drives

    def detect_video_devices(self) -> List[str]:
        """
        Scans for available V4L2 video devices (/dev/video*).
        USB HDMI capture cards typically appear as /dev/video0 or /dev/video2.
        """
        devices = sorted(glob.glob("/dev/video*"))
        return devices

    def is_recording(self) -> bool:
        with self.lock:
            if self.current_process:
                if self.current_process.poll() is None:
                    return True
                else:
                    self.current_process = None
            return False

    def get_status(self, rtsp_url: str = "") -> Dict[str, Any]:
        with self.lock:
            recording = self.is_recording()
            duration = int(time.time() - self.recording_start_time) if recording else 0
            devices = self.detect_video_devices()
            has_rtsp = bool(rtsp_url and rtsp_url.startswith("rtsp://"))

            return {
                "camera_detected": len(devices) > 0 or has_rtsp,
                "video_devices": devices,
                "has_rtsp_configured": has_rtsp,
                "is_recording": recording,
                "duration_seconds": duration,
                "current_file": self.current_filename if recording else None,
                "ffmpeg_available": shutil.which("ffmpeg") is not None,
                "storage_info": self.get_storage_info(),
                "available_drives": self.scan_available_drives()
            }

    def start_recording(self, source: str = "/dev/video0", audio_device: str = "default") -> Dict[str, Any]:
        """
        Starts MP4 recording from either:
        1. V4L2 USB HDMI capture card (/dev/video*)
        2. RTSP IP Network Stream (rtsp://...)
        """
        with self.lock:
            if self.is_recording():
                return {"success": False, "message": "Rakaman sedang berjalan."}

            ffmpeg_bin = shutil.which("ffmpeg")
            if not ffmpeg_bin:
                return {
                    "success": False,
                    "message": "Utiliti ffmpeg belum dipasang. Sila pasang dengan: sudo apt install ffmpeg"
                }

            is_rtsp = source.startswith("rtsp://") or source.startswith("http://")

            if not is_rtsp and not Path(source).exists():
                devices = self.detect_video_devices()
                if devices:
                    source = devices[0]
                else:
                    return {"success": False, "message": "Tiada peranti kamera/HDMI capture dikesan di /dev/video* dan tiada strim RTSP."}

            timestamp = time.strftime("%Y-%m-%d_%H-%M-%S")
            self.current_filename = f"kuliah_{timestamp}.mp4"
            output_path = self.recordings_dir / self.current_filename

            if is_rtsp:
                # RTSP IP Camera Stream (direct copy = near 0% CPU usage)
                cmd = [
                    ffmpeg_bin,
                    "-y",
                    "-rtsp_transport", "tcp",
                    "-i", source,
                    "-c:v", "copy",
                    "-c:a", "aac",
                    "-b:a", "128k",
                    "-movflags", "+faststart",
                    str(output_path)
                ]
            else:
                # Standard V4L2 USB HDMI capture card
                cmd = [
                    ffmpeg_bin,
                    "-y",
                    "-f", "v4l2",
                    "-framerate", "30",
                    "-video_size", "1920x1080",
                    "-i", source,
                    "-f", "alsa",
                    "-i", audio_device,
                    "-c:v", "libx264",
                    "-preset", "veryfast",
                    "-crf", "23",
                    "-c:a", "aac",
                    "-b:a", "128k",
                    "-movflags", "+faststart",
                    str(output_path)
                ]

            try:
                self.current_process = subprocess.Popen(
                    cmd,
                    stdin=subprocess.PIPE,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL
                )
                self.recording_start_time = time.time()
                return {
                    "success": True,
                    "message": f"Rakaman dimulakan: {self.current_filename}",
                    "file": self.current_filename,
                    "source": "rtsp" if is_rtsp else "v4l2"
                }
            except Exception as e:
                # Fallback for V4L2 without separate ALSA input if ALSA capture device differs
                if not is_rtsp:
                    try:
                        cmd_no_audio = [
                            ffmpeg_bin,
                            "-y",
                            "-f", "v4l2",
                            "-framerate", "30",
                            "-video_size", "1920x1080",
                            "-i", source,
                            "-c:v", "libx264",
                            "-preset", "veryfast",
                            "-crf", "23",
                            "-movflags", "+faststart",
                            str(output_path)
                        ]
                        self.current_process = subprocess.Popen(
                            cmd_no_audio,
                            stdin=subprocess.PIPE,
                            stdout=subprocess.DEVNULL,
                            stderr=subprocess.DEVNULL
                        )
                        self.recording_start_time = time.time()
                        return {
                            "success": True,
                            "message": f"Rakaman video dimulakan (tanpa audio ALSA): {self.current_filename}",
                            "file": self.current_filename,
                            "source": "v4l2"
                        }
                    except Exception as ex2:
                        return {"success": False, "message": f"Gagal memulakan ffmpeg: {str(ex2)}"}
                return {"success": False, "message": f"Gagal memulakan rakaman RTSP: {str(e)}"}

    def stop_recording(self) -> Dict[str, Any]:
        """
        Gracefully stops ffmpeg by sending 'q' to stdin so MP4 trailer is cleanly finalized.
        """
        with self.lock:
            if not self.current_process:
                return {"success": False, "message": "Tiada rakaman sedang aktif."}

            try:
                # Send 'q' to quit ffmpeg cleanly
                if self.current_process.stdin:
                    try:
                        self.current_process.stdin.write(b"q\n")
                        self.current_process.stdin.flush()
                    except Exception:
                        pass
                self.current_process.terminate()
                self.current_process.wait(timeout=5)
            except Exception:
                try:
                    self.current_process.kill()
                except Exception:
                    pass
            finally:
                self.current_process = None

            saved_file = self.current_filename
            self.current_filename = ""
            self.recording_start_time = 0.0

            return {
                "success": True,
                "message": f"Rakaman berjaya disimpan: {saved_file}",
                "file": saved_file
            }

    def get_file_path(self, filename: str) -> Optional[Path]:
        """
        Locates a recording file in current or default recordings directory.
        """
        clean_name = os.path.basename(filename)
        # Check active directory first
        p = self.recordings_dir / clean_name
        if p.exists():
            return p
        # Check default directory
        p_def = self.default_recordings_dir / clean_name
        if p_def.exists():
            return p_def
        return None

    def list_recordings(self) -> List[Dict[str, Any]]:
        """
        Lists all recorded MP4 files with file size and timestamp.
        Scans both current storage directory and default fallback directory.
        """
        items = []
        seen_files = set()
        dirs_to_scan = [self.recordings_dir]
        if self.default_recordings_dir != self.recordings_dir:
            dirs_to_scan.append(self.default_recordings_dir)

        all_paths = []
        for d in dirs_to_scan:
            if d.exists():
                all_paths.extend(d.glob("*.mp4"))

        for p in sorted(all_paths, key=os.path.getmtime, reverse=True):
            if p.name in seen_files:
                continue
            seen_files.add(p.name)
            try:
                stat = p.stat()
                items.append({
                    "filename": p.name,
                    "size_mb": round(stat.st_size / (1024 * 1024), 2),
                    "created_at": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(stat.st_mtime)),
                    "download_url": f"/media/recordings/{p.name}",
                    "location": str(p.parent)
                })
            except Exception:
                continue
        return items

    def delete_recording(self, filename: str) -> bool:
        target = self.get_file_path(filename)
        if target and target.exists() and target.suffix == ".mp4":
            try:
                target.unlink()
                return True
            except Exception:
                pass
        return False
