# 🛠️ e-Solat Kiosk — Technical Installation & System Administrator Manual

**Document Version**: 1.2.0  
**Target Platform**: Debian 12 (Bookworm) / Debian 13 (Trixie) amd64  
**Package Name**: `skywalker-esolat_1.2.0_amd64.deb`  
**Official Vendor**: Skywalker Consortium (SSM: AS0463209-A)  
**Support Contact**: +6011-1871 2388 | skywalker.co@proton.me  
**Target Hardware**: Mini PC / Thin Client / Industrial PC with HDMI display output  

---

## 1. Hardware Requirements & Specifications

### 1.1 Recommended Mini PC Specifications
For smooth 1080p and 4K digital signage playback 24 hours a day, 7 days a week:
- **Processor**: Intel Celeron N5095 / N5105 / N100 / Core i3 or AMD Ryzen 3 (Quad Core recommended).
- **RAM**: Minimum 4GB DDR4 (8GB recommended for 4K video rendering).
- **Storage**: Minimum 64GB SSD / eMMC (128GB NVMe/SATA SSD recommended for storing media posters and video files).
- **Display Output**: HDMI 2.0 or 2.1 (supports 1920x1080 @ 60Hz or 3840x2160 @ 60Hz).
- **Network**: Gigabit Ethernet LAN (RJ45) and/or 802.11ac/ax Wi-Fi.
- **Audio Output**: 
  - Standard 3.5mm stereo audio jack (connected directly to the Mosque PA System / Amplifier input).
  - OR HDMI embedded audio (played through TV display speakers).

### 1.2 Essential BIOS / UEFI Configuration
Before installing the operating system, configure the Mini PC BIOS:
1. **Power-On After Power Failure (Critical)**:
   - Enter BIOS by pressing `DEL` or `F2` during boot.
   - Navigate to `Chipset` or `Power Management Setup`.
   - Set **"Restore AC Power Loss"** (or *State After G3*) to **`Power On`** (or *Always On*).
   - *Rationale*: If the mosque suffers a power outage or the power supply is scheduled on a timer switch, the PC will boot automatically without anyone having to press the power button.
2. **Auto Power-On Alarm / RTC (Optional)**:
   - Configure RTC Wake if the committee desires scheduled boots.
3. **Quiet Boot**: Enabled (suppresses motherboard logos).

### 1.3 TV Display Settings (Hall TV)
- **Aspect Ratio**: Set to **"Just Scan"**, **"Full Pixel"**, or **"1:1"** (disables overscan edge cropping).
- **Power On Status**: Configure the TV to turn on automatically upon receiving HDMI signal (HDMI-CEC enabled).
- **Eco Mode / Auto Sleep**: **DISABLE** all "Auto Power Off", "Sleep Timer", and "Energy Saving" features on the TV so the screen remains on continuously.

---

## 2. Operating System Preparation (Debian 12 / 13)

### 2.1 Operating System Installation
1. Download official Debian netinst ISO:
   - Debian 12 (Bookworm) amd64 OR Debian 13 (Trixie) amd64.
2. Flash to a USB drive using `balenaEtcher` or `dd`.
3. Choose standard installation with Desktop Environment:
   - **Recommended Desktop**: **Cinnamon** or **XFCE** (lightweight, stable X11 compositing).
4. Configure Primary User:
   - Username: `surau` (or standard admin user).
   - Enable **Automatic Login** in LightDM / Cinnamon Display Manager settings so the desktop opens directly without prompting for a password upon power-on.

### 2.2 Enabling Automatic Login (LightDM)
If automatic login was not selected during Debian install, edit `/etc/lightdm/lightdm.conf`:
```bash
sudo nano /etc/lightdm/lightdm.conf
```
Under `[Seat:*]`, uncomment and set:
```ini
[Seat:*]
autologin-user=surau
autologin-user-timeout=0
```

---

## 3. Package Installation & Automated Provisioning

### 3.1 Obtaining the .deb Package
Copy the pre-compiled installer package `skywalker-esolat_1.2.0_amd64.deb` to the target machine (via USB drive, SFTP, or direct download).

Or compile it directly on the target machine from the source repository:
```bash
cd /path/to/skywalker.esolat
./build-deb.sh
# Package output will be in skywalker-esolat_1.2.0_amd64.deb
```

### 3.2 Installing via APT
Execute `apt install` using the path to the local `.deb` file:
```bash
sudo apt update
sudo apt install ./skywalker-esolat_1.2.0_amd64.deb -y
```

> [!NOTE]
> Using `apt install ./<package>.deb` is strongly recommended over `dpkg -i` because `apt` automatically resolves and downloads all necessary system dependencies:
> - `python3` (Core execution runtime)
> - `chromium` or `chromium-browser` (Kiosk hardware-accelerated rendering)
> - `unclutter` (Automatic mouse cursor hiding)
> - `mpg123` (Fast, low-latency ALSA audio playback)
> - `curl` and `jq` (Network utilities)

### 3.3 What the `postinst` Script Does Automatically
When `apt install` runs, the package's `postinst` script performs the following tasks:
1. **User Creation**: Creates dedicated system user and group `esolat:esolat` without interactive shell access (`/usr/sbin/nologin`).
2. **Audio/Video Group Delegation**: Adds `esolat` user to `audio`, `video`, `dialout`, `pulse`, and `pulse-access` groups.
3. **Directory Provisioning**:
   - `/opt/esolat/` (Binaries, core libraries, web UI, systemd units)
   - `/var/lib/esolat/data/` (SQLite database)
   - `/var/lib/esolat/media/` (User uploaded poster images and videos)
   - `/var/log/esolat/` (System audit logs)
4. **Service Registration**: Installs `/etc/systemd/system/esolat.service`, executes `daemon-reload`, enables the unit, and starts it immediately.
5. **Autostart Configuration**: Deploys `/etc/xdg/autostart/esolat-kiosk.desktop` and populates user autostart directories.
6. **Screen Power Management**:
   - Disables DPMS and screensaver in `/etc/lightdm/lightdm.conf.d/50-esolat-nosleep.conf`.
   - Adds X11 server flags in `/etc/X11/xorg.conf.d/10-esolat-display.conf` disabling blanking and suspend.
7. **Trial Seeding**: Seeds the 7-day HMAC-SHA256 trial timestamp file at `/var/lib/esolat/.trial`.

---

## 4. Verification & Testing

### 4.1 Checking System Service Status
Verify that the e-Solat backend daemon is running properly:
```bash
sudo systemctl status esolat.service
```
Expected output:
```text
● esolat.service - Mosque Digital Signage & e-Solat System Daemon
     Loaded: loaded (/etc/systemd/system/esolat.service; enabled; preset: enabled)
     Active: active (running) since Sun 2026-09-28 00:30:00 +08; 5m ago
   Main PID: 1234 (esolat-server)
      Tasks: 4 (limit: 9382)
     Memory: 28.4M
        CPU: 120ms
     CGroup: /system.slice/esolat.service
             └─1234 /usr/bin/python3 /opt/esolat/bin/esolat-server --port 8080 --host 0.0.0.0 ...
```

### 4.2 Verifying Local Network Accessibility
Determine the local IP address of the machine:
```bash
ip route get 1.1.1.1 | awk '{print $7}'
# Example output: 192.168.1.104
```
Test with curl locally:
```bash
curl -s http://localhost:8080/api/state | head -n 15
```

### 4.3 Testing Audio Output (PA System Check)
Test that sound flows through to the amplifiers:
```bash
# Test through the backend audio dispatcher:
curl -s -X POST http://localhost:8080/api/system/test_audio \
     -H "Content-Type: application/json" \
     -d '{"sound": "beep"}'

# Or test directly with aplay / mpg123:
mpg123 /opt/esolat/web/assets/audio/adhan.mp3
```

To adjust ALSA master volume:
```bash
alsamixer
# Press F6 to select sound card, then UP arrow to set Master and PCM to 85-90%
```

---

## 5. Commercial Licensing & Commissioning Workflow

Every installation is equipped with an automated **7-Day Free Trial**. After 7 days without activation, the screen locks to an **Activation Required** screen.

### 5.1 Obtaining the Machine ID
Obtain the unique hardware fingerprint using either of these methods:
- **Terminal**: Run `python3 /opt/esolat/core/hwid.py`
- **Phone Admin**: Navigate to `http://<IP>:8080/admin` -> **Lesen** tab.
- **Example Machine ID**: `SURAU-088B-8FF8-5E93`

### 5.2 Generating License Key via Offline Keygen

#### Method A: Using the Offline Web Generator (Fastest & Simplest)
Open the file `tools/keygen/index.html` on any laptop, tablet, or smartphone:
1. Enter the customer's **Machine ID** (e.g., `SURAU-088B-8FF8-5E93`).
2. Enter the **Mosque Name** (e.g., `Masjid Al-Falah`).
3. Select License Type: **Permanent** (Lifetime) or **Annual** (365 Days).
4. Click **Jana Kunci & PIN Pengaktifan**.
5. Copy the generated **Activation PIN** (e.g., `PIN-609B-F671-9E26`) or click **Muat Turun esolat.lic**.

#### Method B: Using CLI Keygen
On your engineering machine:
```bash
python3 tools/keygen/keygen.py \
        --hwid SURAU-088B-8FF8-5E93 \
        --type permanent \
        --licensee "Masjid Al-Falah"
```
Output:
```text
============================================================
✨  KUNCI PENGAKTIFAN BERJAYA DIJANA  ✨
============================================================
Machine ID   : SURAU-088B-8FF8-5E93
Penerima     : Masjid Al-Falah
Jenis Lesen  : PERMANENT

🔑 ACTIVATION PIN:  PIN-609B-F671-9E26
📄 FAIL LESEN:      esolat_088B-8FF8-5E93.lic
============================================================
```

### 5.3 Activating the Customer's Unit
1. Open the Phone Admin panel: `http://<PC_IP>:8080/admin`.
2. Go to the **Lesen** tab.
3. Paste the **Activation PIN** into the input box and click **Sahkan & Aktifkan Lesen**.
4. The system updates immediately to:
   `✓ SISTEM AKTIF (PERMANENT) - Dilesenkan kepada: Masjid Al-Falah`
5. No reboot required; the kiosk display unlocks instantly.

---

## 6. Service Management & Troubleshooting Guide

### 6.1 Service Commands
```bash
# Restart server
sudo systemctl restart esolat.service

# View live logs
sudo journalctl -u esolat.service -f -n 50

# Stop service
sudo systemctl stop esolat.service
```

### 6.2 Common Issues & Resolutions

| Issue | Root Cause | Solution |
|---|---|---|
| **Kiosk displays blank screen** | Chromium profile lock or server not responding. | Run `sudo systemctl restart esolat.service`. Remove stale locks: `rm -rf /tmp/esolat-kiosk-chrome-profile/Singleton*`. |
| **No audio during Adhan** | Output muted in ALSA or wrong audio sink selected. | Run `alsamixer`, un-mute Master and PCM with `M` key. If using 3.5mm jack instead of HDMI, set default audio sink in `/etc/asound.conf`. |
| **TV turns off after 15 minutes** | TV Eco-sensor or HDMI link idle power down active. | Disable "Auto Power Off / Eco Mode" in the TV's physical settings menu using the remote control. Verify `xset q` shows `DPMS is Disabled`. |
| **Forgotten Admin Password** | User changed default and forgot. | Reset password hash to default in database:<br>`python3 -c "import sqlite3; conn = sqlite3.connect('/var/lib/esolat/data/esolat.db'); conn.execute(\"UPDATE settings SET value='e9a05baed10d02494b82f1d327f91cba30c7f696a237cd80b0f5d6525bf39eed' WHERE key='admin_password_hash'; UPDATE settings SET value='1' WHERE key='force_password_change'\"); conn.commit()"`<br>Password resets back to `admin@surau`. |
| **Database Backup & Restore** | Need to backup mosque configuration. | Database is single file: `/var/lib/esolat/data/esolat.db`. Media is at `/var/lib/esolat/media/`. Simply copy `/var/lib/esolat/` to backup drive. |

### 6.3 Complete Package Removal / Purge
```bash
# Remove package (preserves user data and licenses)
sudo apt remove esolat-kiosk

# Total wipeout (cleans database, logs, media, licenses, and system user)
sudo apt purge esolat-kiosk
```

---

## 7. Live HDMI Camera, HDMI Switcher & MP4 Recording Integration

This section provides complete engineering instructions for integrating an external HDMI video camera (e.g. Sony, Canon, Panasonic, or PTZ camera) to display live video on the prayer hall TVs while simultaneously recording 1080p MP4 files.

### 7.1 Key Hardware Principles
- **PC HDMI Port**: **Output Only** (sends video signal to TV). It cannot receive video.
- **Camera HDMI Port**: **Output Only** (sends live camera video).
- **USB HDMI Video Capture Card (Required)**: To get video from the camera *into* the PC for recording or software switching, plug a standard USB 3.0 HDMI Capture Card (e.g. Cam Link or standard UVC USB 3.0 Capture dongle, cost ~RM25 to RM80) into a USB 3.0 port on the PC. Linux recognizes this out-of-the-box as `/dev/video0`.

### 7.2 Architecture Setup Options

#### Option A: Smart e-Solat Integrated Setup (Recommended — Wireless Phone Control)
In this setup, no manual HDMI switcher buttons are needed. The entire broadcast and recording is toggled wirelessly from the committee's smartphone.

```text
┌─────────────────┐
│   HDMI Camera   │ (Pointed at Mimbar / Ustaz)
└────────┬────────┘
         │ (HDMI Cable)
         ▼
┌──────────────────────┐
│ USB HDMI Capture Card│ (Plugged into PC USB 3.0 Port -> /dev/video0)
└────────┬─────────────┘
         ▼
┌────────────────────────────────────────────────────────┐
│                      e-Solat PC                        │
│  • Displays live camera on TV (with prayer ticker)     │
│  • Records 1080p MP4 simultaneously via ffmpeg         │
└────────────────────────┬───────────────────────────────┘
                         │ (PC HDMI Output)
                         ▼
                ┌─────────────────┐
                │     TV Hall     │
                └─────────────────┘
```

1. **Video**: Connect Camera HDMI Out $\rightarrow$ USB HDMI Capture Card $\rightarrow$ PC USB 3.0 port.
2. **Audio**: Connect Mosque PA Mixer **REC OUT** (or AUX OUT) $\rightarrow$ PC 3.5mm **Line-In** port.
3. **Display**: Connect PC HDMI Out $\rightarrow$ Hall TV.
4. **Operation**:
   - In Phone Admin (`http://<PC_IP>:8080/admin`), tap **"📺 Papar Kamera di TV"** to broadcast live to TV.
   - Tap **"🔴 Mula Rakam MP4"** to record the lecture to `/var/lib/esolat/media/recordings/`.

#### Option B: Hardware HDMI Switcher Setup (Zero PC CPU Load, Hardware Pass-Through)
Uses a physical HDMI Switcher to switch between the PC e-Solat Signage and the Camera feed with 0ms latency.

```text
┌────────────────┐                     ┌────────────────┐
│   HDMI Camera  │                     │   e-Solat PC   │ (Signage)
└───────┬────────┘                     └───────┬────────┘
        │ (HDMI Cable)                         │ (HDMI Cable)
        ▼                                      ▼
┌──────────────────┐                           │
│ 1x2 HDMI Splitter│                           │
└───┬──────────┬───┘                           │
    │          │                               │
    │ Output A │ Output B                      │
    │          ▼                               │
    │   ┌─────────────────────┐                │
    │   │USB HDMI Capture Card│                │
    │   └─────────┬───────────┘                │
    │             │ (USB)                      │
    │             ▼                            │
    │     [ PC Records MP4 ]                   │
    │                                          │
    ▼                                          ▼
┌───────────────────────────────────────────────────────┐
│                     HDMI SWITCHER                     │
│   • Input 1: e-Solat PC HDMI (Normal Signage)         │
│   • Input 2: Camera HDMI (Live Khutbah / Kuliah)      │
└───────────────────────────┬───────────────────────────┘
                            │ (HDMI Out to TV)
                            ▼
                   ┌─────────────────┐
                   │     TV Hall     │
                   └─────────────────┘
```

1. Connect Camera HDMI Out $\rightarrow$ Input of a **1x2 HDMI Splitter** (RM20).
2. Splitter Output A $\rightarrow$ **Input 2** of HDMI Switcher.
3. Splitter Output B $\rightarrow$ USB HDMI Capture Card $\rightarrow$ PC USB port.
4. PC HDMI Out $\rightarrow$ **Input 1** of HDMI Switcher.
5. HDMI Switcher Output $\rightarrow$ Hall TV.
6. **Operation**:
   - Normal Hours: Switcher is on Input 1 (e-Solat Signage).
   - Friday Khutbah / Kuliah: Press Button 2 on HDMI Switcher (TV shows camera directly).
   - Tap **"🔴 Mula Rakam MP4"** in Phone Admin to record the MP4 file.

### 7.3 Verifying Capture Card & Audio on Linux
To verify Linux detects the USB capture card:
```bash
# Check video capture device:
ls -la /dev/video*
# Expected: /dev/video0 and /dev/video1

# Check audio capture device:
arecord -l
# Expected: card X: [USB Audio / Line In]
```
The e-Solat backend automatically utilizes hardware-accelerated H.264 / AAC encoding to write MP4 files to `/var/lib/esolat/media/recordings/`.

---

## 8. Official Vendor & Technical Support Details

- **Company Name**: Skywalker Consortium
- **SSM Registration No**: AS0463209-A (202303102311)
- **Business Address**: Block A8-3A, Jalan Selaman, 68000 Ampang, Selangor
- **Official Email**: skywalker.co@proton.me
- **Support Hotline / WhatsApp**: +6011-1871 2388
- **Official Website**: https://sky12388.github.io/esolat/

Untuk perolehan rasmi, pengaktifan lesen kekal/tahunan, sebut harga masjid/surau, atau bantuan teknikal pemasangan di lokasi, sila hubungi pihak sokongan teknikal Skywalker Consortium.

