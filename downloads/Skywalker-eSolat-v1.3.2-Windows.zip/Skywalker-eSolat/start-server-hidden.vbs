' Silent Background Launcher for e-Solat Server on Windows
Set WshShell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
currentDir = fso.GetParentFolderName(WScript.ScriptFullName)
serverExe = currentDir & "\bin\esolat-server.exe"

If fso.FileExists(serverExe) Then
    WshShell.Run """" & serverExe & """ --port 8080 --host 0.0.0.0", 0, False
End If
