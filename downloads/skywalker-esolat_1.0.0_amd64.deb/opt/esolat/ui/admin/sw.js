/**
 * e-Solat Admin Console Service Worker
 * Version: 1.0.0
 * Provides offline caching, lightning-fast loads, and WebAPK installation on Android.
 */

const CACHE_NAME = 'esolat-admin-v1.0.0';
const STATIC_ASSETS = [
  '/admin/',
  '/admin/index.html',
  '/admin/css/admin.css',
  '/admin/js/admin.js',
  '/admin/manifest.json',
  '/admin/icons/icon-192.png',
  '/admin/icons/icon-512.png',
  '/admin/icons/icon-maskable-512.png',
  '/admin/icons/apple-touch-icon.png',
  '/admin/icons/favicon.png'
];

// Install Event - Pre-cache core admin shell
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(STATIC_ASSETS).catch((err) => {
        console.warn('[ServiceWorker] Some assets failed to pre-cache:', err);
      });
    }).then(() => self.skipWaiting())
  );
});

// Activate Event - Clean up old caches
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) => {
      return Promise.all(
        keys.filter((key) => key !== CACHE_NAME).map((key) => caches.delete(key))
      );
    }).then(() => self.clients.claim())
  );
});

// Fetch Event
self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);

  // Always use Network-Only for dynamic API requests and WebSocket/stream endpoints
  if (url.pathname.startsWith('/api/') || url.pathname.startsWith('/stream') || event.request.method !== 'GET') {
    event.respondWith(
      fetch(event.request).catch(() => {
        return new Response(JSON.stringify({ error: true, message: 'Pelayan e-Solat luar talian (Offline).' }), {
          headers: { 'Content-Type': 'application/json' }
        });
      })
    );
    return;
  }

  // Network-First with Cache Fallback for HTML pages & Static assets
  event.respondWith(
    fetch(event.request)
      .then((networkResponse) => {
        if (networkResponse && networkResponse.status === 200 && networkResponse.type === 'basic') {
          const responseToCache = networkResponse.clone();
          caches.open(CACHE_NAME).then((cache) => {
            cache.put(event.request, responseToCache);
          });
        }
        return networkResponse;
      })
      .catch(() => {
        return caches.match(event.request).then((cachedResponse) => {
          if (cachedResponse) {
            return cachedResponse;
          }
          if (event.request.headers.get('accept') && event.request.headers.get('accept').includes('text/html')) {
            return caches.match('/admin/index.html');
          }
        });
      })
  );
});
